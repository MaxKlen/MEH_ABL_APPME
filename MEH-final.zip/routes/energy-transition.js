const express = require("express");
const router = express.Router();

// Energy Transition page
router.get("/", (req, res) => {
  res.render("energy-transition", {
    title: "Energy Transition - ABL Group Services Catalog",
    activeNav: "energy-transition" // Assuming you might want to highlight this in nav
  });
});

module.exports = router;

