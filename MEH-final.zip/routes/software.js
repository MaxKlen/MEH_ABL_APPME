const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');

// Main software landing page
router.get('/', (req, res) => {
  res.render('software/index', { 
    title: 'Software Solutions | ABL Group'
  });
});

// ePAV Page
router.get('/epav', (req, res) => {
  res.render('software/epav', { 
    title: 'ePAV | Environmental Performance Assessment Value'
  });
});

// Software Downloads
router.get('/download/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, '../public/downloads/software', filename);

  if (fs.existsSync(filePath)) {
    res.download(filePath);
  } else {
    res.status(404).render('error', {
      title: 'File Not Found | ABL Group',
      message: 'The requested software file could not be found.',
      error: { status: 404, stack: '' }
    });
  }
});

module.exports = router;
