// Create professional visuals for general concepts
document.addEventListener('DOMContentLoaded', function() {
  // Create professional visuals for general concepts
  const createProfessionalVisuals = () => {
    // Global Presence visual
    const globalPresenceImg = document.createElement('img');
    globalPresenceImg.src = '/images/features_new/global-presence-new.webp';
    globalPresenceImg.alt = 'Global Presence';
    globalPresenceImg.className = 'img-fluid feature-image';
    
    // Expert Team visual
    const expertTeamImg = document.createElement('img');
    expertTeamImg.src = '/images/features_new/expert-team-new.webp';
    expertTeamImg.alt = 'Expert Team';
    expertTeamImg.className = 'img-fluid feature-image';
    
    // Sustainability Focus visual
    const sustainabilityImg = document.createElement('img');
    sustainabilityImg.src = '/images/features_new/sustainability-focus.jpeg';
    sustainabilityImg.alt = 'Sustainability Focus';
    sustainabilityImg.className = 'img-fluid feature-image';
    
    // Replace existing visuals with professional ones
    const featureImages = document.querySelectorAll('.feature-image-container');
    if (featureImages.length >= 3) {
      featureImages[0].querySelector('img')?.replaceWith(globalPresenceImg);
      featureImages[1].querySelector('img')?.replaceWith(expertTeamImg);
      featureImages[2].querySelector('img')?.replaceWith(sustainabilityImg);
    }
  };
  
  // Use ABL-specific images only for their intended purposes
  const useABLImagesCorrectly = () => {
    // Business segments
    const ablImg = document.createElement('img');
    ablImg.src = '/images/segments/abl.png';
    ablImg.alt = 'ABL Group Business Segment';
    ablImg.className = 'img-fluid segment-image';
    
    const owcImg = document.createElement('img');
    owcImg.src = '/images/segments/owc.png';
    owcImg.alt = 'OWC Business Segment';
    owcImg.className = 'img-fluid segment-image';
    
    const agrImg = document.createElement('img');
    agrImg.src = '/images/segments/agr.png';
    agrImg.alt = 'AGR Business Segment';
    agrImg.className = 'img-fluid segment-image';
    
    const longitudeImg = document.createElement('img');
    longitudeImg.src = '/images/segments/longitude.png';
    longitudeImg.alt = 'Longitude Business Segment';
    longitudeImg.className = 'img-fluid segment-image';
    
    // Replace segment images
    const segmentImages = document.querySelectorAll('.segment-image-container');
    if (segmentImages.length >= 4) {
      segmentImages[0].querySelector('img')?.replaceWith(ablImg);
      segmentImages[1].querySelector('img')?.replaceWith(owcImg);
      segmentImages[2].querySelector('img')?.replaceWith(agrImg);
      segmentImages[3].querySelector('img')?.replaceWith(longitudeImg);
    }
    
    // Energy lifecycle
    const lifecycleImg = document.createElement('img');
    lifecycleImg.src = '/images/lifecycle/energy-lifecycle.png';
    lifecycleImg.alt = 'Energy Lifecycle';
    lifecycleImg.className = 'img-fluid lifecycle-image';
    
    const lifecycleContainer = document.querySelector('.lifecycle-image-container');
    if (lifecycleContainer) {
      lifecycleContainer.querySelector('img')?.replaceWith(lifecycleImg);
    }
  };
  
  // Initialize visuals
  createProfessionalVisuals();
  useABLImagesCorrectly();
});
