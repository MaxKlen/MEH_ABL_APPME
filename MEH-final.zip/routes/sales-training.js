const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Sales Training page
router.get('/', (req, res) => {
  res.render('sales-training', {
    title: 'Sales and Business Development Essentials',
    activeNav: 'sales-training'
  });
});

// Get specific training module
router.get('/module/:moduleId', (req, res) => {
  const moduleId = req.params.moduleId;
  
  // Mock training modules data
  const trainingModules = {
    'client-communication': {
      id: 'client-communication',
      title: 'Client Communication Fundamentals',
      description: 'Learn effective strategies for communicating with potential clients, building rapport, and understanding client needs.',
      sections: [
        {
          title: 'Initial Client Contact',
          content: 'The first impression is crucial in establishing a professional relationship. When making initial contact with a potential client, be clear, concise, and professional. Introduce yourself and ABL Group briefly, then focus on understanding the client\'s needs rather than immediately pitching services.',
          tips: [
            'Research the client before making contact',
            'Prepare a brief elevator pitch about ABL Group',
            'Ask open-ended questions to understand their needs',
            'Listen more than you speak'
          ]
        },
        {
          title: 'Building Rapport',
          content: 'Building rapport is about establishing trust and a connection with your client. This involves finding common ground, showing genuine interest in their business challenges, and demonstrating how ABL Group can provide value.',
          tips: [
            'Find common interests or connections',
            'Show genuine interest in their business',
            'Share relevant industry insights',
            'Be authentic and honest in all communications'
          ]
        },
        {
          title: 'Active Listening',
          content: 'Active listening involves fully concentrating on what the client is saying, understanding their message, and responding thoughtfully. This skill is essential for identifying client needs and potential opportunities.',
          tips: [
            'Maintain eye contact and appropriate body language',
            'Take notes during meetings',
            'Paraphrase to confirm understanding',
            'Ask clarifying questions'
          ]
        },
        {
          title: 'Communication Templates',
          content: 'The following templates can be used as starting points for various client communications:',
          templates: [
            {
              name: 'Introduction Email',
              text: 'Subject: Introduction - ABL Group Services\n\nDear [Client Name],\n\nI hope this email finds you well. My name is [Your Name] from ABL Group, a leading provider of [relevant services] in the [industry] sector.\n\nI recently learned about [something specific about their company/project] and believe our expertise in [specific service area] could be valuable to your team.\n\nWould you be available for a brief 15-minute call next week to discuss how ABL Group might support your [specific need or project]?\n\nThank you for your consideration.\n\nBest regards,\n[Your Name]\n[Your Position]\nABL Group'
            },
            {
              name: 'Follow-up After Meeting',
              text: 'Subject: Thank You and Next Steps - [Project/Meeting Reference]\n\nDear [Client Name],\n\nThank you for taking the time to meet with me today to discuss [brief meeting summary].\n\nBased on our conversation, I understand your key challenges are:\n1. [Challenge 1]\n2. [Challenge 2]\n3. [Challenge 3]\n\nI believe ABL Group can support you with these challenges through our [specific services]. As promised, I\'ve attached [relevant materials] for your review.\n\nI\'ll follow up next week to discuss any questions you might have and potential next steps.\n\nBest regards,\n[Your Name]\n[Your Position]\nABL Group'
            }
          ]
        }
      ],
      resources: [
        {
          title: 'ABL Academy Course: Advanced Client Communication',
          url: 'https://academy.ablgroup.com/courses/client-communication',
          description: 'A comprehensive course on effective client communication strategies'
        },
        {
          title: 'Communication Style Assessment Tool',
          url: 'https://academy.ablgroup.com/tools/communication-style-assessment',
          description: 'Tool to help identify your communication style and adapt to different client preferences'
        }
      ]
    },
    'business-discussions': {
      id: 'business-discussions',
      title: 'Initiating Business Discussions',
      description: 'Learn how to effectively introduce ABL Group\'s services, identify client pain points, and initiate conversations about new business opportunities.',
      sections: [
        {
          title: 'Value Proposition Delivery',
          content: 'A strong value proposition clearly communicates how ABL Group\'s services address specific client needs. When introducing our services, focus on the unique value we provide rather than just listing features.',
          tips: [
            'Customize the value proposition to the specific client',
            'Focus on outcomes rather than services',
            'Use concrete examples and case studies',
            'Quantify benefits whenever possible'
          ]
        },
        {
          title: 'Identifying Pain Points',
          content: 'Successful business discussions often start by identifying and addressing client pain points. By understanding their challenges, you can position ABL Group services as solutions.',
          tips: [
            'Research common industry challenges before meetings',
            'Ask probing questions about current processes',
            'Listen for frustrations or inefficiencies mentioned',
            'Connect pain points to specific ABL Group solutions'
          ]
        },
        {
          title: 'Opportunity Identification',
          content: 'Beyond addressing immediate needs, look for opportunities to introduce additional services that could benefit the client. This requires understanding their business holistically.',
          tips: [
            'Research the client\'s strategic initiatives',
            'Understand their industry trends and challenges',
            'Look for gaps in their current service providers',
            'Identify upcoming projects or expansions'
          ]
        }
      ],
      resources: [
        {
          title: 'ABL Academy Course: Consultative Selling',
          url: 'https://academy.ablgroup.com/courses/consultative-selling',
          description: 'Learn the principles of consultative selling to better identify and address client needs'
        },
        {
          title: 'Industry Pain Points Database',
          url: 'https://academy.ablgroup.com/resources/industry-pain-points',
          description: 'Database of common pain points by industry and how ABL Group services address them'
        }
      ]
    },
    'client-relationships': {
      id: 'client-relationships',
      title: 'Improving Client Relationships',
      description: 'Strategies for nurturing and strengthening client relationships, proactive communication, and addressing client inquiries professionally.',
      sections: [
        {
          title: 'Relationship Nurturing',
          content: 'Building strong client relationships requires consistent nurturing beyond project delivery. Regular check-ins, sharing relevant insights, and demonstrating ongoing value are key strategies.',
          tips: [
            'Schedule regular relationship check-ins',
            'Share industry news and insights relevant to their business',
            'Remember personal details and preferences',
            'Celebrate their successes and milestones'
          ]
        },
        {
          title: 'Proactive Communication',
          content: 'Proactive communication involves anticipating client needs and providing information before they ask for it. This demonstrates attentiveness and builds trust.',
          tips: [
            'Provide regular status updates on ongoing projects',
            'Alert clients to potential issues before they become problems',
            'Share relevant new services or capabilities',
            'Follow up after project completion to ensure satisfaction'
          ]
        },
        {
          title: 'Addressing Inquiries',
          content: 'How you respond to client inquiries and concerns significantly impacts relationship quality. Quick, thorough, and professional responses demonstrate reliability and commitment.',
          tips: [
            'Acknowledge all inquiries within 24 hours',
            'Set clear expectations for resolution timelines',
            'Be transparent about challenges or limitations',
            'Follow up to ensure satisfaction with the resolution'
          ]
        }
      ],
      resources: [
        {
          title: 'ABL Academy Course: Client Relationship Management',
          url: 'https://academy.ablgroup.com/courses/client-relationship-management',
          description: 'Comprehensive course on building and maintaining strong client relationships'
        },
        {
          title: 'Client Communication Templates',
          url: 'https://academy.ablgroup.com/resources/communication-templates',
          description: 'Templates for various client communications throughout the relationship lifecycle'
        }
      ]
    },
    'lead-qualification': {
      id: 'lead-qualification',
      title: 'Lead/Opportunity Qualification',
      description: 'Methodologies for identifying and qualifying potential leads and opportunities, assessing viability, and understanding client decision-making processes.',
      sections: [
        {
          title: 'Qualification Criteria',
          content: 'Not all leads have equal potential. Using consistent qualification criteria helps focus efforts on the most promising opportunities.',
          tips: [
            'Assess budget availability and alignment',
            'Confirm decision-making authority and process',
            'Evaluate timeline compatibility',
            'Determine technical and strategic fit'
          ]
        },
        {
          title: 'BANT Framework',
          content: 'The BANT framework (Budget, Authority, Need, Timeline) provides a structured approach to qualifying leads:',
          details: [
            {
              title: 'Budget',
              description: 'Does the prospect have budget allocated for this type of service? What is their typical investment range for similar services?'
            },
            {
              title: 'Authority',
              description: 'Are you speaking with the decision-maker? If not, who is involved in the decision process and what is their role?'
            },
            {
              title: 'Need',
              description: 'What specific challenges or pain points does the prospect have that ABL Group can address? How urgent or important is solving this need?'
            },
            {
              title: 'Timeline',
              description: 'What is the prospect\'s timeline for implementation? Are there any specific deadlines or milestones driving their timeline?'
            }
          ]
        },
        {
          title: 'Opportunity Scoring',
          content: 'Using a consistent scoring system helps prioritize opportunities based on potential value and likelihood of success.',
          scoringSystem: {
            criteria: [
              'Strategic alignment with ABL Group capabilities',
              'Budget availability and size',
              'Decision-making process clarity',
              'Competitive positioning',
              'Timeline alignment'
            ],
            scale: 'Each criterion is scored 1-5, with 5 being the highest. Opportunities scoring 20+ are high priority.'
          }
        }
      ],
      resources: [
        {
          title: 'ABL Academy Course: Lead Qualification Mastery',
          url: 'https://academy.ablgroup.com/courses/lead-qualification',
          description: 'Detailed course on effective lead qualification methodologies'
        },
        {
          title: 'Opportunity Scoring Template',
          url: 'https://academy.ablgroup.com/resources/opportunity-scoring-template',
          description: 'Excel template for scoring and prioritizing sales opportunities'
        }
      ]
    }
  };
  
  const module = trainingModules[moduleId];
  
  if (!module) {
    return res.status(404).json({ error: 'Training module not found' });
  }
  
  res.json(module);
});

module.exports = router;
