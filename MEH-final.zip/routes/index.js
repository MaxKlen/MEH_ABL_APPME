const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Load mock data
const services = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/services.json')));
const businessSegments = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/business-segments.json')));
const lifecycleStages = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/lifecycle-stages.json')));

// Home page
router.get('/', (req, res) => {
  res.render('index', {
    title: 'ABL Group Services Digital Catalog',
    activeNav: 'home',
    services,
    businessSegments,
    lifecycleStages
  });
});

// Login page
router.get('/login', (req, res) => {
  res.render('login', {
    title: 'Login - ABL Group Services Digital Catalog',
    activeNav: 'login'
  });
});

// Process login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  
  // Mock authentication - in a real app, this would validate against a database
  if (email && password) {
    req.session.user = {
      id: 1,
      name: email.split('@')[0],
      email,
      role: email.includes('admin') ? 'admin' : 'engineer',
      isInternal: email.includes('@ablgroup.com')
    };
    
    res.redirect('/');
  } else {
    res.render('login', {
      title: 'Login - ABL Group Services Digital Catalog',
      activeNav: 'login',
      error: 'Invalid email or password'
    });
  }
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

module.exports = router;
