// Copilot AI Assistant functionality
document.addEventListener('DOMContentLoaded', function() {
    const copilotForm = document.getElementById('copilot-form');
    const copilotQuestion = document.getElementById('copilot-question');
    const copilotMessages = document.getElementById('copilot-messages');
    
    if (copilotForm && copilotQuestion && copilotMessages) {
        // Enhanced responses for common questions
        const responses = {
            'services': 'ABL Group offers a wide range of services across four business segments: Renewables, Maritime, Oil & Gas, and Energy Transition & Digital. You can explore all services in our Services Catalog section.',
            'renewables': 'Our Renewables segment, led by OWC, offers comprehensive services for wind, solar, and energy storage projects, from early-stage development through operations and maintenance.',
            'maritime': 'ABL provides marine engineering, asset integrity management, and technical advisory services for the maritime sector, including vessel inspections and marine warranty surveys.',
            'oil': 'Our Oil & Gas segment offers well engineering, reservoir management, and asset integrity services through ABL and AGR companies.',
            'gas': 'Our Oil & Gas segment offers well engineering, reservoir management, and asset integrity services through ABL and AGR companies.',
            'digital': 'The Energy Transition & Digital segment provides cross-sectoral support with digital solutions and advisory services for energy transition projects.',
            'contact': 'You can contact us through the lead form at the bottom of this page or by emailing info@ablgroup.com.',
            'locations': 'ABL Group operates in 43 countries worldwide with expertise across 77 markets. Our major offices are located in London, Oslo, Houston, Singapore, and Perth.',
            'experts': 'ABL Group has over 1800 dedicated professionals with deep industry knowledge across various disciplines including engineering, naval architecture, and environmental sciences.',
            'bundles': 'We offer pre-configured service packages (bundles) designed for specific project needs and lifecycle stages. Check out our Service Bundles section for more details.',
            'training': 'ABL Group provides comprehensive training through ABL Academy. Visit https://ablacademy.myabsorb.eu/ to explore our training programs.',
            'lifecycle': 'ABL Group provides services across the entire energy lifecycle, from concept and feasibility through development, construction, operations, and decommissioning.',
            'concept': 'In the Concept stage, ABL Group offers services including concept design, pre-feasibility studies, and initial environmental assessments.',
            'feasibility': 'For the Feasibility stage, we provide detailed feasibility studies, site assessments, and preliminary engineering design services.',
            'development': 'During the Development stage, ABL Group offers detailed engineering, environmental impact assessments, and regulatory compliance services.',
            'construction': 'For the Construction stage, we provide construction supervision, quality assurance, and marine warranty survey services.',
            'operations': 'During Operations, ABL Group offers asset integrity management, performance optimization, and maintenance strategy services.',
            'decommissioning': 'For Decommissioning, we provide decommissioning planning, environmental compliance, and waste management services.',
            'abl': 'ABL is one of our core business segments, providing marine engineering, asset integrity management, and technical advisory services.',
            'owc': 'OWC is our renewable energy consultancy, offering services for wind, solar, and energy storage projects.',
            'agr': 'AGR provides well engineering, reservoir management, and software solutions for the oil and gas industry.',
            'longitude': 'Longitude offers naval architecture and marine engineering solutions for various maritime sectors.',
            'help': 'I can help you with information about ABL Group services, business segments, lifecycle stages, and more. Just ask me about any specific area you\'re interested in!',
            'hello': 'Hello! I\'m your ABL Group Services assistant. How can I help you today?',
            'hi': 'Hi there! I\'m your ABL Group Services assistant. How can I help you today?',
            'academy': 'ABL Academy is our comprehensive training platform. Visit https://ablacademy.myabsorb.eu/ to access courses and certification programs.',
            'certification': 'ABL Group offers various certification programs through ABL Academy. Visit https://ablacademy.myabsorb.eu/ for more information.',
            'cost': 'Service costs vary based on project requirements and scope. Please contact our team through the lead form for a customized quote.',
            'price': 'Service pricing depends on project specifics and requirements. Please submit your details through the lead form for a detailed quote.',
            'login': 'You can log in to ABL Academy at https://ablacademy.myabsorb.eu/ using your provided credentials.',
            'sustainability': 'ABL Group is committed to sustainability and energy transition. We offer specialized services to support renewable energy development and decarbonization strategies.',
            'energy transition': 'Our Energy Transition services help clients navigate the shift to cleaner energy sources through strategic advisory, technical support, and innovative solutions.'
        };
        
        // Multi-keyword responses for more complex questions
        const complexResponses = [
            {
                keywords: ['difference', 'between', 'concept', 'feasibility'],
                response: 'The Concept stage focuses on initial ideas and preliminary analysis, while the Feasibility stage involves detailed technical, economic, and environmental viability assessments. ABL Group provides specialized services for both stages.'
            },
            {
                keywords: ['how', 'contact', 'sales'],
                response: 'You can contact our sales team by filling out the lead form at the bottom of this page, emailing sales@ablgroup.com, or calling our main office at +44 123 456 78.'
            },
            {
                keywords: ['which', 'services', 'renewables'],
                response: 'For renewable energy projects, we offer services including site selection, resource assessment, technical due diligence, engineering design, construction supervision, and operational performance optimization.'
            },
            {
                keywords: ['what', 'business', 'segments'],
                response: 'ABL Group operates across four main business segments: ABL (marine and engineering services), OWC (renewable energy consultancy), AGR (oil & gas well engineering), and Longitude (naval architecture).'
            }
        ];
        
        // Function to generate AI response with improved matching
        function generateResponse(question) {
            question = question.toLowerCase();
            
            // Check for complex multi-keyword matches first
            for (const complex of complexResponses) {
                const matchCount = complex.keywords.filter(keyword => question.includes(keyword)).length;
                // If the question contains at least 2 keywords from the complex response
                if (matchCount >= 2) {
                    return complex.response;
                }
            }
            
            // Check for direct keyword matches
            for (const [keyword, response] of Object.entries(responses)) {
                if (question.includes(keyword)) {
                    return response;
                }
            }
            
            // Check for partial matches if no direct keyword match
            for (const [keyword, response] of Object.entries(responses)) {
                const words = keyword.split(' ');
                for (const word of words) {
                    if (word.length > 3 && question.includes(word)) {
                        return response;
                    }
                }
            }
            
            // Default response if no keywords match
            return "I'd be happy to help with that. For specific information about this topic, I recommend exploring our Services Catalog or contacting our team through the lead form. Is there something specific about ABL Group services you'd like to know?";
        }
        
        // Add user message to chat
        function addUserMessage(message) {
            const userDiv = document.createElement('div');
            userDiv.className = 'copilot-message user-message';
            userDiv.textContent = message;
            copilotMessages.appendChild(userDiv);
            copilotMessages.scrollTop = copilotMessages.scrollHeight;
        }
        
        // Add AI response to chat with enhanced formatting
        function addAIResponse(message) {
            const aiDiv = document.createElement('div');
            aiDiv.className = 'copilot-message ai-message';
            
            // Format links in the response
            if (message.includes('https://')) {
                const parts = message.split(/(https:\/\/[^\s]+)/g);
                aiDiv.innerHTML = '';
                
                parts.forEach(part => {
                    if (part.startsWith('https://')) {
                        const link = document.createElement('a');
                        link.href = part;
                        link.target = '_blank';
                        link.textContent = part;
                        link.className = 'text-white';
                        aiDiv.appendChild(link);
                    } else {
                        const text = document.createTextNode(part);
                        aiDiv.appendChild(text);
                    }
                });
            } else {
                aiDiv.textContent = message;
            }
            
            copilotMessages.appendChild(aiDiv);
            copilotMessages.scrollTop = copilotMessages.scrollHeight;
        }
        
        // Handle form submission
        copilotForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const question = copilotQuestion.value.trim();
            if (question) {
                // Add user question to chat
                addUserMessage(question);
                
                // Clear input field
                copilotQuestion.value = '';
                
                // Show typing indicator
                const typingDiv = document.createElement('div');
                typingDiv.className = 'copilot-message ai-message typing';
                typingDiv.textContent = 'Typing...';
                copilotMessages.appendChild(typingDiv);
                copilotMessages.scrollTop = copilotMessages.scrollHeight;
                
                // Generate and display AI response after a short delay
                setTimeout(function() {
                    // Remove typing indicator
                    copilotMessages.removeChild(typingDiv);
                    
                    // Add AI response
                    const response = generateResponse(question);
                    addAIResponse(response);
                    
                    // Add follow-up suggestion for certain responses
                    if (response.includes('services') || response.includes('lifecycle')) {
                        setTimeout(() => {
                            addAIResponse("Would you like to know more about a specific business segment or lifecycle stage?");
                        }, 1500);
                    }
                }, 1000);
            }
        });
        
        // Add some CSS for the chat
        const style = document.createElement('style');
        style.textContent = `
            .copilot-message {
                padding: 10px 15px;
                margin-bottom: 10px;
                border-radius: 10px;
                max-width: 80%;
                word-wrap: break-word;
            }
            
            .user-message {
                background-color: #e9ecef;
                margin-left: auto;
                text-align: right;
            }
            
            .ai-message {
                background-color: #0d6efd;
                color: white;
            }
            
            .typing {
                opacity: 0.7;
            }
            
            #copilot-messages {
                border: 1px solid #dee2e6;
                border-radius: 5px;
                padding: 10px;
                background-color: #f8f9fa;
                height: 300px !important;
            }
            
            #copilot-form .input-group {
                margin-top: 10px;
            }
            
            .ai-message a {
                text-decoration: underline;
            }
            
            .ai-message a:hover {
                text-decoration: none;
            }
        `;
        document.head.appendChild(style);
        
        // Add initial welcome message if container is empty
        if (copilotMessages.children.length === 0) {
            addAIResponse("Hello! I'm your ABL Group Services assistant. How can I help you today?");
            
            // Add a suggestion message after a short delay
            setTimeout(() => {
                addAIResponse("You can ask me about our services, business segments, or specific lifecycle stages.");
            }, 1500);
        }
        
        // Add quick suggestion buttons
        const suggestionsDiv = document.createElement('div');
        suggestionsDiv.className = 'copilot-suggestions mt-2 mb-2';
        suggestionsDiv.innerHTML = `
            <span class="me-2">Try asking about:</span>
            <button class="btn btn-sm btn-outline-primary me-1 suggestion-btn" data-question="What services do you offer?">Services</button>
            <button class="btn btn-sm btn-outline-primary me-1 suggestion-btn" data-question="Tell me about the energy lifecycle">Lifecycle</button>
            <button class="btn btn-sm btn-outline-primary me-1 suggestion-btn" data-question="How can I contact ABL Group?">Contact</button>
        `;
        
        // Insert suggestions before the form
        copilotForm.parentNode.insertBefore(suggestionsDiv, copilotForm);
        
        // Add event listeners to suggestion buttons
        const suggestionButtons = document.querySelectorAll('.suggestion-btn');
        suggestionButtons.forEach(button => {
            button.addEventListener('click', function() {
                const question = this.getAttribute('data-question');
                copilotQuestion.value = question;
                copilotForm.dispatchEvent(new Event('submit'));
            });
        });
    }
});
