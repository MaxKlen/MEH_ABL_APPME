import React from 'react';

const EffectiveQuestioning = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-blue-800 mb-1">Effective Questioning Templates</h1>
        <p className="text-gray-600 italic">A Comprehensive Guide for ABL Group Technical Consultants</p>
      </div>
      
      <div className="bg-blue-50 p-4 rounded-md mb-6">
        <h2 className="text-lg font-semibold text-blue-700 mb-2">Introduction</h2>
        <p className="text-gray-700 mb-3">Asking the right questions at the right time is a fundamental skill for ABL Group consultants across all our sectors. Effective questioning helps uncover true client needs, gather critical technical information, identify risks, and build trust. This guide provides structured questioning templates tailored to ABL Group's consultancy services in renewables, maritime, and oil & gas.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">Benefits of Strategic Questioning</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Uncovers hidden technical requirements</li>
              <li>Demonstrates ABL's expertise and insight</li>
              <li>Builds client trust and credibility</li>
              <li>Guides more effective solution development</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">ABL Group Values Alignment</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li><strong>Safety:</strong> Uncover safety considerations</li>
              <li><strong>Technical Excellence:</strong> Identify all requirements</li>
              <li><strong>Collaboration:</strong> Build client partnerships</li>
              <li><strong>Innovation:</strong> Discover opportunities</li>
              <li><strong>Truth:</strong> Ensure transparent discussions</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">How to Use This Guide</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Prepare questions before client meetings</li>
              <li>Adapt templates to specific sector contexts</li>
              <li>Practice question sequences for common scenarios</li>
              <li>Review and refine your approach after meetings</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Question Types Framework</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Question Type</th>
                  <th className="p-2 text-left">Purpose</th>
                  <th className="p-2 text-left">When to Use</th>
                  <th className="p-2 text-left">Example in ABL Context</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Open-Ended</td>
                  <td className="p-2">Generate detailed responses and explore topics broadly</td>
                  <td className="p-2">Initial client discovery; exploring technical challenges; understanding project scope</td>
                  <td className="p-2 italic">"What are the main technical challenges you've encountered with your floating wind platform design?"</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Closed</td>
                  <td className="p-2">Confirm specific information; get clear yes/no answers</td>
                  <td className="p-2">Verifying technical specifications; confirming deadlines; checking understanding</td>
                  <td className="p-2 italic">"Has your team conducted a HAZID assessment for the marine operations?"</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Probing</td>
                  <td className="p-2">Dig deeper into responses; uncover underlying technical issues</td>
                  <td className="p-2">Following up on vague technical descriptions; exploring root causes; challenging assumptions</td>
                  <td className="p-2 italic">"Could you tell me more about the specific metocean conditions that caused those unexpected loads?"</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Reflective</td>
                  <td className="p-2">Confirm understanding of technical requirements; encourage elaboration</td>
                  <td className="p-2">Clarifying complex technical information; demonstrating active listening; building rapport</td>
                  <td className="p-2 italic">"So you're saying the main issue is with the dynamic response of the cable configuration during extreme weather events?"</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Hypothetical</td>
                  <td className="p-2">Explore technical possibilities; test scenarios; evaluate alternatives</td>
                  <td className="p-2">Engineering option assessment; risk evaluation; future planning</td>
                  <td className="p-2 italic">"If we were to implement a different mooring configuration, how would that affect your installation timeline?"</td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Leading</td>
                  <td className="p-2">Guide toward specific technical considerations or insights</td>
                  <td className="p-2">Highlighting important considerations; suggesting alternatives (use very sparingly)</td>
                  <td className="p-2 italic">"Have you considered how implementing this condition monitoring system could reduce your long-term maintenance costs?"</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Client Engagement Templates by Sector</h2>
        
        <div className="mb-5">
          <h3 className="text-lg font-medium text-blue-600 mb-2">Renewables Sector</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Project Context Assessment</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What are the primary drivers for this renewable energy project? (e.g., policy requirements, corporate targets, market opportunity)"</li>
                    <li className="mb-2">"What stage is the project currently at in terms of development, and what are your immediate priorities?"</li>
                    <li className="mb-2">"What technical studies or assessments have already been completed for this development?"</li>
                    <li className="mb-2">"What specific site characteristics or constraints are most significantly influencing your design decisions?"</li>
                    <li className="mb-2">"How would you describe your team's experience with similar renewable energy developments?"</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Technical Challenge Exploration</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What specific technical challenges have you encountered with the [foundation/electrical system/turbine selection]?"</li>
                    <li className="mb-2">"How have the metocean conditions at the site influenced your approach to the design?"</li>
                    <li className="mb-2">"What installation methodologies are you considering, and what constraints might affect these operations?"</li>
                    <li className="mb-2">"What grid connection challenges or constraints are you facing with this project?"</li>
                    <li className="mb-2">"What yield assessment uncertainties are most concerning for your financial modeling?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Risk Assessment & Mitigation</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2">"What do you see as the top three technical risks that could impact project success?"</li>
                  <li className="mb-2">"How is your team currently approaching weather risk management for the construction phase?"</li>
                  <li className="mb-2">"What supply chain or logistics risks have you identified that could affect the project timeline?"</li>
                  <li className="mb-2">"How are you planning to address potential environmental impacts and regulatory requirements?"</li>
                  <li className="mb-2">"What contingency plans do you have in place for managing unexpected technical challenges during implementation?"</li>
                </ul>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Technology-Specific Questions</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Offshore Wind</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What foundation type are you considering and why?"</li>
                    <li className="mb-1">"How are you addressing dynamic cable fatigue concerns?"</li>
                    <li className="mb-1">"What vessel spread assumptions are in your installation plan?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Floating Solar</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What mooring system design are you considering?"</li>
                    <li className="mb-1">"How are you addressing panel cleaning and maintenance?"</li>
                    <li className="mb-1">"What water quality effects have you considered?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Wave & Tidal</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What operational experience do you have with this technology?"</li>
                    <li className="mb-1">"How are you addressing biofouling concerns?"</li>
                    <li className="mb-1">"What extreme load cases govern your design?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="bg-yellow-50 p-3 rounded mt-4">
              <h4 className="font-medium text-yellow-800 mb-1">Strategic Notes for Renewables Sector</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Focus questions on areas where ABL Group's OWC, Innosea, and East Point Geo expertise can add the most value</li>
                <li className="mb-1">Connect technical inquiries to project economics and bankability concerns</li>
                <li className="mb-1">Explore integration with existing energy infrastructure when relevant</li>
                <li className="mb-1">Listen for opportunities to introduce innovative solutions from ABL's global experience</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mb-5">
          <h3 className="text-lg font-medium text-blue-600 mb-2">Maritime Sector</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Vessel & Fleet Assessment</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What is the current composition of your fleet, and what operational challenges are you experiencing?"</li>
                    <li className="mb-2">"What are your main concerns regarding the vessel's [structural integrity/propulsion system/navigation equipment]?"</li>
                    <li className="mb-2">"How are you currently approaching your fleet's emissions reduction targets?"</li>
                    <li className="mb-2">"What has been your experience with implementing [new technology/system] across your vessels?"</li>
                    <li className="mb-2">"What specific regulatory compliance challenges are most pressing for your operations?"</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Marine Casualty & Claims</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"Can you walk me through the sequence of events that led to the incident?"</li>
                    <li className="mb-2">"What were the weather and sea conditions at the time of the incident?"</li>
                    <li className="mb-2">"What immediate actions were taken by the crew following the incident?"</li>
                    <li className="mb-2">"What documentation is available regarding the vessel's condition prior to the incident?"</li>
                    <li className="mb-2">"What technical specifications or drawings do you have available for the affected systems?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Ports & Harbors</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2">"What are the primary operational constraints or bottlenecks at your port facility?"</li>
                  <li className="mb-2">"How is your port planning to accommodate changing vessel sizes and types in the future?"</li>
                  <li className="mb-2">"What specific environmental regulations are affecting your port operations and development plans?"</li>
                  <li className="mb-2">"What are your current and projected cargo handling requirements?"</li>
                  <li className="mb-2">"How are you addressing navigation safety concerns with increased traffic or larger vessels?"</li>
                </ul>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Maritime Sector Specializations</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Marine Warranty</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What is the critical path in your marine operations schedule?"</li>
                    <li className="mb-1">"How have you defined your operational environmental limits?"</li>
                    <li className="mb-1">"What contingency plans exist for weather downtime?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Clean Shipping</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What alternative fuel technologies are you considering?"</li>
                    <li className="mb-1">"How are you addressing IMO 2050 compliance in your fleet plans?"</li>
                    <li className="mb-1">"What operational efficiency measures have been most effective?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Superyachts</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What specific aspects of the vessel concern you most?"</li>
                    <li className="mb-1">"What maintenance history documentation is available?"</li>
                    <li className="mb-1">"What are your expectations for the vessel's operational profile?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="bg-yellow-50 p-3 rounded mt-4">
              <h4 className="font-medium text-yellow-800 mb-1">Strategic Notes for Maritime Sector</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Balance technical questions with operational reality understanding</li>
                <li className="mb-1">When dealing with marine casualties, maintain professional objectivity while gathering all facts</li>
                <li className="mb-1">For port and harbor clients, focus on long-term planning and future-proofing</li>
                <li className="mb-1">Connect decarbonization questions to practical implementation steps</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-medium text-blue-600 mb-2">Oil & Gas Sector</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Asset Integrity & Operations</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What are your primary concerns regarding the structural integrity of your offshore assets?"</li>
                    <li className="mb-2">"How are you currently managing your asset inspection and maintenance programs?"</li>
                    <li className="mb-2">"What operational challenges are most significantly impacting your production efficiency?"</li>
                    <li className="mb-2">"What is your current approach to life extension of aging infrastructure?"</li>
                    <li className="mb-2">"How are you balancing operational necessities with your energy transition goals?"</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Marine Operations & Installation</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What are the key schedule drivers for your upcoming marine operations campaign?"</li>
                    <li className="mb-2">"What specific vessel or equipment constraints are influencing your installation methodology?"</li>
                    <li className="mb-2">"How have you accounted for metocean conditions in your operational planning?"</li>
                    <li className="mb-2">"What interfaces between different contractors present the greatest risk to your operations?"</li>
                    <li className="mb-2">"How are you approaching your marine warranty survey requirements for these operations?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Project Development & Engineering</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2">"What are the key technical uncertainties that could impact your project economics?"</li>
                  <li className="mb-2">"How are you approaching the balance between CAPEX optimization and operational flexibility?"</li>
                  <li className="mb-2">"What design standards or specifications are governing your engineering work?"</li>
                  <li className="mb-2">"How are you incorporating emissions reduction technologies into your project design?"</li>
                  <li className="mb-2">"What technical interfaces between different project elements present the greatest integration challenges?"</li>
                </ul>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Oil & Gas Specializations</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Upstream</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What reservoir challenges are affecting production performance?"</li>
                    <li className="mb-1">"How are you addressing well integrity management?"</li>
                    <li className="mb-1">"What subsurface uncertainties concern you most?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Midstream Pipelines</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What seabed conditions present the greatest pipeline design challenges?"</li>
                    <li className="mb-1">"How are you addressing free span management?"</li>
                    <li className="mb-1">"What third-party interface risks exist along the route?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Decommissioning</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What is driving your decommissioning strategy and timing?"</li>
                    <li className="mb-1">"How are you approaching infrastructure removal vs. repurposing?"</li>
                    <li className="mb-1">"What well abandonment challenges do you anticipate?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="bg-yellow-50 p-3 rounded mt-4">
              <h4 className="font-medium text-yellow-800 mb-1">Strategic Notes for Oil & Gas Sector</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Connect asset integrity discussions to safety and environmental performance</li>
                <li className="mb-1">Link traditional operations questions to energy transition opportunities</li>
                <li className="mb-1">For marine operations, focus on risk identification and practical mitigation measures</li>
                <li className="mb-1">Be sensitive to commercial considerations while gathering technical information</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Cross-Sector Technical Questioning Templates</h2>
        
        <div className="mb-5">
          <h3 className="text-lg font-medium text-blue-600 mb-2">Technical Due Diligence</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Design & Engineering Assessment</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What design codes and standards have been applied to this project?"</li>
                    <li className="mb-2">"How have the site-specific conditions been incorporated into the design?"</li>
                    <li className="mb-2">"What independent verification of the design has been completed to date?"</li>
                    <li className="mb-2">"What are the key design assumptions that would most significantly impact project viability if changed?"</li>
                    <li className="mb-2">"How have lessons learned from similar projects been incorporated into this design?"</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Technical Risk Evaluation</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What formal risk assessment processes have been applied to this project?"</li>
                    <li className="mb-2">"What are the top technical risks identified in your risk register?"</li>
                    <li className="mb-2">"How have you quantified the potential impact of these risks?"</li>
                    <li className="mb-2">"What mitigation measures have been developed for each key risk?"</li>
                    <li className="mb-2">"What contingency provisions have been made in the schedule and budget for technical risks?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Technology Assessment</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2">"What is the technology readiness level (TRL) of the key components in this project?"</li>
                  <li className="mb-2">"What operational track record exists for this technology in similar applications?"</li>
                  <li className="mb-2">"What technology qualification or certification has been completed?"</li>
                  <li className="mb-2">"How have supply chain considerations influenced technology selection?"</li>
                  <li className="mb-2">"What operational and maintenance implications does this technology choice have?"</li>
                </ul>
              </div>
            </div>
            <div className="bg-yellow-50 p-3 rounded mt-4">
              <h4 className="font-medium text-yellow-800 mb-1">Strategic Notes</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Balance technical depth with commercial understanding in due diligence contexts</li>
                <li className="mb-1">Maintain professional objectivity while identifying potential issues</li>
                <li className="mb-1">Focus questions on areas with highest potential impact on project success</li>
                <li className="mb-1">Adapt technical language to audience expertise level</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-medium text-blue-600 mb-2">Energy Transition & Sustainability</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Decarbonization Strategy</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What are your organization's specific carbon reduction targets and timeframes?"</li>
                    <li className="mb-2">"How have you prioritized different decarbonization opportunities in your operations?"</li>
                    <li className="mb-2">"What baseline emissions assessment have you completed for your assets or operations?"</li>
                    <li className="mb-2">"How are you approaching the challenge of scope 3 emissions in your value chain?"</li>
                    <li className="mb-2">"What are the key technical barriers to implementing your decarbonization roadmap?"</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Technology Implementation</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2">"What alternative energy or low-carbon technologies are you considering for your operations?"</li>
                    <li className="mb-2">"How are you evaluating the technical and economic feasibility of these technologies?"</li>
                    <li className="mb-2">"What pilot projects have you implemented to test decarbonization solutions?"</li>
                    <li className="mb-2">"How are you addressing the integration challenges of new energy technologies?"</li>
                    <li className="mb-2">"What operational changes would be required to implement these technologies?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Specific Energy Transition Areas</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Hydrogen & Alternative Fuels</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What hydrogen production pathways are you considering?"</li>
                    <li className="mb-1">"What storage and transportation solutions are in your plan?"</li>
                    <li className="mb-1">"How are you addressing safety and regulatory requirements?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Electrification</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"Which operational systems are priorities for electrification?"</li>
                    <li className="mb-1">"What power supply constraints affect your electrification plans?"</li>
                    <li className="mb-1">"How are you addressing equipment conversion challenges?"</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Carbon Capture</h5>
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-1">"What emission sources are most suitable for CCUS in your operations?"</li>
                    <li className="mb-1">"What capture technologies align with your operational profile?"</li>
                    <li className="mb-1">"How are you addressing transport and storage challenges?"</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="bg-yellow-50 p-3 rounded mt-4">
              <h4 className="font-medium text-yellow-800 mb-1">Strategic Notes</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Balance technical feasibility questions with commercial viability considerations</li>
                <li className="mb-1">Connect decarbonization discussions to ABL Group's energy transition expertise</li>
                <li className="mb-1">Adapt questioning to client's stage in energy transition journey</li>
                <li className="mb-1">Listen for opportunities to introduce ABL Group's cross-sector experience</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Questioning Techniques & Best Practices</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-blue-600 mb-2">Effective Questioning Techniques</h3>
              <div className="bg-white p-3 rounded border border-gray-200">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="p-2 text-left">Technique</th>
                      <th className="p-2 text-left">Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Technical Funneling</td>
                      <td className="p-2">Start with broad questions about project context, then progressively narrow to specific technical details</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Stakeholder Perspective</td>
                      <td className="p-2">Ask about how different stakeholders view the technical challenges or requirements</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Technical Quantification</td>
                      <td className="p-2">Ask for numerical ratings of technical risks or confidence levels to establish priorities</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Solution Projection</td>
                      <td className="p-2">Ask what an ideal solution would look like if all constraints were removed</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-medium">Technical Appreciative Inquiry</td>
                      <td className="p-2">Focus on what's working well technically before exploring challenges</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div>
              <h3 className="font-medium text-blue-600 mb-2">Common Pitfalls to Avoid</h3>
              <div className="bg-white p-3 rounded border border-gray-200">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="p-2 text-left">Pitfall</th>
                      <th className="p-2 text-left">Better Alternative</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Technical overload</td>
                      <td className="p-2">Break complex technical topics into smaller, more manageable questions</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Leading with solutions</td>
                      <td className="p-2">Focus on understanding the problem fully before suggesting approaches</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Closed questions too early</td>
                      <td className="p-2">Start with open exploration before narrowing to specifics</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Excessive jargon</td>
                      <td className="p-2">Adapt technical language to client's expertise level</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-medium">Dismissing concerns</td>
                      <td className="p-2">Acknowledge all client concerns as valid before exploring solutions</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <h3 className="font-medium text-blue-600 mb-2">Adapting Questions to Client Roles</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-2 text-left">Client Role</th>
                    <th className="p-2 text-left">Questioning Approach</th>
                    <th className="p-2 text-left">Example</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-200">
                    <td className="p-2 font-medium">Technical Specialists</td>
                    <td className="p-2">Use precise technical language; focus on detailed specifications and methodology</td>
                    <td className="p-2 italic">"What specific fatigue analysis methodology are you employing for the mooring analysis?"</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="p-2 font-medium">Project Managers</td>
                    <td className="p-2">Balance technical and project considerations; focus on interfaces, schedules, and risk management</td>
                    <td className="p-2 italic">"How are the technical work packages sequenced to manage interdependencies?"</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="p-2 font-medium">Executive Decision Makers</td>
                    <td className="p-2">Connect technical details to strategic outcomes; focus on business impacts and ROI</td>
                    <td className="p-2 italic">"How would this technical approach affect your long-term operational flexibility?"</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Operational Teams</td>
                    <td className="p-2">Focus on practical implementation; emphasize maintenance, training, and real-world constraints</td>
                    <td className="p-2 italic">"What operational challenges do you anticipate when implementing this system?"</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Client Meeting Preparation Worksheet</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="bg-white p-4 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-3 text-center">ABL Group Client Meeting Question Planning</h3>
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">1. Meeting Objective & Context</h4>
              <div className="border border-gray-300 p-2 h-12 rounded-md"></div>
            </div>
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">2. Client Information</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <p className="text-sm text-gray-700 mb-1">Client Sector & Subsector</p>
                  <div className="border border-gray-300 p-2 h-10 rounded-md"></div>
                </div>
                <div>
                  <p className="text-sm text-gray-700 mb-1">Client's Stage in Project Lifecycle</p>
                  <div className="border border-gray-300 p-2 h-10 rounded-md"></div>
                </div>
              </div>
            </div>
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">3. Key Question Planning</h4>
              <table className="min-w-full text-sm border border-gray-300">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-2 text-left border-b border-gray-300">Topic Area</th>
                    <th className="p-2 text-left border-b border-gray-300">Planned Questions</th>
                    <th className="p-2 text-left border-b border-gray-300">Information Needed</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-300">
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 h-12"></td>
                  </tr>
                  <tr className="border-b border-gray-300">
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 h-12"></td>
                  </tr>
                  <tr className="border-b border-gray-300">
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 h-12"></td>
                  </tr>
                  <tr>
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 border-r border-gray-300 h-12"></td>
                    <td className="p-2 h-12"></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">4. Potential Follow-up Questions</h4>
              <div className="border border-gray-300 p-2 h-16 rounded-md"></div>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 mb-2">5. Post-Meeting Notes</h4>
              <div className="border border-gray-300 p-2 h-16 rounded-md"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="text-xs text-gray-500 mt-6 text-center">
        ABL Group Effective Questioning Templates • Driving Sustainability in Energy and Oceans • Last Updated: May 2025
      </div>
    </div>
  );
};

export default EffectiveQuestioning;
