import React from 'react';

const ClientCommunicationHandbook = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-blue-800 mb-1">ABL Group Client Communication Handbook</h1>
        <p className="text-gray-600 italic">A Comprehensive Guide for Professional Client Engagement</p>
      </div>
      
      <div className="bg-blue-50 p-4 rounded-md mb-6">
        <h2 className="text-lg font-semibold text-blue-700 mb-2">Purpose & Scope</h2>
        <p className="text-gray-700">This handbook provides standardized communication guidelines and best practices for all client-facing professionals across ABL Group companies. It ensures consistency, professionalism, and effectiveness in all client interactions, helping build strong relationships and deliver exceptional service across our renewables, maritime, and oil & gas sectors.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 text-sm">
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">Who Should Use This Guide</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Technical Consultants</li>
              <li>Project Managers</li>
              <li>Business Development</li>
              <li>Marine Surveyors</li>
              <li>Engineering Specialists</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">ABL Group Values</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li><strong>Safety:</strong> Our top priority</li>
              <li><strong>Technical Excellence:</strong> Quality in all we do</li>
              <li><strong>Collaboration:</strong> Teamwork across disciplines</li>
              <li><strong>Innovation:</strong> Finding better solutions</li>
              <li><strong>Truth:</strong> Seek the truth in all we do</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">Communication Channels</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Client meetings & presentations</li>
              <li>Technical reports & deliverables</li>
              <li>Email correspondence</li>
              <li>Virtual meetings & webinars</li>
              <li>Project management tools</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Communication Standards & Guidelines</h2>
        
        <div className="mb-5">
          <h3 className="text-lg font-medium text-blue-600 mb-2">ABL Group Brand Voice & Tone</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Professional Tone</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2"><strong>Expert yet accessible</strong> – Demonstrate technical expertise without unnecessary jargon</li>
                    <li className="mb-2"><strong>Confident but humble</strong> – Project competence while remaining open to client input</li>
                    <li className="mb-2"><strong>Global partner, local expert</strong> – Leverage worldwide knowledge with regional understanding</li>
                    <li className="mb-2"><strong>Solutions-oriented</strong> – Focus on practical approaches to client challenges</li>
                    <li className="mb-2"><strong>Trusted advisor</strong> – Build relationships through honesty and technical integrity</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Language Guidelines</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <div className="mb-3">
                    <h5 className="font-medium text-gray-700 mb-1">DO</h5>
                    <ul className="list-disc pl-5 text-gray-700 text-sm">
                      <li className="mb-1">Use clear, concise language with technical precision</li>
                      <li className="mb-1">Adapt terminology to client's technical knowledge level</li>
                      <li className="mb-1">Employ active voice for clarity in technical explanations</li>
                      <li className="mb-1">Provide specific examples to illustrate technical concepts</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">DON'T</h5>
                    <ul className="list-disc pl-5 text-gray-700 text-sm">
                      <li className="mb-1">Use excessive technical jargon with non-specialist audiences</li>
                      <li className="mb-1">Include vague statements or unsubstantiated claims</li>
                      <li className="mb-1">Overuse abbreviations without proper introduction</li>
                      <li className="mb-1">Make commitments that exceed project scope or capabilities</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Sector-Specific Adaptations</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="p-2 text-left">Client Sector</th>
                      <th className="p-2 text-left">Communication Adaptation</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Renewables</td>
                      <td className="p-2">Focus on innovative solutions; emphasize sustainability impact; reference experience with similar technologies; highlight track record in energy transition</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Maritime</td>
                      <td className="p-2">Emphasize ABL's maritime heritage and independent assessment capability; focus on safety and risk mitigation; reference marine regulatory expertise</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-2 font-medium">Oil & Gas</td>
                      <td className="p-2">Balance operational excellence with energy transition support; emphasize asset integrity and optimization; reference industry experience; include safety emphasis</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-medium">Cross-Sector/Energy Transition</td>
                      <td className="p-2">Highlight ABL Group's unique position supporting traditional and renewable energy; emphasize transferable expertise; focus on pragmatic transition pathways</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-medium text-blue-600 mb-2">Response Times & Availability</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Standard Response Times</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <table className="min-w-full text-sm">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="p-2 text-left">Communication Type</th>
                        <th className="p-2 text-left">Target Response Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-gray-200">
                        <td className="p-2">Client email - Standard</td>
                        <td className="p-2">Same business day or within 24 hours</td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="p-2">Client email - Urgent</td>
                        <td className="p-2">Within 4 business hours</td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="p-2">Client voicemail</td>
                        <td className="p-2">Same business day</td>
                      </tr>
                      <tr className="border-b border-gray-200">
                        <td className="p-2">Meeting request</td>
                        <td className="p-2">Within 24 hours</td>
                      </tr>
                      <tr>
                        <td className="p-2">Marine casualty response</td>
                        <td className="p-2">Immediate acknowledgment (24/7)</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Availability Management</h4>
                <div className="bg-white p-3 rounded border border-gray-200 text-sm">
                  <div className="mb-3">
                    <h5 className="font-medium text-gray-700 mb-1">Out-of-Office Protocol</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Set automatic email replies with dates of absence</li>
                      <li className="mb-1">Include alternative contact person with their details</li>
                      <li className="mb-1">Notify key clients directly before extended absences</li>
                      <li className="mb-1">Ensure clear handover of critical client matters</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">Emergency Response Availability</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Maritime emergencies: Use regional 24/7 emergency numbers</li>
                      <li className="mb-1">London: +44 203 142 4350</li>
                      <li className="mb-1">New York: +1 212 587 9300</li>
                      <li className="mb-1">Singapore: +65 6224 9200</li>
                      <li className="mb-1">Dubai: +971 58 5047014</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Managing Client Expectations</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">Setting Clear Expectations</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Define deliverables, timelines, and milestones clearly in proposals</li>
                      <li className="mb-1">Establish communication protocols at project kickoff</li>
                      <li className="mb-1">Document key decisions and action items after meetings</li>
                      <li className="mb-1">Be transparent about dependencies and constraints</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">When You Can't Respond Immediately</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Send a brief acknowledgment of receipt</li>
                      <li className="mb-1">Provide a specific timeframe for full response</li>
                      <li className="mb-1">Copy a colleague who may be able to assist</li>
                      <li className="mb-1">Follow up as promised without fail</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Technical Communication Guidelines</h2>
        
        <div className="mb-5">
          <h3 className="text-lg font-medium text-blue-600 mb-2">Technical Reports & Deliverables</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Document Structure</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2"><strong>Executive Summary</strong> – Key findings and recommendations in non-technical language</li>
                    <li className="mb-2"><strong>Introduction</strong> – Clear context, scope, and objectives</li>
                    <li className="mb-2"><strong>Methodology</strong> – Technical approach with appropriate detail</li>
                    <li className="mb-2"><strong>Findings/Analysis</strong> – Organized by key themes or technical areas</li>
                    <li className="mb-2"><strong>Recommendations</strong> – Clear, actionable, and prioritized</li>
                    <li className="mb-2"><strong>Appendices</strong> – Technical details, data, and supporting information</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Quality Standards</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2"><strong>Technical Accuracy</strong> – All data, calculations, and conclusions verified</li>
                    <li className="mb-2"><strong>Clarity</strong> – Logical flow with appropriate technical language</li>
                    <li className="mb-2"><strong>Completeness</strong> – All objectives addressed; no gaps in analysis</li>
                    <li className="mb-2"><strong>Consistency</strong> – Common terminology and units throughout</li>
                    <li className="mb-2"><strong>Visual Presentation</strong> – Professional formatting with appropriate graphics</li>
                    <li className="mb-2"><strong>ABL Group Branding</strong> – Correct templates, logos, and styling</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Review Process</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">Technical Review</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Technical accuracy check</li>
                      <li className="mb-1">Methodology validation</li>
                      <li className="mb-1">Analysis verification</li>
                      <li className="mb-1">Engineering calculations check</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">Quality Review</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Document structure check</li>
                      <li className="mb-1">Clarity and flow assessment</li>
                      <li className="mb-1">Formatting consistency</li>
                      <li className="mb-1">Spelling and grammar check</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">Principal Review</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Alignment with client objectives</li>
                      <li className="mb-1">Commercial sensitivity check</li>
                      <li className="mb-1">Strategic advice validation</li>
                      <li className="mb-1">Final approval before issue</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-medium text-blue-600 mb-2">Client Meetings & Presentations</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Meeting Preparation</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2"><strong>Research</strong> – Review client background, project history, and key concerns</li>
                    <li className="mb-2"><strong>Objectives</strong> – Define clear goals for the meeting</li>
                    <li className="mb-2"><strong>Agenda</strong> – Prepare and share structured agenda in advance</li>
                    <li className="mb-2"><strong>Materials</strong> – Prepare concise, well-designed presentation materials</li>
                    <li className="mb-2"><strong>Team Coordination</strong> – Assign roles and align on key messages</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-blue-600 mb-2">Presentation Best Practices</h4>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <ul className="list-disc pl-5 text-gray-700 text-sm">
                    <li className="mb-2"><strong>Structure</strong> – Begin with key messages; follow logical flow</li>
                    <li className="mb-2"><strong>Visuals</strong> – Use clear graphics; limit text on slides</li>
                    <li className="mb-2"><strong>Technical Content</strong> – Adapt to audience's technical expertise</li>
                    <li className="mb-2"><strong>Engagement</strong> – Encourage questions and discussion</li>
                    <li className="mb-2"><strong>Time Management</strong> – Respect scheduled time frames</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-medium text-blue-600 mb-2">Follow-Up Protocol</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">Post-Meeting Documentation</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Meeting minutes with key discussion points</li>
                      <li className="mb-1">Documented decisions and agreed actions</li>
                      <li className="mb-1">Clear assignment of responsibilities</li>
                      <li className="mb-1">Confirmation of next steps and timelines</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-700 mb-1">Communication Timeline</h5>
                    <ul className="list-disc pl-5 text-gray-700">
                      <li className="mb-1">Thank you email within 24 hours</li>
                      <li className="mb-1">Meeting minutes within 2 business days</li>
                      <li className="mb-1">Follow-up on action items as committed</li>
                      <li className="mb-1">Status updates at agreed frequency</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Email Communication Templates</h2>
        
        <div className="mb-5">
          <h3 className="text-lg font-medium text-blue-600 mb-2">Project Communication Templates</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="mb-4">
              <h4 className="font-medium text-blue-600 mb-2">New Project Introduction</h4>
              <div className="bg-gray-50 p-3 rounded border border-gray-200 mb-4 text-sm">
                <p className="mb-1"><strong>Subject:</strong> ABL Group - [Project Name] - Project Initiation and Next Steps</p>
                <p className="mb-1"><strong>Dear [Client Name],</strong></p>
                <p className="mb-2">Thank you for selecting ABL Group to support [specific project/service]. We are committed to delivering exceptional technical service for your [project type] and look forward to a successful partnership.</p>
                <p className="mb-2">To ensure a smooth project initiation, I would like to share our immediate next steps:</p>
                <ul className="list-disc pl-5 mb-2">
                  <li>Project Kickoff Meeting: Scheduled for [date/time] via [platform]</li>
                  <li>Data Requirements: Please see the attached checklist of information needed to begin our analysis</li>
                  <li>Key Contact Details: Your project team details are provided below</li>
                </ul>
                <p className="mb-2">Your ABL Group project team consists of:</p>
                <ul className="list-disc pl-5 mb-2">
                  <li>[Name] - Project Manager (primary contact) - [email] - [phone]</li>
                  <li>[Name] - Technical Lead - [email]</li>
                  <li>[Name] - Specialist Consultant - [email]</li>
                </ul>
                <p className="mb-2">Please feel free to contact me directly with any questions or requirements. We are committed to delivering technical excellence and look forward to supporting your project objectives.</p>
                <p className="mb-2">Best regards,</p>
                <p>[Your Name]<br />
                [Your Position]<br />
                ABL Group<br />
                [Your Email] | [Your Phone]</p>
              </div>
            </div>
            
            <div className="mb-4">
              <h4 className="font-medium text-blue-600 mb-2">Technical Deliverable Submission</h4>
              <div className="bg-gray-50 p-3 rounded border border-gray-200 mb-4 text-sm">
                <p className="mb-1"><strong>Subject:</strong> ABL Group - [Project Name] - [Deliverable Name] Submission</p>
                <p className="mb-1"><strong>Dear [Client Name],</strong></p>
                <p className="mb-2">I am pleased to submit the [Deliverable Name] for the [Project Name] as per our agreed scope of work. This deliverable represents the completion of [project phase/milestone] and addresses the key technical requirements outlined in our project plan.</p>
                <p className="mb-2">Key aspects of this submission include:</p>
                <ul className="list-disc pl-5 mb-2">
                  <li>[Key technical finding or recommendation 1]</li>
                  <li>[Key technical finding or recommendation 2]</li>
                  <li>[Key technical finding or recommendation 3]</li>
                </ul>
                <p className="mb-2">The complete deliverable is attached to this email and includes:</p>
                <ul className="list-disc pl-5 mb-2">
                  <li>[Document 1] - Main report with executive summary and detailed analysis</li>
                  <li>[Document 2] - Technical appendices with supporting calculations</li>
                  <li>[Document 3] - Presentation slides summarizing key findings</li>
                </ul>
                <p className="mb-2">We would welcome the opportunity to discuss this deliverable with you and address any questions you may have. Please let me know if you would like to schedule a review meeting.</p>
                <p className="mb-2">Our next steps in the project will be [brief description of upcoming activities and timeline].</p>
                <p className="mb-2">Thank you for your continued collaboration.</p>
                <p className="mb-2">Best regards,</p>
                <p>[Your Name]<br />
                [Your Position]<br />
                ABL Group<br />
                [Your Email] | [Your Phone]</p>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Project Status Update</h4>
              <div className="bg-gray-50 p-3 rounded border border-gray-200 text-sm">
                <p className="mb-1"><strong>Subject:</strong> ABL Group - [Project Name] - Weekly Status Update [Date]</p>
                <p className="mb-1"><strong>Dear [Client Name],</strong></p>
                <p className="mb-2">Please find below the weekly status update for [Project Name]:</p>
                <p className="mb-1"><strong>Accomplishments This Week:</strong></p>
                <ul className="list-disc pl-5 mb-2">
                  <li>Completed [specific technical task/milestone]</li>
                  <li>Conducted [analysis/review/meeting] for [project component]</li>
                  <li>Initiated [new project phase/activity]</li>
                </ul>
                <p className="mb-1"><strong>Planned Activities Next Week:</strong></p>
                <ul className="list-disc pl-5 mb-2">
                  <li>[Technical task 1] - [Expected completion date]</li>
                  <li>[Technical task 2] - [Expected completion date]</li>
                  <li>[Technical task 3] - [Expected completion date]</li>
                </ul>
                <p className="mb-1"><strong>Project Status Summary:</strong></p>
                <ul className="list-disc pl-5 mb-2">
                  <li>Schedule: [On track / Minor delay / Significant delay]</li>
                  <li>Budget: [Within budget / Minor variance / Significant variance]</li>
                  <li>Risks/Issues: [Description of any new or evolving risks or issues]</li>
                </ul>
                <p className="mb-1"><strong>Action Items:</strong></p>
                <ul className="list-disc pl-5 mb-2">
                  <li>[Action item 1] - [Owner] - [Due date]</li>
                  <li>[Action item 2] - [Owner] - [Due date]</li>
                </ul>
                <p className="mb-2">Please let me know if you have any questions or require additional information.</p>
                <p className="mb-2">Best regards,</p>
                <p>[Your Name]<br />
                [Your Position]<br />
                ABL Group<br />
                [Your Email] | [Your Phone]</p>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-medium text-blue-600 mb-2">Business Development Templates</h3>
          <div className="border border-gray-300 rounded-md p-4">
            <div className="mb-4">
              <h4 className="font-medium text-blue-600 mb-2">Initial Contact/Follow-up</h4>
              <div className="bg-gray-50 p-3 rounded border border-gray-200 mb-4 text-sm">
                <p className="mb-1"><strong>Subject:</strong> ABL Group - Specialized [Sector] Consultancy Services</p>
                <p className="mb-1"><strong>Dear [Prospect Name],</strong></p>
                <p className="mb-2">Thank you for our conversation at [event/meeting] regarding [specific topic discussed]. As promised, I'm following up with additional information about how ABL Group can support [company name] with [specific challenge/opportunity].</p>
                <p className="mb-2">ABL Group is a leading global energy and marine consultancy with expertise in [relevant sector]. Our team has extensive experience helping organizations like yours address challenges related to [specific area of interest].</p>
                <p className="mb-2">Based on our discussion, I believe the following services would be particularly relevant to your needs:</p>
                <ul className="list-disc pl-5 mb-2">
                  <li>[Service 1] - [Brief description of benefit]</li>
                  <li>[Service 2] - [Brief description of benefit]</li>
                  <li>[Service 3] - [Brief description of benefit]</li>
                </ul>
                <p className="mb-2">We have successfully delivered similar solutions for clients including [reference client examples]. I've attached a brief overview of a recent case study that illustrates our approach and results achieved.</p>
                <p className="mb-2">I would welcome the opportunity to discuss how we might support your specific requirements. Would you be available for a brief call next week to explore this further?</p>
                <p className="mb-2">Best regards,</p>
                <p>[Your Name]<br />
                [Your Position]<br />
                ABL Group<br />
                [Your Email] | [Your Phone]</p>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Proposal Follow-up</h4>
              <div className="bg-gray-50 p-3 rounded border border-gray-200 text-sm">
                <p className="mb-1"><strong>Subject:</strong> ABL Group - [Proposal Name] - Follow-up</p>
                <p className="mb-1"><strong>Dear [Client Name],</strong></p>
                <p className="mb-2">I hope this email finds you well. I'm writing to follow up on the proposal we submitted on [date] for [project/service description].</p>
                <p className="mb-2">Our team is excited about the opportunity to work with [company name] on this important initiative. We believe our approach, which emphasizes [key differentiator/value proposition], will provide significant value in addressing your [specific challenge/requirement].</p>
                <p className="mb-2">Since submitting our proposal, we've continued to refine our understanding of the challenges and opportunities in [relevant sector/technology area]. We would be happy to share additional insights or address any questions you may have about our proposed approach, timeline, or team composition.</p>
                <p className="mb-2">Are you available for a brief discussion in the coming days to review any aspects of our proposal? Alternatively, if there is any additional information we can provide to support your decision-making process, please let me know.</p>
                <p className="mb-2">Thank you for considering ABL Group for this important work. We look forward to the possibility of collaborating with your team.</p>
                <p className="mb-2">Best regards,</p>
                <p>[Your Name]<br />
                [Your Position]<br />
                ABL Group<br />
                [Your Email] | [Your Phone]</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Cross-Cultural Communication</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <p className="text-gray-700 mb-4">As a global organization with offices in 40+ countries and clients worldwide, ABL Group professionals must be sensitive to cultural differences in communication. The following guidelines will help navigate cross-cultural interactions effectively:</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="bg-white p-3 rounded border border-gray-200">
              <h4 className="font-medium text-blue-600 mb-2">Communication Style</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Recognize direct vs. indirect communication preferences</li>
                <li className="mb-1">Adapt formality level to cultural expectations</li>
                <li className="mb-1">Be aware of differences in pace and turn-taking</li>
                <li className="mb-1">Consider cultural attitudes toward disagreement</li>
                <li className="mb-1">Recognize variations in use of silence</li>
              </ul>
            </div>
            <div className="bg-white p-3 rounded border border-gray-200">
              <h4 className="font-medium text-blue-600 mb-2">Non-Verbal Communication</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Be aware of cultural differences in eye contact</li>
                <li className="mb-1">Understand appropriate physical distance</li>
                <li className="mb-1">Recognize cultural meanings of gestures</li>
                <li className="mb-1">Be mindful of facial expressions</li>
                <li className="mb-1">Consider cultural norms for greetings</li>
              </ul>
            </div>
            <div className="bg-white p-3 rounded border border-gray-200">
              <h4 className="font-medium text-blue-600 mb-2">Virtual Meetings</h4>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li className="mb-1">Be mindful of time zone considerations</li>
                <li className="mb-1">Allow for potential language barriers</li>
                <li className="mb-1">Provide written materials in advance when possible</li>
                <li className="mb-1">Check for understanding more frequently</li>
                <li className="mb-1">Be explicit about expectations and action items</li>
              </ul>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded border border-gray-200 mb-4">
            <h4 className="font-medium text-blue-600 mb-2">Regional Communication Considerations</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-2 text-left">Region</th>
                    <th className="p-2 text-left">Key Communication Considerations</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-200">
                    <td className="p-2 font-medium">Europe</td>
                    <td className="p-2">Varies significantly by country; Northern European cultures tend to be more direct, while Southern European cultures may emphasize relationship building; formality levels vary considerably</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="p-2 font-medium">Middle East</td>
                    <td className="p-2">Emphasis on relationship building; avoid rushing to business matters; respect for hierarchy; preference for face-to-face meetings; importance of hospitality rituals</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="p-2 font-medium">Asia Pacific</td>
                    <td className="p-2">Indirect communication styles often preferred; saving "face" important; hierarchical relationships; group consensus valued; patience in decision-making processes</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="p-2 font-medium">Americas</td>
                    <td className="p-2">U.S. and Canada tend toward direct communication and quick business focus; Latin American cultures often emphasize relationship building and may have more flexible approach to time</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Africa</td>
                    <td className="p-2">Highly diverse communication styles; relationship building important; respect for age and experience; storytelling traditions; awareness of colonial history impacts</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="bg-yellow-50 p-3 rounded">
            <h4 className="font-medium text-yellow-800 mb-1">Best Practices for Global Communication</h4>
            <ul className="list-disc pl-5 text-gray-700 text-sm">
              <li className="mb-1">Research client's cultural background before important meetings</li>
              <li className="mb-1">Consult local ABL colleagues for cultural insights when working in unfamiliar regions</li>
              <li className="mb-1">Avoid idioms, slang, and culturally-specific references</li>
              <li className="mb-1">Be patient and ask clarifying questions rather than making assumptions</li>
              <li className="mb-1">Remember that ABL's technical expertise must be delivered with cultural intelligence</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Communication in Crisis Situations</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <p className="text-gray-700 mb-4">ABL Group's marine casualty response and other critical services require special communication approaches during crisis situations:</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Marine Casualty & Emergency Response</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2"><strong>Immediate Acknowledgment</strong> – Confirm receipt of request and mobilization timeline</li>
                  <li className="mb-2"><strong>Clear Information Gathering</strong> – Structured approach to collecting essential details</li>
                  <li className="mb-2"><strong>Regular Updates</strong> – Established cadence for situation reports</li>
                  <li className="mb-2"><strong>Documentation</strong> – Meticulous recording of observations and actions</li>
                  <li className="mb-2"><strong>Factual Communication</strong> – Focus on verified information, clearly separate facts from opinions</li>
                  <li className="mb-2"><strong>Chain of Command</strong> – Clear communication protocols and approval processes</li>
                </ul>
              </div>
            </div>
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Media & External Communication</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2"><strong>Single Point of Contact</strong> – All external communications channeled through designated spokesperson</li>
                  <li className="mb-2"><strong>Coordination with Client</strong> – Align on messaging and approval processes</li>
                  <li className="mb-2"><strong>Factual Statements</strong> – Provide only verified information</li>
                  <li className="mb-2"><strong>Confidentiality</strong> – Strict protection of sensitive information</li>
                  <li className="mb-2"><strong>No Speculation</strong> – Avoid assumptions about causes or outcomes</li>
                  <li className="mb-2"><strong>Legal Review</strong> – Legal approval for public statements when appropriate</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="bg-red-50 p-3 rounded mt-4">
            <h4 className="font-medium text-red-800 mb-1">Crisis Communication Protocol</h4>
            <ol className="list-decimal pl-5 text-gray-700 text-sm">
              <li className="mb-1">Notify appropriate ABL Group crisis management team immediately</li>
              <li className="mb-1">Establish communication chain and reporting structure</li>
              <li className="mb-1">Implement information gathering and verification process</li>
              <li className="mb-1">Set up secure communication channels as needed</li>
              <li className="mb-1">Brief all team members on communication protocols</li>
              <li className="mb-1">Coordinate with client's crisis communication team</li>
              <li className="mb-1">Document all communications meticulously</li>
              <li className="mb-1">Refer media inquiries to designated spokesperson</li>
            </ol>
          </div>
        </div>
      </div>
      
      <div className="text-xs text-gray-500 mt-6 text-center">
        ABL Group Client Communication Handbook • Driving Sustainability in Energy and Oceans • Last Updated: May 2025
      </div>
    </div>
  );
};

export default ClientCommunicationHandbook;
