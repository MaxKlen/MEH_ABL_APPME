// Best practices and industry standards content for sales and business development
document.addEventListener('DOMContentLoaded', function() {
    // Extend the existing moduleData with more comprehensive content
    const bestPracticesContent = {
        'client-communication': {
            sections: [
                {
                    title: 'Initial Client Contact Strategies',
                    content: `
                        <p>The first interaction with a potential client sets the tone for the entire business relationship. Follow these key principles to make a positive first impression:</p>
                        <h5>Research-Based Approach</h5>
                        <ul>
                            <li>Research the client's business, recent projects, and industry challenges before making contact</li>
                            <li>Identify specific pain points relevant to their operations that ABL Group can address</li>
                            <li>Prepare 3-5 thoughtful questions that demonstrate your understanding of their business</li>
                        </ul>
                        
                        <h5>Initial Contact Best Practices</h5>
                        <ul>
                            <li>Personalize your approach based on the client's industry and position</li>
                            <li>Lead with value, not sales pitch - focus on how ABL Group has solved similar problems</li>
                            <li>Use the "Problem-Agitate-Solve" framework to structure your initial message</li>
                            <li>Provide a clear, specific next step (e.g., 15-minute discovery call)</li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Industry Standard:</strong> According to RAIN Group's research, top-performing sales professionals spend 6+ hours researching prospects before initial contact, resulting in 94% higher engagement rates.
                        </div>
                    `
                },
                {
                    title: 'Building Rapport Techniques',
                    content: `
                        <p>Building rapport is essential for developing long-term client relationships. Use these evidence-based techniques to establish trust:</p>
                        
                        <h5>The Trust Equation</h5>
                        <p>Trust = (Credibility + Reliability + Intimacy) ÷ Self-Orientation</p>
                        <ul>
                            <li><strong>Credibility:</strong> Demonstrate expertise through case studies and technical knowledge</li>
                            <li><strong>Reliability:</strong> Follow through on commitments, respond promptly, be consistent</li>
                            <li><strong>Intimacy:</strong> Create safe space for open discussion of challenges and concerns</li>
                            <li><strong>Self-Orientation:</strong> Focus on client needs rather than your sales goals</li>
                        </ul>
                        
                        <h5>Mirroring and Matching Techniques</h5>
                        <ul>
                            <li>Match communication style (formal vs. casual, detailed vs. big picture)</li>
                            <li>Adapt to preferred communication channels and frequency</li>
                            <li>Use industry-specific terminology appropriately</li>
                            <li>Acknowledge and validate client perspectives before offering alternatives</li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Best Practice:</strong> Harvard Business Review research shows that successful relationship builders spend 18% more time discussing non-business topics to establish personal connection before diving into business matters.
                        </div>
                    `
                },
                {
                    title: 'Active Listening Skills',
                    content: `
                        <p>Use the HEAR framework to improve your active listening skills:</p>
                        
                        <h5>The HEAR Framework</h5>
                        <ul>
                            <li><strong>H</strong>alt - Stop talking and focus completely on the speaker</li>
                            <li><strong>E</strong>ngage - Show engagement through body language and verbal cues</li>
                            <li><strong>A</strong>nticipate - Listen for underlying needs and concerns</li>
                            <li><strong>R</strong>eplay - Summarize and reflect back what you've heard</li>
                        </ul>
                        
                        <h5>Advanced Listening Techniques</h5>
                        <ul>
                            <li><strong>Precision Questioning:</strong> Ask clarifying questions that reveal deeper needs</li>
                            <li><strong>Emotional Intelligence:</strong> Recognize and respond to emotional cues</li>
                            <li><strong>Silence Utilization:</strong> Become comfortable with pauses to allow deeper reflection</li>
                            <li><strong>Needs Mapping:</strong> Document explicit and implicit needs during conversations</li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Industry Standard:</strong> According to research by TOPO, sales professionals who practice structured active listening techniques achieve 32% higher close rates than those who don't.
                        </div>
                    `
                }
            ],
            resources: [
                {
                    title: 'Client Communication Handbook',
                    type: 'PDF',
                    url: '/downloads/sales-training/client-communication-handbook.pdf'
                },
                {
                    title: 'Effective Questioning Templates',
                    type: 'PDF',
                    url: '/downloads/sales-training/effective-questioning-templates.pdf'
                },
                {
                    title: 'Active Listening Workshop Materials',
                    type: 'PDF',
                    url: '/downloads/sales-training/active-listening-workshop.pdf'
                }
            ]
        },
        'technical-solution-selling': {
            sections: [
                {
                    title: 'Technical to Business Value Translation',
                    content: `
                        <p>Translating technical capabilities into business value is critical when selling complex solutions:</p>
                        
                        <h5>The Value Bridge Framework</h5>
                        <p>Follow this 4-step process to connect technical features to business outcomes:</p>
                        <ol>
                            <li><strong>Feature:</strong> Identify the technical capability or feature</li>
                            <li><strong>Function:</strong> Explain what this feature does in practical terms</li>
                            <li><strong>Benefit:</strong> Describe the direct benefit to the client's operations</li>
                            <li><strong>Value:</strong> Quantify the business impact (time/cost savings, risk reduction, revenue increase)</li>
                        </ol>
                        
                        <h5>Value Metrics by Industry</h5>
                        <p>Focus on these key metrics when presenting solutions to different sectors:</p>
                        <ul>
                            <li><strong>Oil & Gas:</strong> Operational efficiency, risk reduction, regulatory compliance, asset integrity</li>
                            <li><strong>Renewables:</strong> LCOE reduction, project timeline acceleration, environmental impact, grid integration</li>
                            <li><strong>Maritime:</strong> Vessel performance, operational safety, classification compliance, emissions reduction</li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Best Practice:</strong> According to Gartner research, technical solutions presented with quantified business value are 64% more likely to advance to the next stage in the sales process.
                        </div>
                    `
                },
                {
                    title: 'Solution Presentation Techniques',
                    content: `
                        <p>Use these proven techniques when presenting complex technical solutions:</p>
                        
                        <h5>The Situation-Complication-Resolution (SCR) Framework</h5>
                        <ul>
                            <li><strong>Situation:</strong> Establish the client's current state and business context</li>
                            <li><strong>Complication:</strong> Highlight specific challenges, risks, or missed opportunities</li>
                            <li><strong>Resolution:</strong> Present your solution with clear connection to the complications</li>
                        </ul>
                        
                        <h5>Technical Presentation Best Practices</h5>
                        <ul>
                            <li>Start with the business outcome, then explain the technical approach</li>
                            <li>Use visual aids to simplify complex concepts (diagrams, process flows)</li>
                            <li>Provide case studies with measurable results from similar implementations</li>
                            <li>Include implementation timeline and resource requirements</li>
                            <li>Address potential risks and mitigation strategies proactively</li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Industry Standard:</strong> Corporate Visions research shows that presentations that follow a problem-first structure are 30% more effective at driving decision-making than those that lead with solutions.
                        </div>
                    `
                },
                {
                    title: 'Handling Technical Objections',
                    content: `
                        <p>Technical objections require a structured approach to maintain credibility:</p>
                        
                        <h5>The LSCPA Objection Handling Framework</h5>
                        <ul>
                            <li><strong>L</strong>isten - Fully understand the objection without interrupting</li>
                            <li><strong>S</strong>ympathize - Acknowledge the concern as valid and important</li>
                            <li><strong>C</strong>larify - Ask questions to understand the specific technical concern</li>
                            <li><strong>P</strong>osition - Present your response with evidence and examples</li>
                            <li><strong>A</strong>gree - Establish next steps and confirm resolution</li>
                        </ul>
                        
                        <h5>Common Technical Objections in Energy & Marine Sectors</h5>
                        <p>Prepare responses for these frequently encountered objections:</p>
                        <ul>
                            <li>Concerns about new/unproven methodologies</li>
                            <li>Questions about regulatory compliance</li>
                            <li>Integration with existing systems/processes</li>
                            <li>Resource requirements and implementation timeline</li>
                            <li>Technical risk management approach</li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Best Practice:</strong> According to Forrester Research, sales professionals who document and practice responses to common technical objections achieve 28% higher win rates in complex sales situations.
                        </div>
                    `
                }
            ],
            resources: [
                {
                    title: 'Technical Solution Selling Playbook',
                    type: 'PDF',
                    url: '/downloads/sales-training/technical-solution-selling-playbook.pdf'
                },
                {
                    title: 'Value Quantification Templates',
                    type: 'Excel',
                    url: '/downloads/sales-training/value-quantification-templates.xlsx'
                },
                {
                    title: 'Technical Objection Response Guide',
                    type: 'PDF',
                    url: '/downloads/sales-training/technical-objection-response-guide.pdf'
                }
            ]
        },
        'lead-qualification': {
            sections: [
                {
                    title: 'Qualification Criteria',
                    content: `
                        <p>Use these industry-standard criteria to evaluate potential leads and opportunities:</p>
                        
                        <h5>The MEDDICC Framework for Complex Sales</h5>
                        <ul>
                            <li><strong>M</strong>etrics - Quantifiable business outcomes the client seeks</li>
                            <li><strong>E</strong>conomic Buyer - Decision maker who controls the budget</li>
                            <li><strong>D</strong>ecision Criteria - Formal evaluation criteria for solutions</li>
                            <li><strong>D</strong>ecision Process - Steps required for purchase approval</li>
                            <li><strong>I</strong>dentify Pain - Specific business challenges to address</li>
                            <li><strong>C</strong>hampion - Internal advocate for your solution</li>
                            <li><strong>C</strong>ompetition - Alternative solutions being considered</li>
                        </ul>
                        
                        <h5>ABL Group-Specific Qualification Factors</h5>
                        <ul>
                            <li><strong>Strategic Alignment:</strong> Fit with ABL Group's core capabilities and growth areas</li>
                            <li><strong>Project Scale:</strong> Size and scope relative to optimal engagement size</li>
                            <li><strong>Technical Complexity:</strong> Match between requirements and our expertise</li>
                            <li><strong>Timeline Alignment:</strong> Client timeline vs. our resource availability</li>
                            <li><strong>Cross-selling Potential:</strong> Opportunity for multiple service offerings</li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Industry Standard:</strong> According to SiriusDecisions, organizations with formalized lead qualification frameworks achieve 35% higher conversion rates from opportunity to closed business.
                        </div>
                    `
                },
                {
                    title: 'BANT Framework',
                    content: `
                        <p>The BANT framework helps assess if a lead is worth pursuing:</p>
                        
                        <h5>Enhanced BANT for Technical Services</h5>
                        <ul>
                            <li><strong>B</strong>udget
                                <ul>
                                    <li>Is funding allocated for this initiative?</li>
                                    <li>What is the expected investment range?</li>
                                    <li>Who controls the budget approval process?</li>
                                    <li>How does the client typically structure payment terms?</li>
                                </ul>
                            </li>
                            <li><strong>A</strong>uthority
                                <ul>
                                    <li>Who makes the final decision?</li>
                                    <li>What is the approval chain?</li>
                                    <li>Who are the technical evaluators vs. business approvers?</li>
                                    <li>Are there external stakeholders involved (regulators, partners)?</li>
                                </ul>
                            </li>
                            <li><strong>N</strong>eed
                                <ul>
                                    <li>What specific business problem needs solving?</li>
                                    <li>How is this problem impacting operations/results?</li>
                                    <li>What happens if the problem isn't addressed?</li>
                                    <li>How does this align with strategic priorities?</li>
                                </ul>
                            </li>
                            <li><strong>T</strong>imeframe
                                <ul>
                                    <li>What is driving the timeline?</li>
                                    <li>What are the key milestones in the decision process?</li>
                                    <li>Are there external factors affecting timing (regulations, market conditions)?</li>
                                    <li>What happens if deadlines are missed?</li>
                                </ul>
                            </li>
                        </ul>
                        
                        <div class="alert alert-info">
                            <strong>Best Practice:</strong> McKinsey research indicates that sales teams who thoroughly qualify opportunities using structured frameworks like BANT spend 27% less time on deals that don't close.
                        </div>
                    `
                }
            ],
            resources: [
                {
                    title: 'Lead Qualification Handbook',
                    type: 'PDF',
                    url: '/downloads/sales-training/lead-qualification-handbook.pdf'
                },
                {
                    title: 'MEDDICC Assessment Template',
                    type: 'Excel',
                    url: '/downloads/sales-training/meddicc-assessment-template.xlsx'
                },
                {
                    title: 'Opportunity Scoring Calculator',
                    type: 'Excel',
                    url: '/downloads/sales-training/opportunity-scoring-calculator.xlsx'
                }
            ]
        }
    };

    // Function to merge the best practices content with existing moduleData
    function enhanceModuleData() {
        // Check if moduleData exists
        if (typeof window.moduleData === 'undefined') {
            console.error('moduleData not found');
            return;
        }

        // Merge the best practices content with existing moduleData
        for (const moduleId in bestPracticesContent) {
            if (window.moduleData[moduleId]) {
                // If sections exist in both, merge them
                if (bestPracticesContent[moduleId].sections && window.moduleData[moduleId].sections) {
                    // Replace existing sections with enhanced ones
                    window.moduleData[moduleId].sections = bestPracticesContent[moduleId].sections;
                }
                
                // If resources exist in both, merge them
                if (bestPracticesContent[moduleId].resources && window.moduleData[moduleId].resources) {
                    // Add new resources to existing ones
                    window.moduleData[moduleId].resources = [
                        ...window.moduleData[moduleId].resources,
                        ...bestPracticesContent[moduleId].resources
                    ];
                }
            }
        }
    }

    // Call the function to enhance moduleData
    enhanceModuleData();
});
