import React from 'react';

const MeetingPreparationChecklist = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-blue-800 mb-1">ABL Group Meeting Preparation Checklist</h1>
        <p className="text-gray-600 italic">A Comprehensive Tool for Client Meeting Success</p>
      </div>
      
      <div className="bg-blue-50 p-4 rounded-md mb-6">
        <h2 className="text-lg font-semibold text-blue-700 mb-2">Purpose & Value</h2>
        <p className="text-gray-700 mb-3">This checklist helps ABL Group professionals prepare thoroughly for client meetings across our renewables, maritime, and oil & gas sectors. Proper preparation demonstrates our professionalism, maximizes meeting productivity, and strengthens client relationships. This structured approach ensures we consistently represent ABL Group's values of safety, technical excellence, collaboration, innovation, and truth.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mt-4">
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">When to Use</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Initial client meetings</li>
              <li>Project progress reviews</li>
              <li>Technical presentations</li>
              <li>Business development meetings</li>
              <li>Contract negotiations</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">Key Benefits</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Enhanced meeting effectiveness</li>
              <li>Demonstrates professionalism</li>
              <li>Maximizes client value</li>
              <li>Ensures consistent approach</li>
              <li>Supports technical excellence</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">How to Use</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Start preparation 3-5 days before</li>
              <li>Complete all relevant sections</li>
              <li>Share with meeting participants</li>
              <li>Review final checklist day before</li>
              <li>Document follow-up items after</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Pre-Meeting Planning</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <h3 className="font-medium text-blue-600 mb-2">Meeting Fundamentals</h3>
          <div className="mb-4">
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check1" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check1" className="block text-gray-700 font-medium">Define clear meeting objectives</label>
                  <p className="text-sm text-gray-500">Document 2-3 specific outcomes you want to achieve</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check2" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check2" className="block text-gray-700 font-medium">Prepare and distribute agenda</label>
                  <p className="text-sm text-gray-500">Include specific topics, timing, and responsible parties</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check3" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check3" className="block text-gray-700 font-medium">Confirm meeting logistics</label>
                  <p className="text-sm text-gray-500">Date, time, location/platform, duration, and technical requirements</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check4" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check4" className="block text-gray-700 font-medium">Identify and invite key participants</label>
                  <p className="text-sm text-gray-500">Include necessary ABL Group specialists and confirm client attendees</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check5" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check5" className="block text-gray-700 font-medium">Assign meeting roles</label>
                  <p className="text-sm text-gray-500">Leader, technical presenters, note-taker, timekeeper</p>
                </div>
              </div>
            </div>
          </div>
          
          <h3 className="font-medium text-blue-600 mb-2">Client Research</h3>
          <div className="mb-4">
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check6" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check6" className="block text-gray-700 font-medium">Review client background information</label>
                  <p className="text-sm text-gray-500">Company profile, recent news, industry position, sustainability commitments</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check7" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check7" className="block text-gray-700 font-medium">Research attendee profiles</label>
                  <p className="text-sm text-gray-500">Roles, responsibilities, technical backgrounds, previous interactions</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check8" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check8" className="block text-gray-700 font-medium">Review project/engagement history</label>
                  <p className="text-sm text-gray-500">Previous work, outstanding issues, current project status</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check9" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check9" className="block text-gray-700 font-medium">Understand client's business challenges</label>
                  <p className="text-sm text-gray-500">Current market position, industry pressures, strategic initiatives</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check10" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check10" className="block text-gray-700 font-medium">Identify relevant cross-selling opportunities</label>
                  <p className="text-sm text-gray-500">Review ABL Cross-Selling Matrix for complementary services</p>
                </div>
              </div>
            </div>
          </div>
          
          <h3 className="font-medium text-blue-600 mb-2">Technical Preparation</h3>
          <div>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check11" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check11" className="block text-gray-700 font-medium">Review technical information</label>
                  <p className="text-sm text-gray-500">Project specifications, technical requirements, industry standards</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check12" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check12" className="block text-gray-700 font-medium">Prepare technical content</label>
                  <p className="text-sm text-gray-500">Slides, diagrams, case studies, data visualizations</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check13" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check13" className="block text-gray-700 font-medium">Consult with relevant subject matter experts</label>
                  <p className="text-sm text-gray-500">Involve specialists from across ABL Group companies as needed</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check14" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check14" className="block text-gray-700 font-medium">Compile relevant project examples/references</label>
                  <p className="text-sm text-gray-500">Similar projects, case studies, lessons learned, success stories</p>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="check15" />
                <div className="ml-3 flex-1">
                  <label htmlFor="check15" className="block text-gray-700 font-medium">Anticipate technical questions</label>
                  <p className="text-sm text-gray-500">Prepare answers to likely technical inquiries</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Sector-Specific Preparation</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="border border-gray-300 rounded-md p-4">
            <h3 className="font-medium text-blue-600 mb-2">Renewables Sector</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="renew1" />
                <div className="ml-3">
                  <label htmlFor="renew1" className="block text-gray-700">Review project technology specifics</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="renew2" />
                <div className="ml-3">
                  <label htmlFor="renew2" className="block text-gray-700">Understand site conditions & constraints</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="renew3" />
                <div className="ml-3">
                  <label htmlFor="renew3" className="block text-gray-700">Research relevant regulatory framework</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="renew4" />
                <div className="ml-3">
                  <label htmlFor="renew4" className="block text-gray-700">Review project economics & financing</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="renew5" />
                <div className="ml-3">
                  <label htmlFor="renew5" className="block text-gray-700">Understand supply chain considerations</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="renew6" />
                <div className="ml-3">
                  <label htmlFor="renew6" className="block text-gray-700">Research market trends & innovations</label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border border-gray-300 rounded-md p-4">
            <h3 className="font-medium text-blue-600 mb-2">Maritime Sector</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="maritime1" />
                <div className="ml-3">
                  <label htmlFor="maritime1" className="block text-gray-700">Review vessel/asset specifications</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="maritime2" />
                <div className="ml-3">
                  <label htmlFor="maritime2" className="block text-gray-700">Understand insurance & warranty context</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="maritime3" />
                <div className="ml-3">
                  <label htmlFor="maritime3" className="block text-gray-700">Research applicable regulations/class rules</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="maritime4" />
                <div className="ml-3">
                  <label htmlFor="maritime4" className="block text-gray-700">Review operational profiles & requirements</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="maritime5" />
                <div className="ml-3">
                  <label htmlFor="maritime5" className="block text-gray-700">Understand environmental considerations</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="maritime6" />
                <div className="ml-3">
                  <label htmlFor="maritime6" className="block text-gray-700">Research port/infrastructure requirements</label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border border-gray-300 rounded-md p-4">
            <h3 className="font-medium text-blue-600 mb-2">Oil & Gas Sector</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="og1" />
                <div className="ml-3">
                  <label htmlFor="og1" className="block text-gray-700">Review asset/facility specifications</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="og2" />
                <div className="ml-3">
                  <label htmlFor="og2" className="block text-gray-700">Understand operating environment</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="og3" />
                <div className="ml-3">
                  <label htmlFor="og3" className="block text-gray-700">Research safety & regulatory requirements</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="og4" />
                <div className="ml-3">
                  <label htmlFor="og4" className="block text-gray-700">Review operational constraints</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="og5" />
                <div className="ml-3">
                  <label htmlFor="og5" className="block text-gray-700">Understand energy transition context</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="og6" />
                <div className="ml-3">
                  <label htmlFor="og6" className="block text-gray-700">Research market conditions & challenges</label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Meeting-Type Specific Preparation</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border border-gray-300 rounded-md p-4">
            <h3 className="font-medium text-blue-600 mb-2">New Business/Sales Meetings</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="sales1" />
                <div className="ml-3">
                  <label htmlFor="sales1" className="block text-gray-700">Prepare client-specific value proposition</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="sales2" />
                <div className="ml-3">
                  <label htmlFor="sales2" className="block text-gray-700">Research competitive landscape</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="sales3" />
                <div className="ml-3">
                  <label htmlFor="sales3" className="block text-gray-700">Prepare ROI/value demonstration</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="sales4" />
                <div className="ml-3">
                  <label htmlFor="sales4" className="block text-gray-700">Define next steps & proposal process</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="sales5" />
                <div className="ml-3">
                  <label htmlFor="sales5" className="block text-gray-700">Prepare qualification questions</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="sales6" />
                <div className="ml-3">
                  <label htmlFor="sales6" className="block text-gray-700">Review commercial parameters</label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border border-gray-300 rounded-md p-4">
            <h3 className="font-medium text-blue-600 mb-2">Project Review Meetings</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="review1" />
                <div className="ml-3">
                  <label htmlFor="review1" className="block text-gray-700">Prepare progress status report</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="review2" />
                <div className="ml-3">
                  <label htmlFor="review2" className="block text-gray-700">Review deliverable quality</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="review3" />
                <div className="ml-3">
                  <label htmlFor="review3" className="block text-gray-700">Update schedule & milestone status</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="review4" />
                <div className="ml-3">
                  <label htmlFor="review4" className="block text-gray-700">Document issues & mitigation plans</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="review5" />
                <div className="ml-3">
                  <label htmlFor="review5" className="block text-gray-700">Review budget & resource status</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="review6" />
                <div className="ml-3">
                  <label htmlFor="review6" className="block text-gray-700">Prepare change management items</label>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
          <div className="border border-gray-300 rounded-md p-4">
            <h3 className="font-medium text-blue-600 mb-2">Technical Solution Presentations</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="tech1" />
                <div className="ml-3">
                  <label htmlFor="tech1" className="block text-gray-700">Prepare technical presentation</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="tech2" />
                <div className="ml-3">
                  <label htmlFor="tech2" className="block text-gray-700">Develop visual aids & demonstrations</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="tech3" />
                <div className="ml-3">
                  <label htmlFor="tech3" className="block text-gray-700">Review technical accuracy</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="tech4" />
                <div className="ml-3">
                  <label htmlFor="tech4" className="block text-gray-700">Prepare for technical Q&A</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="tech5" />
                <div className="ml-3">
                  <label htmlFor="tech5" className="block text-gray-700">Adapt content to audience expertise</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="tech6" />
                <div className="ml-3">
                  <label htmlFor="tech6" className="block text-gray-700">Test any technical demonstrations</label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border border-gray-300 rounded-md p-4">
            <h3 className="font-medium text-blue-600 mb-2">Virtual Meeting Specifics</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="virtual1" />
                <div className="ml-3">
                  <label htmlFor="virtual1" className="block text-gray-700">Test video platform & settings</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="virtual2" />
                <div className="ml-3">
                  <label htmlFor="virtual2" className="block text-gray-700">Check audio & video quality</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="virtual3" />
                <div className="ml-3">
                  <label htmlFor="virtual3" className="block text-gray-700">Prepare professional background</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="virtual4" />
                <div className="ml-3">
                  <label htmlFor="virtual4" className="block text-gray-700">Test screen sharing functionality</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="virtual5" />
                <div className="ml-3">
                  <label htmlFor="virtual5" className="block text-gray-700">Plan for technical contingencies</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="virtual6" />
                <div className="ml-3">
                  <label htmlFor="virtual6" className="block text-gray-700">Prepare collaborative tools</label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Final Day Preparation</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-blue-600 mb-2">Materials & Logistics</h3>
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="final1" />
                  <div className="ml-3">
                    <label htmlFor="final1" className="block text-gray-700">Finalize & test presentation materials</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="final2" />
                  <div className="ml-3">
                    <label htmlFor="final2" className="block text-gray-700">Prepare handouts/supporting documents</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="final3" />
                  <div className="ml-3">
                    <label htmlFor="final3" className="block text-gray-700">Confirm meeting room/virtual setup</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="final4" />
                  <div className="ml-3">
                    <label htmlFor="final4" className="block text-gray-700">Prepare ABL Group business cards/materials</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="final5" />
                  <div className="ml-3">
                    <label htmlFor="final5" className="block text-gray-700">Confirm travel arrangements if applicable</label>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium text-blue-600 mb-2">Team Coordination</h3>
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="team1" />
                  <div className="ml-3">
                    <label htmlFor="team1" className="block text-gray-700">Hold pre-meeting team briefing</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="team2" />
                  <div className="ml-3">
                    <label htmlFor="team2" className="block text-gray-700">Align on key messages & talking points</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="team3" />
                  <div className="ml-3">
                    <label htmlFor="team3" className="block text-gray-700">Review presentation flow & handoffs</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="team4" />
                  <div className="ml-3">
                    <label htmlFor="team4" className="block text-gray-700">Confirm team member roles & responsibilities</label>
                  </div>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="team5" />
                  <div className="ml-3">
                    <label htmlFor="team5" className="block text-gray-700">Practice technical explanations & demonstrations</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <h3 className="font-medium text-blue-600 mb-2">Final Readiness Check</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="ready1" />
                <div className="ml-3">
                  <label htmlFor="ready1" className="block text-gray-700 font-medium">Confirm all preparation items complete</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="ready2" />
                <div className="ml-3">
                  <label htmlFor="ready2" className="block text-gray-700 font-medium">Review meeting objectives & success criteria</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="ready3" />
                <div className="ml-3">
                  <label htmlFor="ready3" className="block text-gray-700 font-medium">Plan follow-up activities & next steps</label>
                </div>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="ready4" />
                <div className="ml-3">
                  <label htmlFor="ready4" className="block text-gray-700 font-medium">Prepare for post-meeting documentation</label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Post-Meeting Actions (Complete After Meeting)</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="grid grid-cols-1 gap-3">
            <div className="flex items-center">
              <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="post1" />
              <div className="ml-3">
                <label htmlFor="post1" className="block text-gray-700 font-medium">Document meeting notes & key decisions</label>
              </div>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="post2" />
              <div className="ml-3">
                <label htmlFor="post2" className="block text-gray-700 font-medium">Distribute meeting minutes to participants</label>
              </div>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="post3" />
              <div className="ml-3">
                <label htmlFor="post3" className="block text-gray-700 font-medium">Update CRM/project management system</label>
              </div>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="post4" />
              <div className="ml-3">
                <label htmlFor="post4" className="block text-gray-700 font-medium">Follow up on action items & commitments</label>
              </div>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="post5" />
              <div className="ml-3">
                <label htmlFor="post5" className="block text-gray-700 font-medium">Send thank you note with next steps</label>
              </div>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="post6" />
              <div className="ml-3">
                <label htmlFor="post6" className="block text-gray-700 font-medium">Prepare/submit any promised deliverables</label>
              </div>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="h-5 w-5 text-blue-600 rounded" id="post7" />
              <div className="ml-3">
                <label htmlFor="post7" className="block text-gray-700 font-medium">Debrief with ABL Group team on lessons learned</label>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="text-xs text-gray-500 mt-6 text-center">
        ABL Group Meeting Preparation Checklist • Driving Sustainability in Energy and Oceans • Last Updated: May 2025
      </div>
    </div>
  );
};

export default MeetingPreparationChecklist;
