const express = require('express');
const router = express.Router();

// Admin: Services Page
router.get('/services', (req, res) => {
  res.render('admin/services', {
    title: 'Admin - Services Management',
    message: 'This is where services can be managed by admin users.'
  });
});

// Admin: Analytics Page
router.get('/analytics', (req, res) => {
  res.render('admin/analytics', {
    title: 'Admin - Analytics Dashboard',
    message: 'Analytics data and charts for admin.'
  });
});

module.exports = router;
