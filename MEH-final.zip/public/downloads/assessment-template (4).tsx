import React from 'react';

const AssessmentTemplate = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-blue-800 mb-4">ABL Group Solution Assessment Template</h1>
      
      <div className="bg-blue-50 p-4 rounded-md mb-6">
        <p className="text-sm text-blue-700">This comprehensive assessment template helps evaluate the fit, impact, and implementation readiness of proposed technical solutions across ABL Group's core sectors: renewables, maritime, and oil & gas. Complete all sections with stakeholder input to ensure solution viability and alignment with client needs while adhering to our values of safety, technical excellence, collaboration, innovation, and truth.</p>
      </div>
      
      <div className="mb-8">
        <div className="flex items-center mb-3">
          <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2">1</div>
          <h2 className="text-xl font-semibold text-blue-700">Client & Project Information</h2>
        </div>
        <div className="border border-gray-300 rounded-md p-4 mb-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium text-blue-600 mb-1">Client Details</h4>
              <div className="grid grid-cols-3 gap-1 text-sm mb-3">
                <div className="font-medium text-gray-600">Client Name:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">OceanWind Ventures</div>
                
                <div className="font-medium text-gray-600">Industry:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">Offshore Wind Energy</div>
                
                <div className="font-medium text-gray-600">Size:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">Mid-market (€350M annual revenue)</div>

                <div className="font-medium text-gray-600">Region:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">Northern Europe</div>
              </div>
            </div>
            <div>
              <h4 className="font-medium text-blue-600 mb-1">Project Context</h4>
              <div className="grid grid-cols-3 gap-1 text-sm">
                <div className="font-medium text-gray-600">Project Name:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">North Sea Floating Wind Project</div>
                
                <div className="font-medium text-gray-600">Project Phase:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">Early Development & Engineering</div>
                
                <div className="font-medium text-gray-600">Timeline:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">Q3 2025 - Q4 2027</div>

                <div className="font-medium text-gray-600">ABL Business Unit:</div>
                <div className="col-span-2 bg-gray-100 p-1 rounded">OWC (Offshore Wind Consultants)</div>
              </div>
            </div>
          </div>
        </div>
        <div className="border border-gray-300 rounded-md p-4">
          <h4 className="font-medium text-blue-600 mb-1">Key Stakeholders</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Name</th>
                  <th className="p-2 text-left">Role</th>
                  <th className="p-2 text-left">Influence Level</th>
                  <th className="p-2 text-left">Key Concerns</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Maria Johansen</td>
                  <td className="p-2">Project Director</td>
                  <td className="p-2">Decision Maker</td>
                  <td className="p-2">Technical feasibility, project economics, timeline</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Thomas Nielsen</td>
                  <td className="p-2">Head of Marine Operations</td>
                  <td className="p-2">Key Influencer</td>
                  <td className="p-2">Installation logistics, vessel availability, weather risk</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Karen Andersen</td>
                  <td className="p-2">Finance Director</td>
                  <td className="p-2">Approver</td>
                  <td className="p-2">CAPEX optimization, ROI, financial risk management</td>
                </tr>
                <tr>
                  <td className="p-2">Erik Schmidt</td>
                  <td className="p-2">Engineering Manager</td>
                  <td className="p-2">Technical Authority</td>
                  <td className="p-2">Design integrity, certification, technical standards</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <div className="flex items-center mb-3">
          <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2">2</div>
          <h2 className="text-xl font-semibold text-blue-700">Needs Assessment</h2>
        </div>
        <div className="border border-gray-300 rounded-md p-4 mb-2">
          <h4 className="font-medium text-blue-600 mb-2">Client Challenges & Pain Points</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Challenge</th>
                  <th className="p-2 text-left">Impact</th>
                  <th className="p-2 text-left">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Complex mooring system design for challenging seabed conditions</td>
                  <td className="p-2">Potential €5M+ in additional engineering costs, 6-month schedule risk</td>
                  <td className="p-2"><span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium">Critical</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Uncertainty in metocean conditions affecting design parameters</td>
                  <td className="p-2">Potential overdesign adding 15% to foundation costs or underdesign increasing operational risks</td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Limited experience with floating wind T&I operations in the region</td>
                  <td className="p-2">Increased risk premiums from contractors, 20% contingency in installation budget</td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr>
                  <td className="p-2">Cable stability and protection in dynamic floating wind environment</td>
                  <td className="p-2">Concern for long-term reliability, potential for costly repairs (€2-3M per event)</td>
                  <td className="p-2"><span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="border border-gray-300 rounded-md p-4">
          <h4 className="font-medium text-blue-600 mb-2">Success Criteria</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white p-3 rounded border border-gray-200">
              <h5 className="font-medium text-gray-700 mb-1">Primary Objectives</h5>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li>Develop optimized mooring system design validated for site conditions</li>
                <li>Reduce engineering and design uncertainties by at least 60%</li>
                <li>Create detailed T&I methodology with thorough risk assessment</li>
                <li>Establish robust design basis with comprehensive metocean analysis</li>
                <li>Provide actionable recommendations for dynamic cable configuration</li>
              </ul>
            </div>
            <div className="bg-white p-3 rounded border border-gray-200">
              <h5 className="font-medium text-gray-700 mb-1">Key Performance Indicators</h5>
              <ul className="list-disc pl-5 text-gray-700 text-sm">
                <li>CAPEX optimization (target: 10-15% reduction from baseline)</li>
                <li>Schedule confidence (target: 90% probability of meeting milestones)</li>
                <li>Risk reduction (target: &lt;35% contingency requirement)</li>
                <li>Contractor engagement (target: minimum 3 qualified bids per package)</li>
                <li>Design certification (target: Class approval with minimal comments)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <div className="flex items-center mb-3">
          <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2">3</div>
          <h2 className="text-xl font-semibold text-blue-700">ABL Group Solution Assessment</h2>
        </div>
        <div className="border border-gray-300 rounded-md p-4 mb-2">
          <h4 className="font-medium text-blue-600 mb-2">Proposed Solution Components</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Component</th>
                  <th className="p-2 text-left">Description</th>
                  <th className="p-2 text-left">Addresses</th>
                  <th className="p-2 text-left">Estimated Fee</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Integrated Engineering Solution</td>
                  <td className="p-2">Comprehensive mooring system design and analysis with advanced coupled simulations</td>
                  <td className="p-2">Mooring system design, seabed conditions</td>
                  <td className="p-2">€450,000</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Metocean Campaign & Analysis</td>
                  <td className="p-2">Site-specific metocean study with data collection, statistical analysis and design basis development</td>
                  <td className="p-2">Metocean uncertainties</td>
                  <td className="p-2">€320,000</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">T&I Engineering Package</td>
                  <td className="p-2">Detailed transportation and installation engineering, methodologies and procedures</td>
                  <td className="p-2">Limited T&I experience</td>
                  <td className="p-2">€380,000</td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Dynamic Cable Analysis</td>
                  <td className="p-2">Fatigue and extreme load analysis of dynamic cable configurations with optimization recommendations</td>
                  <td className="p-2">Cable stability and protection</td>
                  <td className="p-2">€250,000</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="border border-gray-300 rounded-md p-4 mb-2">
          <h4 className="font-medium text-blue-600 mb-2">Solution Evaluation Matrix</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Criteria</th>
                  <th className="p-2 text-center">Weight</th>
                  <th className="p-2 text-center">Score (1-5)</th>
                  <th className="p-2 text-center">Weighted Score</th>
                  <th className="p-2 text-left">Notes</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Technical Capability Match</td>
                  <td className="p-2 text-center">25%</td>
                  <td className="p-2 text-center">4.8</td>
                  <td className="p-2 text-center">1.20</td>
                  <td className="p-2">Excellent alignment with OWC's core floating wind expertise</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Client Value Creation</td>
                  <td className="p-2 text-center">30%</td>
                  <td className="p-2 text-center">4.6</td>
                  <td className="p-2 text-center">1.38</td>
                  <td className="p-2">Strong potential for cost reduction and risk mitigation</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Resource Availability</td>
                  <td className="p-2 text-center">15%</td>
                  <td className="p-2 text-center">3.8</td>
                  <td className="p-2 text-center">0.57</td>
                  <td className="p-2">Some specialist resources require coordination between offices</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Commercial Viability</td>
                  <td className="p-2 text-center">20%</td>
                  <td className="p-2 text-center">4.5</td>
                  <td className="p-2 text-center">0.90</td>
                  <td className="p-2">Strong margin potential with appropriate risk profile</td>
                </tr>
                <tr>
                  <td className="p-2">Strategic Alignment</td>
                  <td className="p-2 text-center">10%</td>
                  <td className="p-2 text-center">5.0</td>
                  <td className="p-2 text-center">0.50</td>
                  <td className="p-2">Perfectly aligned with ABL's renewable energy growth strategy</td>
                </tr>
                <tr className="bg-blue-50">
                  <td className="p-2 font-medium">TOTAL</td>
                  <td className="p-2 text-center">100%</td>
                  <td className="p-2 text-center">-</td>
                  <td className="p-2 text-center font-medium">4.55</td>
                  <td className="p-2">HIGHLY RECOMMENDED (Score > 4.5)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="border border-gray-300 rounded-md p-4">
          <h4 className="font-medium text-blue-600 mb-2">ABL Group Competitive Position</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Competitor</th>
                  <th className="p-2 text-left">Strengths</th>
                  <th className="p-2 text-left">Weaknesses</th>
                  <th className="p-2 text-center">Threat Level</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Global Engineering Firm X</td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Strong general engineering capability</li>
                      <li>Competitive pricing strategy</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Limited floating wind experience</li>
                      <li>No dedicated metocean team</li>
                    </ul>
                  </td>
                  <td className="p-2 text-center">Medium</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Specialist Wind Consultancy Y</td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Strong wind turbine expertise</li>
                      <li>Established relationship with client</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Limited marine operations expertise</li>
                      <li>Smaller team with capacity constraints</li>
                    </ul>
                  </td>
                  <td className="p-2 text-center">High</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">In-House Engineering Team</td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>No external cost</li>
                      <li>Direct control over process</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Limited specialized expertise</li>
                      <li>Resource constraints</li>
                      <li>No independent verification</li>
                    </ul>
                  </td>
                  <td className="p-2 text-center">Medium</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <div className="flex items-center mb-3">
          <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2">4</div>
          <h2 className="text-xl font-semibold text-blue-700">Delivery Plan</h2>
        </div>
        <div className="border border-gray-300 rounded-md p-4 mb-2">
          <h4 className="font-medium text-blue-600 mb-2">Project Phases & Timeline</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Phase</th>
                  <th className="p-2 text-left">Timeline</th>
                  <th className="p-2 text-left">Key Deliverables</th>
                  <th className="p-2 text-left">ABL Resources</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">1. Project Initiation</td>
                  <td className="p-2">4 weeks</td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Project execution plan</li>
                      <li>Data gathering & gap analysis</li>
                      <li>Design basis development</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Project Manager (1)</li>
                      <li>Technical Lead (1)</li>
                      <li>Engineering Support (2)</li>
                    </ul>
                  </td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">2. Engineering Analysis</td>
                  <td className="p-2">14 weeks</td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Mooring system design report</li>
                      <li>Metocean analysis report</li>
                      <li>Dynamic cable configuration design</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Mooring Engineers (2)</li>
                      <li>Metocean Specialists (2)</li>
                      <li>Cable Engineers (2)</li>
                      <li>Technical Director (oversight)</li>
                    </ul>
                  </td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">3. T&I Planning</td>
                  <td className="p-2">10 weeks</td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Transportation engineering report</li>
                      <li>Installation methodologies</li>
                      <li>Marine operations procedures</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Marine Operations Engineers (3)</li>
                      <li>Naval Architects (2)</li>
                      <li>MWS Specialists (1)</li>
                    </ul>
                  </td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">4. Integration & Final Reporting</td>
                  <td className="p-2">6 weeks</td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Integrated solution report</li>
                      <li>Risk assessment & mitigation plan</li>
                      <li>Final presentation & recommendations</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Project Manager (1)</li>
                      <li>Technical Director (1)</li>
                      <li>Technical Leads (3)</li>
                      <li>QA/QC Manager (1)</li>
                    </ul>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="border border-gray-300 rounded-md p-4">
          <h4 className="font-medium text-blue-600 mb-2">Risk Assessment & Mitigation</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Risk</th>
                  <th className="p-2 text-left">Impact</th>
                  <th className="p-2 text-left">Probability</th>
                  <th className="p-2 text-left">Mitigation Strategy</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Insufficient site data for detailed design</td>
                  <td className="p-2"><span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                  <td className="p-2">Early data gap analysis; statistical methods for extrapolation; conservative design factors where needed</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Resource conflicts with other ABL projects</td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                  <td className="p-2">Cross-office resource planning; backup specialist identification; staggered project scheduling</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Client design changes during project execution</td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                  <td className="p-2">Clear change management process; regular client design reviews; modular approach to deliverables</td>
                </tr>
                <tr>
                  <td className="p-2">Novel technology assessment challenges</td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                  <td className="p-2"><span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">Low</span></td>
                  <td className="p-2">Engage with class societies early; leverage ABL's global floating wind expertise; implement technology qualification process</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <div className="flex items-center mb-3">
          <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2">5</div>
          <h2 className="text-xl font-semibold text-blue-700">Commercial Assessment</h2>
        </div>
        <div className="border border-gray-300 rounded-md p-4 mb-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Project Fee Structure</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <table className="min-w-full text-sm">
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Integrated Engineering Solution:</td>
                      <td className="p-1 text-right">€450,000</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Metocean Campaign & Analysis:</td>
                      <td className="p-1 text-right">€320,000</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">T&I Engineering Package:</td>
                      <td className="p-1 text-right">€380,000</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Dynamic Cable Analysis:</td>
                      <td className="p-1 text-right">€250,000</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Project Management (10%):</td>
                      <td className="p-1 text-right">€140,000</td>
                    </tr>
                    <tr className="bg-blue-50">
                      <td className="p-1 font-medium">Total Project Fee:</td>
                      <td className="p-1 text-right font-bold">€1,540,000</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Financial Metrics</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <table className="min-w-full text-sm">
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Estimated Project Margin:</td>
                      <td className="p-1 text-right">28%</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Expected Utilization Rate:</td>
                      <td className="p-1 text-right">85%</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Resource Efficiency:</td>
                      <td className="p-1 text-right">High</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="p-1 font-medium">Cross-Selling Potential:</td>
                      <td className="p-1 text-right">Very High</td>
                    </tr>
                    <tr className="bg-green-50">
                      <td className="p-1 font-medium">Financial Assessment:</td>
                      <td className="p-1 text-right font-bold">Strong</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <h4 className="font-medium text-blue-600 mb-2">Value Proposition</h4>
          <div className="bg-white p-3 rounded border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h5 className="font-medium text-gray-700 mb-1">Value to Client</h5>
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-1">Potential CAPEX savings: €15-25M through optimized design</li>
                  <li className="mb-1">Risk reduction: 40-60% decrease in schedule uncertainty</li>
                  <li className="mb-1">Technical de-risking: Increased confidence for financing</li>
                  <li className="mb-1">Access to specialized expertise not available in-house</li>
                  <li className="mb-1">Robust engineering foundation for future project phases</li>
                </ul>
              </div>
              <div>
                <h5 className="font-medium text-gray-700 mb-1">Value to ABL Group</h5>
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-1">Strategic floating wind reference project in key market</li>
                  <li className="mb-1">Strong margin with limited delivery risk</li>
                  <li className="mb-1">Potential for follow-on work (MWS, T&I support, O&M)</li>
                  <li className="mb-1">Opportunity to leverage cross-business expertise</li>
                  <li className="mb-1">Strengthens ABL's position as floating wind leader</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <div className="flex items-center mb-3">
          <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2">6</div>
          <h2 className="text-xl font-semibold text-blue-700">Recommendation & Next Steps</h2>
        </div>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="bg-blue-50 p-3 rounded mb-4">
            <h4 className="font-medium text-blue-700 mb-1">Recommendation</h4>
            <p className="text-gray-800">Based on the comprehensive assessment, we <strong>strongly recommend</strong> pursuing this opportunity with OceanWind Ventures. The project aligns perfectly with ABL Group's core capabilities in floating wind and presents an excellent opportunity to deliver high-value services with strong margins. The solution addresses critical client challenges while offering significant potential for follow-on work across ABL Group companies.</p>
          </div>
          <h4 className="font-medium text-blue-600 mb-2">Immediate Next Steps</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Action</th>
                  <th className="p-2 text-left">Owner</th>
                  <th className="p-2 text-left">Timeline</th>
                  <th className="p-2 text-left">Success Criteria</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Finalize and submit proposal</td>
                  <td className="p-2">Business Development Lead</td>
                  <td className="p-2">Within 1 week</td>
                  <td className="p-2">Comprehensive proposal addressing all client needs</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Technical presentation to client</td>
                  <td className="p-2">Technical Director</td>
                  <td className="p-2">Within 2 weeks</td>
                  <td className="p-2">Clear articulation of value proposition and approach</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2">Resource planning & allocation</td>
                  <td className="p-2">Operations Manager</td>
                  <td className="p-2">Within 3 weeks</td>
                  <td className="p-2">Confirmed availability of key specialists</td>
                </tr>
                <tr>
                  <td className="p-2">Contract negotiation & setup</td>
                  <td className="p-2">Commercial Manager</td>
                  <td className="p-2">Within 4 weeks</td>
                  <td className="p-2">Signed contract with favorable terms</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <div className="bg-gray-50 p-4 rounded-md">
          <h2 className="text-lg font-semibold text-gray-700 mb-2">Assessment Completion</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="grid grid-cols-3 gap-1">
                <div className="font-medium text-gray-600">Prepared By:</div>
                <div className="col-span-2">John Andersen, Business Development Manager, OWC</div>
                
                <div className="font-medium text-gray-600">Reviewed By:</div>
                <div className="col-span-2">Katherine Miller, Technical Director, Floating Wind</div>
                
                <div className="font-medium text-gray-600">Date:</div>
                <div className="col-span-2">May 13, 2025</div>
              </div>
            </div>
            <div>
              <div className="grid grid-cols-3 gap-1">
                <div className="font-medium text-gray-600">Status:</div>
                <div className="col-span-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">Highly Recommended</span></div>
                
                <div className="font-medium text-gray-600">Document ID:</div>
                <div className="col-span-2">ABL-OWC-2025-0513-FW</div>
                
                <div className="font-medium text-gray-600">Version:</div>
                <div className="col-span-2">1.0</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="text-xs text-gray-500 mt-6 text-center">
        ABL Group Solution Assessment Template • Driving Sustainability in Energy and Oceans • Last Updated: May 2025
      </div>
    </div>
  );
};

export default AssessmentTemplate;
