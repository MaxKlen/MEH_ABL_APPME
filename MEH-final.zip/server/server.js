const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/', (req, res) => {
    res.send('Server is running successfully!');
});

app.listen(PORT, () => {
    console.log(`Server is running on port: ${PORT}`);
});
const dataHandler = require('./modules/data/dataHandler');
const authModule = require('./modules/auth/auth');
app.post('/login', (req, res) => res.json(authModule.login(req.body)));
app.get('/data', (req, res) => res.json(dataHandler.fetchData()));
