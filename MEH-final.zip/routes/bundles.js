const express = require('express');
const router = express.Router();

// Bundles page
router.get('/', (req, res) => {
  res.render('bundles', {
    title: 'Service Bundles - ABL Group Services Catalog',
    activeNav: 'bundles'
  });
});

// Bundle details page
router.get('/:id', (req, res) => {
  const bundleId = req.params.id;
  
  // Mock bundle data - in a real app, this would come from a database
  const bundle = {
    id: bundleId,
    name: 'Offshore Wind Development Bundle',
    description: 'Comprehensive service package for offshore wind development projects',
    services: [
      {
        id: 'owc-001',
        name: 'Site Selection & Feasibility',
        description: 'Expert analysis for optimal offshore wind farm location'
      },
      {
        id: 'owc-002',
        name: 'Environmental Impact Assessment',
        description: 'Thorough assessment of environmental factors and mitigation strategies'
      },
      {
        id: 'lng-003',
        name: 'Engineering Design & Analysis',
        description: 'Detailed engineering design and structural analysis'
      }
    ],
    lifecycleStage: 'concept',
    benefits: [
      'Streamlined project development',
      'Integrated expertise across disciplines',
      'Cost optimization through bundled services',
      'Single point of contact for all services'
    ]
  };
  
  res.render('bundle-details', {
    title: `${bundle.name} - ABL Group Services Catalog`,
    activeNav: 'bundles',
    bundle
  });
});

module.exports = router;
