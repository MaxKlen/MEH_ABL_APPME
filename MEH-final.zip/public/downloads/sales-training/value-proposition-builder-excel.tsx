import React from 'react';

const ValuePropositionBuilderExcel = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-blue-800 mb-1">ABL Group Value Proposition Builder</h1>
        <p className="text-gray-600 italic">Excel Format - For Building Compelling Client Solutions</p>
      </div>
      
      <div className="mb-6">
        <div className="flex justify-between items-center border-b border-gray-300 mb-2 pb-2">
          <div className="flex">
            <div className="bg-blue-600 text-white px-6 py-1">File</div>
            <div className="bg-gray-200 text-gray-700 px-6 py-1">Home</div>
            <div className="bg-gray-200 text-gray-700 px-6 py-1">Insert</div>
            <div className="bg-gray-200 text-gray-700 px-6 py-1">Page Layout</div>
            <div className="bg-gray-200 text-gray-700 px-6 py-1">Formulas</div>
            <div className="bg-gray-200 text-gray-700 px-6 py-1">Data</div>
            <div className="bg-gray-200 text-gray-700 px-6 py-1">Review</div>
            <div className="bg-gray-200 text-gray-700 px-6 py-1">View</div>
          </div>
          <div className="text-gray-500 text-sm">Value_Proposition_Builder_ABL.xlsx</div>
        </div>
        
        <div className="flex text-sm mb-2">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold"></div>
          <div className="w-32 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">A</div>
          <div className="w-48 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">B</div>
          <div className="w-48 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">C</div>
          <div className="w-48 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">D</div>
          <div className="w-48 border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">E</div>
        </div>
        
        {/* Row 1 */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">1</div>
          <div className="w-32 border-r border-b border-gray-300 bg-blue-100 p-2" colSpan="4">
            <p className="font-bold text-blue-800">ABL Group</p>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-2 bg-blue-50" colSpan="4">
            <p className="font-bold text-blue-800">VALUE PROPOSITION BUILDER</p>
          </div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
        
        {/* Row 2 */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">2</div>
          <div className="w-32 border-r border-b border-gray-300 p-1 bg-blue-50" colSpan="4">
            <p className="font-bold text-gray-700">Sector</p>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <select className="w-full border border-gray-300 p-1">
              <option>Renewables</option>
              <option>Maritime</option>
              <option>Oil & Gas</option>
              <option>Energy Transition</option>
            </select>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-1 bg-blue-50">
            <p className="font-bold text-gray-700">Date</p>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-1">13-May-2025</div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
        
        {/* Row 3 */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">3</div>
          <div className="w-32 border-r border-b border-gray-300 p-1 bg-blue-50" colSpan="4">
            <p className="font-bold text-gray-700">Client/Prospect</p>
          </div>
          <div className="w-96 border-r border-b border-gray-300 p-1" colSpan="2">OceanWind Ventures</div>
          <div className="w-48 border-r border-b border-gray-300 p-1 bg-blue-50">
            <p className="font-bold text-gray-700">Prepared By</p>
          </div>
          <div className="w-48 border-b border-gray-300 p-1">John Andersen</div>
        </div>
        
        {/* Row 4 - Empty */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">4</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
        
        {/* Section 1: Target Market */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">5</div>
          <div className="w-96 border-r border-b border-gray-300 bg-blue-600 p-2 text-white font-bold" colSpan="2">1. TARGET MARKET</div>
          <div className="w-96 border-b border-gray-300" colSpan="3"></div>
        </div>
        
        {/* Row 6 - Headers */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">6</div>
          <div className="w-32 border-r border-b border-gray-300 bg-blue-100 p-1">
            <p className="font-bold text-blue-800">Market Segment</p>
          </div>
          <div className="w-96 border-r border-b border-gray-300 bg-blue-100 p-1" colSpan="2">
            <p className="font-bold text-blue-800">Characteristics/Demographics</p>
          </div>
          <div className="w-96 border-b border-gray-300 bg-blue-100 p-1" colSpan="2">
            <p className="font-bold text-blue-800">Needs/Pain Points</p>
          </div>
        </div>
        
        {/* Row 7 - Content */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">7</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Offshore Wind Developers</div>
          <div className="w-96 border-r border-b border-gray-300 p-1" colSpan="2">
            <ul className="list-disc pl-5">
              <li>Mid-market (€250-500M annual revenue)</li>
              <li>Northern European focus</li>
              <li>Early-stage floating wind projects</li>
              <li>Limited in-house technical expertise</li>
            </ul>
          </div>
          <div className="w-96 border-b border-gray-300 p-1" colSpan="2">
            <ul className="list-disc pl-5">
              <li>Complex mooring system design challenges</li>
              <li>Metocean uncertainty affecting design</li>
              <li>Limited T&I operations experience</li>
              <li>Cable stability concerns in dynamic environment</li>
            </ul>
          </div>
        </div>
        
        {/* More rows for Section 1 */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">8</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Renewable Energy Investors</div>
          <div className="w-96 border-r border-b border-gray-300 p-1" colSpan="2">
            <ul className="list-disc pl-5">
              <li>Investment funds and financial institutions</li>
              <li>Growing renewable energy portfolios</li>
              <li>Seeking technical risk assessment</li>
              <li>Strong focus on bankability</li>
            </ul>
          </div>
          <div className="w-96 border-b border-gray-300 p-1" colSpan="2">
            <ul className="list-disc pl-5">
              <li>Project technical due diligence requirements</li>
              <li>Risk assessment and mitigation expertise</li>
              <li>Reliable energy yield predictions</li>
              <li>Independent verification of designs</li>
            </ul>
          </div>
        </div>
        
        {/* Empty row */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">9</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
        
        {/* Section 2: Service Offerings */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">10</div>
          <div className="w-96 border-r border-b border-gray-300 bg-blue-600 p-2 text-white font-bold" colSpan="2">2. ABL GROUP SERVICE OFFERINGS</div>
          <div className="w-96 border-b border-gray-300" colSpan="3"></div>
        </div>
        
        {/* Row 11 - Headers */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">11</div>
          <div className="w-32 border-r border-b border-gray-300 bg-blue-100 p-1">
            <p className="font-bold text-blue-800">Service</p>
          </div>
          <div className="w-48 border-r border-b border-gray-300 bg-blue-100 p-1">
            <p className="font-bold text-blue-800">Description</p>
          </div>
          <div className="w-48 border-r border-b border-gray-300 bg-blue-100 p-1">
            <p className="font-bold text-blue-800">Key Features</p>
          </div>
          <div className="w-48 border-r border-b border-gray-300 bg-blue-100 p-1">
            <p className="font-bold text-blue-800">Client Benefits</p>
          </div>
          <div className="w-48 border-b border-gray-300 bg-blue-100 p-1">
            <p className="font-bold text-blue-800">Primary ABL Provider</p>
          </div>
        </div>
        
        {/* Row 12 - Content */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">12</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Integrated Engineering Solution</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">Comprehensive mooring system design and analysis with advanced coupled simulations</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>Advanced simulation tools</li>
              <li>Coupled analysis capability</li>
              <li>Global expertise</li>
              <li>Optimized designs</li>
            </ul>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>Reduced CAPEX through optimization</li>
              <li>Enhanced design reliability</li>
              <li>Faster approval process</li>
              <li>Risk reduction</li>
            </ul>
          </div>
          <div className="w-48 border-b border-gray-300 p-1">OWC/Innosea</div>
        </div>
        
        {/* Row 13 - Content */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">13</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Metocean Campaign & Analysis</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">Site-specific metocean study with data collection, statistical analysis and design basis development</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>High-resolution modeling</li>
              <li>Statistical analysis</li>
              <li>Climate change factors</li>
              <li>Calibrated with measurements</li>
            </ul>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>Reduced design uncertainties</li>
              <li>Optimized design criteria</li>
              <li>Enhanced operational planning</li>
              <li>Improved weather window analysis</li>
            </ul>
          </div>
          <div className="w-48 border-b border-gray-300 p-1">OWC</div>
        </div>
        
        {/* Row 14 - Content */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">14</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">T&I Engineering Package</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">Detailed transportation and installation engineering, methodologies and procedures</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>Detailed method statements</li>
              <li>Vessel selection expertise</li>
              <li>Motion analysis</li>
              <li>Lifting calculations</li>
            </ul>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>Reduced installation risk</li>
              <li>Optimized vessel selection</li>
              <li>Enhanced weather window analysis</li>
              <li>Improved contractor negotiation position</li>
            </ul>
          </div>
          <div className="w-48 border-b border-gray-300 p-1">Longitude/ABL</div>
        </div>
        
        {/* Row 15 - Content */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">15</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Dynamic Cable Analysis</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">Fatigue and extreme load analysis of dynamic cable configurations with optimization recommendations</div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>Fatigue analysis</li>
              <li>Configuration optimization</li>
              <li>Protection system design</li>
              <li>Installation methodology</li>
            </ul>
          </div>
          <div className="w-48 border-r border-b border-gray-300 p-1">
            <ul className="list-disc pl-5">
              <li>Enhanced cable reliability</li>
              <li>Reduced lifetime O&M costs</li>
              <li>Optimized cable design</li>
              <li>Reduced cable failure risk</li>
            </ul>
          </div>
          <div className="w-48 border-b border-gray-300 p-1">Innosea</div>
        </div>
        
        {/* Empty row */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">16</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
        
        {/* Section 3: Unique Value Proposition */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">17</div>
          <div className="w-96 border-r border-b border-gray-300 bg-blue-600 p-2 text-white font-bold" colSpan="2">3. UNIQUE VALUE PROPOSITION</div>
          <div className="w-96 border-b border-gray-300" colSpan="3"></div>
        </div>
        
        {/* Row 18 - Headers */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">18</div>
          <div className="w-96 border-r border-b border-gray-300 bg-blue-100 p-1 font-bold text-blue-800" colSpan="2">ABL Group Differentiators</div>
          <div className="w-96 border-b border-gray-300 bg-blue-100 p-1 font-bold text-blue-800" colSpan="3">Competitor Comparison</div>
        </div>
        
        {/* Row 19 - Content */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">19</div>
          <div className="w-96 border-r border-b border-gray-300 p-1" colSpan="2">
            <ul className="list-disc pl-5">
              <li>Global reach with local expertise across 300+ locations worldwide</li>
              <li>Legacy of technical excellence dating back to 1856</li>
              <li>Deepest pool of multi-disciplinary expertise across marine and engineering disciplines</li>
              <li>Leading provider in marine warranty survey and marine assurance</li>
              <li>Truly independent consultancy ensuring objective advice</li>
              <li>Unique position supporting all three sectors: renewables, maritime, and oil & gas</li>
            </ul>
          </div>
          <div className="w-96 border-b border-gray-300 p-1" colSpan="3">
            <table className="min-w-full text-xs">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-1">Capability</th>
                  <th className="border p-1">ABL Group</th>
                  <th className="border p-1">Competitor A</th>
                  <th className="border p-1">Competitor B</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border p-1">Floating Wind Expertise</td>
                  <td className="border p-1">Strong</td>
                  <td className="border p-1">Medium</td>
                  <td className="border p-1">Weak</td>
                </tr>
                <tr>
                  <td className="border p-1">Marine Engineering</td>
                  <td className="border p-1">Strong</td>
                  <td className="border p-1">Weak</td>
                  <td className="border p-1">Medium</td>
                </tr>
                <tr>
                  <td className="border p-1">Global Presence</td>
                  <td className="border p-1">Strong</td>
                  <td className="border p-1">Medium</td>
                  <td className="border p-1">Weak</td>
                </tr>
                <tr>
                  <td className="border p-1">Independence</td>
                  <td className="border p-1">Strong</td>
                  <td className="border p-1">Weak</td>
                  <td className="border p-1">Medium</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Row 20-22 - Value Proposition Statement */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">20</div>
          <div className="w-32 border-r border-b border-gray-300 bg-blue-100 p-1 font-bold text-blue-800">Value Proposition Statement</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <span className="font-bold">Renewables Value Proposition:</span>
          </div>
        </div>
        
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">21</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            For renewable energy developers seeking to optimize project performance and mitigate risks, ABL Group delivers unparalleled technical expertise and marine engineering solutions that reduce technical uncertainty, enhance project economics, and accelerate the energy transition.
          </div>
        </div>
        
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">22</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <span className="font-bold">Key Benefits:</span> CAPEX reduction of 10-15% through design optimization, 40-60% decrease in schedule uncertainty, enhanced technical design reliability, and accelerated delivery timeframes.
          </div>
        </div>
        
        {/* Empty row */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">23</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
        
        {/* Section 4: Evidence & Proof Points */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">24</div>
          <div className="w-96 border-r border-b border-gray-300 bg-blue-600 p-2 text-white font-bold" colSpan="2">4. EVIDENCE & PROOF POINTS</div>
          <div className="w-96 border-b border-gray-300" colSpan="3"></div>
        </div>
        
        {/* Row 25 - Headers */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">25</div>
          <div className="w-32 border-r border-b border-gray-300 bg-blue-100 p-1 font-bold text-blue-800">Category</div>
          <div className="w-192 border-b border-gray-300 bg-blue-100 p-1 font-bold text-blue-800" colSpan="4">Evidence</div>
        </div>
        
        {/* Row 26-27 - Case Studies */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">26</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Case Studies</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <ul className="list-disc pl-5">
              <li><strong>Floating Wind Platform Design (North Sea)</strong> - Engineering optimization delivered 18% CAPEX reduction</li>
              <li><strong>Offshore Wind Farm Installation (Baltic Sea)</strong> - T&I engineering support reduced weather downtime by 35%</li>
              <li><strong>Metocean Analysis (Celtic Sea)</strong> - Enhanced design criteria reduced conservative assumptions saving €12M</li>
            </ul>
          </div>
        </div>
        
        {/* Row 27-28 - References/Clients */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">27</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">References/ Clients</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <ul className="list-disc pl-5">
              <li>Major European utilities including Ørsted, Vattenfall, and RWE</li>
              <li>Renewable energy developers such as Ocean Winds, BlueFloat Energy, and Mainstream Renewable Power</li>
              <li>Investment firms including Copenhagen Infrastructure Partners and Green Investment Group</li>
            </ul>
          </div>
        </div>
        
        {/* Row 28-29 - Credentials */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">28</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Team Credentials</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <ul className="list-disc pl-5">
              <li>150+ engineering specialists focused on renewable energy</li>
              <li>40+ years combined experience in offshore wind projects</li>
              <li>Multi-disciplinary expertise across all marine engineering specialties</li>
              <li>Track record of 25+ GW of renewable energy projects supported</li>
            </ul>
          </div>
        </div>
        
        {/* Row 29-30 - Metrics */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">29</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Key Metrics</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <div className="grid grid-cols-3 gap-4">
              <div className="border border-blue-200 p-2 bg-blue-50 text-center">
                <div className="text-xl font-bold text-blue-700">150+</div>
                <div className="text-xs">Years of Maritime Legacy</div>
              </div>
              <div className="border border-blue-200 p-2 bg-blue-50 text-center">
                <div className="text-xl font-bold text-blue-700">40+</div>
                <div className="text-xs">Countries with ABL Offices</div>
              </div>
              <div className="border border-blue-200 p-2 bg-blue-50 text-center">
                <div className="text-xl font-bold text-blue-700">300+</div>
                <div className="text-xs">Global Locations</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Empty row */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">30</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
        
        {/* Section 5: Communication Strategy */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">31</div>
          <div className="w-96 border-r border-b border-gray-300 bg-blue-600 p-2 text-white font-bold" colSpan="2">5. COMMUNICATION STRATEGY</div>
          <div className="w-96 border-b border-gray-300" colSpan="3"></div>
        </div>
        
        {/* Row 32-33 - Key Messages */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">32</div>
          <div className="w-32 border-r border-b border-gray-300 bg-blue-100 p-1 font-bold text-blue-800">Key Messages</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <ul className="list-disc pl-5">
              <li><strong>Global Partner, Local Expert</strong> - delivering worldwide expertise with local understanding</li>
              <li><strong>Driving Sustainability in Energy and Oceans</strong> - supporting the energy transition</li>
              <li><strong>Deepest Pool of Technical Excellence</strong> - unmatched expertise across disciplines</li>
              <li><strong>Trusted Independent Advisor</strong> - objective consultancy for optimal solutions</li>
              <li><strong>Seeking the Truth</strong> - our guiding principle since 1856</li>
            </ul>
          </div>
        </div>
        
        {/* Row 33-34 - Elevator Pitch */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">33</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Elevator Pitch</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <p className="italic">"ABL Group brings unparalleled technical expertise to renewable energy projects, combining engineering excellence with marine operations knowledge to optimize performance, mitigate risks, and accelerate your clean energy goals. Our global team of specialists across offshore wind, marine engineering, and energy transition can provide integrated solutions to your most complex technical challenges."</p>
          </div>
        </div>
        
        {/* Row 34-35 - Delivery Channels */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">34</div>
          <div className="w-32 border-r border-b border-gray-300 p-1">Delivery Channels</div>
          <div className="w-192 border-b border-gray-300 p-1" colSpan="4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-bold">Primary</p>
                <ul className="list-disc pl-5">
                  <li>Direct client meetings & presentations</li>
                  <li>Technical workshops & webinars</li>
                  <li>Industry conference participation</li>
                  <li>Tailored technical reports & studies</li>
                </ul>
              </div>
              <div>
                <p className="font-bold">Supporting</p>
                <ul className="list-disc pl-5">
                  <li>Industry publications & white papers</li>
                  <li>LinkedIn & professional network sharing</li>
                  <li>Website technical content & case studies</li>
                  <li>Technical newsletters & updates</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        
        {/* More rows would continue... */}
        <div className="flex text-sm">
          <div className="w-20 border-r border-b border-gray-300 bg-gray-100 flex justify-center items-center font-bold">35</div>
          <div className="w-32 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-r border-b border-gray-300"></div>
          <div className="w-48 border-b border-gray-300"></div>
        </div>
      </div>
      
      <div className="text-xs text-gray-500 mt-6 text-center">
        ABL Group Value Proposition Builder - Excel Template • Driving Sustainability in Energy and Oceans • Last Updated: May 2025
      </div>
    </div>
  );
};

export default ValuePropositionBuilderExcel;
