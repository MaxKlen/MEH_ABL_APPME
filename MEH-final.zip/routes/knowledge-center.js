const express = require('express');
const router = express.Router();

// Knowledge Center main page
router.get('/', (req, res) => {
  // Mock data for knowledge resources
  const resources = [
    {
      id: 'kc-001',
      title: 'Offshore Wind Farm Development Guide',
      type: 'Guide',
      category: 'Renewables',
      tags: ['Offshore Wind', 'Development', 'Best Practices'],
      description: 'Comprehensive guide to offshore wind farm development from site selection to operations.',
      thumbnail: '/images/knowledge/offshore-wind-guide.jpg',
      datePublished: '2025-03-15',
      popularity: 'High'
    },
    {
      id: 'kc-002',
      title: 'Maritime Asset Integrity Management Framework',
      type: 'Framework',
      category: 'Maritime',
      tags: ['Asset Integrity', 'Management', 'Framework'],
      description: 'Framework for implementing effective asset integrity management for maritime assets.',
      thumbnail: '/images/knowledge/maritime-asset-integrity.jpg',
      datePublished: '2025-02-20',
      popularity: 'Medium'
    },
    {
      id: 'kc-003',
      title: 'Oil & Gas Decommissioning Best Practices',
      type: 'Best Practices',
      category: 'Oil & Gas',
      tags: ['Decommissioning', 'Best Practices', 'Environmental'],
      description: 'Best practices for environmentally responsible decommissioning of oil and gas assets.',
      thumbnail: '/images/knowledge/decommissioning.jpg',
      datePublished: '2025-01-10',
      popularity: 'High'
    },
    {
      id: 'kc-004',
      title: 'Energy Transition Strategy Framework',
      type: 'Framework',
      category: 'Energy Transition',
      tags: ['Strategy', 'Framework', 'Transition'],
      description: 'Strategic framework for organizations navigating the energy transition landscape.',
      thumbnail: '/images/knowledge/energy-transition.jpg',
      datePublished: '2025-04-05',
      popularity: 'Very High'
    },
    {
      id: 'kc-005',
      title: 'Floating Offshore Wind Technology Overview',
      type: 'Technical Paper',
      category: 'Renewables',
      tags: ['Floating Wind', 'Technology', 'Innovation'],
      description: 'Technical overview of floating offshore wind technologies and their applications.',
      thumbnail: '/images/knowledge/floating-wind.jpg',
      datePublished: '2025-03-28',
      popularity: 'Medium'
    },
    {
      id: 'kc-006',
      title: 'Digital Twin Implementation Guide',
      type: 'Guide',
      category: 'Digital',
      tags: ['Digital Twin', 'Implementation', 'Technology'],
      description: 'Step-by-step guide to implementing digital twin technology for energy assets.',
      thumbnail: '/images/knowledge/digital-twin.jpg',
      datePublished: '2025-02-15',
      popularity: 'High'
    }
  ];

  // Render the knowledge center page
  res.render('knowledge-center', {
    title: 'Knowledge Center - ABL Group Services Catalog',
    activeNav: 'knowledge',
    resources,
    ablAcademyUrl: 'https://ablacademy.myabsorb.eu/'
  });
});

// Knowledge resource details
router.get('/resources/:id', (req, res) => {
  const resourceId = req.params.id;
  
  // Mock data for a specific resource
  // In a real application, this would be fetched from a database
  const resource = {
    id: resourceId,
    title: 'Offshore Wind Farm Development Guide',
    type: 'Guide',
    category: 'Renewables',
    tags: ['Offshore Wind', 'Development', 'Best Practices'],
    description: 'Comprehensive guide to offshore wind farm development from site selection to operations.',
    content: 'This comprehensive guide covers all aspects of offshore wind farm development, including site selection, environmental impact assessment, design considerations, construction methodologies, and operations and maintenance strategies. It draws on ABL Group\'s extensive experience in the offshore wind sector and provides practical insights and best practices for developers, investors, and operators.',
    downloadUrl: '#',
    datePublished: '2025-03-15',
    author: 'ABL Group Renewables Team',
    relatedResources: [
      { id: 'kc-005', title: 'Floating Offshore Wind Technology Overview' },
      { id: 'kc-004', title: 'Energy Transition Strategy Framework' },
      { id: 'kc-006', title: 'Digital Twin Implementation Guide' }
    ]
  };
  
  // Render the resource details page
  res.render('resource-details', {
    title: `${resource.title} - ABL Group Services Catalog`,
    activeNav: 'knowledge',
    resource
  });
});

// ABL Academy redirect
router.get('/academy', (req, res) => {
  res.redirect('https://ablacademy.myabsorb.eu/');
});

module.exports = router;
