const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Load mock data
const services = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/services.json')));
const lifecycleStages = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/lifecycle-stages.json')));
const businessSegments = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/business-segments.json')));

// Energy Lifecycle Explorer page
router.get('/', (req, res) => {
  res.render('energy-lifecycle', {
    title: 'Energy Lifecycle Explorer',
    activeNav: 'lifecycle',
    lifecycleStages,
    services,
    businessSegments
  });
});

// Get services for a specific lifecycle stage
router.get('/stage/:stageId', (req, res) => {
  const stageId = req.params.stageId;
  const stage = lifecycleStages.find(s => s.id === stageId);
  
  if (!stage) {
    return res.status(404).json({ error: 'Lifecycle stage not found' });
  }
  
  // Get services for this stage
  const stageServices = stage.services.map(serviceId => {
    return services.find(s => s.id === serviceId);
  }).filter(Boolean);
  
  // Get bundle recommendations for this stage
  const bundles = stage.bundleRecommendations || [];
  
  res.json({
    stage,
    services: stageServices,
    bundles
  });
});

module.exports = router;
