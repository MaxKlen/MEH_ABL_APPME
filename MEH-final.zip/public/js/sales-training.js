// Sales Training Module Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Define moduleData globally first
    window.moduleData = {
      'client-communication': {
        title: 'Client Communication Fundamentals',
        description: 'Effective strategies for communicating with potential clients, building rapport, and understanding client needs.',
        sections: [
          {
            title: 'Initial Client Contact Strategies',
            content: `<p>The first interaction with a potential client sets the tone for the entire business relationship. Follow these key principles to make a positive first impression.</p>`
          },
          {
            title: 'Building Rapport Techniques',
            content: `<p>Building rapport is essential for developing long-term client relationships. Use these techniques to establish trust.</p>`
          },
          {
            title: 'Active Listening Skills',
            content: `<p>Use the HEAR framework to improve your active listening skills.</p>`
          },
          {
            title: 'Communication Templates',
            content: `<p>Use these templates as starting points, but always personalize them for each client.</p>`
          }
        ],
        resources: [
          {
            title: 'Client Communication Handbook',
            type: 'PDF',
            url: '/downloads/sales-training/client-communication-handbook.pdf'
          }
        ]
      },
      'business-discussions': {
        title: 'Initiating Business Discussions',
        description: 'Learn how to effectively introduce ABL Group\'s services, identify client pain points, and initiate conversations about new business opportunities.',
        sections: [
          {
            title: 'Value Proposition Delivery',
            content: `<p>A strong value proposition clearly communicates the unique benefits ABL Group offers to clients.</p>`
          },
          {
            title: 'Identifying Pain Points',
            content: `<p>Understanding typical challenges in each sector helps identify client needs.</p>`
          },
          {
            title: 'Opportunity Identification',
            content: `<p>Use this systematic approach to identify business opportunities.</p>`
          }
        ],
        resources: [
          {
            title: 'Business Development Toolkit',
            type: 'PDF',
            url: '/downloads/sales-training/business-development-toolkit.pdf'
          }
        ]
      },
      'client-relationships': {
        title: 'Improving Client Relationships',
        description: 'Strategies for nurturing and strengthening client relationships, proactive communication, and addressing client inquiries professionally.',
        sections: [
          {
            title: 'Relationship Nurturing',
            content: `<p>Understanding the current stage of a client relationship helps determine appropriate nurturing strategies.</p>`
          },
          {
            title: 'Proactive Communication',
            content: `<p>Stay ahead of client needs with this proactive communication approach.</p>`
          },
          {
            title: 'Addressing Inquiries',
            content: `<p>Follow this protocol to ensure professional and effective responses to client inquiries.</p>`
          }
        ],
        resources: [
          {
            title: 'Client Relationship Management Guide',
            type: 'PDF',
            url: '/downloads/sales-training/client-relationship-guide.pdf'
          }
        ]
      },
      'lead-qualification': {
        title: 'Lead/Opportunity Qualification',
        description: 'Methodologies for identifying and qualifying potential leads and opportunities, assessing viability, and understanding client decision-making processes.',
        sections: [
          {
            title: 'Qualification Criteria',
            content: `<p>Use these criteria to evaluate potential leads and opportunities.</p>`
          },
          {
            title: 'BANT Framework',
            content: `<p>The BANT framework helps assess if a lead is worth pursuing.</p>`
          },
          {
            title: 'Opportunity Scoring',
            content: `<p>Score opportunities based on these key factors to prioritize your efforts.</p>`
          }
        ],
        resources: [
          {
            title: 'Lead Qualification Handbook',
            type: 'PDF',
            url: '/downloads/sales-training/lead-qualification-handbook.pdf'
          }
        ]
      },
      'technical-solution-selling': {
        title: 'Technical Solution Selling',
        description: 'Techniques for translating technical capabilities into business value, presenting complex solutions, and addressing technical objections.',
        sections: [
          {
            title: 'Technical to Business Translation',
            content: `<p>Learn how to translate technical features into business benefits that resonate with decision-makers.</p>`
          },
          {
            title: 'Solution Presentation',
            content: `<p>Structure your presentations to highlight value and address client needs effectively.</p>`
          },
          {
            title: 'Handling Technical Objections',
            content: `<p>Prepare for and address common technical objections with confidence.</p>`
          }
        ],
        resources: [
          {
            title: 'Technical Solution Selling Guide',
            type: 'PDF',
            url: '/downloads/sales-training/technical-solution-selling-guide.pdf'
          }
        ]
      },
      'business-development-planning': {
        title: 'Business Development Planning',
        description: 'Strategies for identifying target markets, creating account plans, and developing systematic business development approaches.',
        sections: [
          {
            title: 'Market Segmentation',
            content: `<p>Identify and prioritize market segments based on strategic fit and growth potential.</p>`
          },
          {
            title: 'Account Planning',
            content: `<p>Create structured account plans to guide your business development efforts.</p>`
          },
          {
            title: 'Business Development Metrics',
            content: `<p>Track these key metrics to measure the effectiveness of your business development activities.</p>`
          }
        ],
        resources: [
          {
            title: 'Business Development Planning Template',
            type: 'Excel',
            url: '/downloads/sales-training/business-development-planning-template.xlsx'
          }
        ]
      }
    };
  
    // Module view functionality
    const viewModuleBtns = document.querySelectorAll('.view-module-btn');
    const moduleContentCard = document.getElementById('module-content-card');
    const moduleTitle = document.getElementById('module-title');
    const moduleDescription = document.getElementById('module-description');
    const moduleSections = document.getElementById('module-sections');
    const moduleResources = document.getElementById('module-resources');
    const closeModuleBtn = document.getElementById('close-module-btn');
    
    if (viewModuleBtns.length > 0 && moduleContentCard) {
        viewModuleBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const moduleId = this.getAttribute('data-module');
                showModuleContent(moduleId);
            });
        });
        
        if (closeModuleBtn) {
            closeModuleBtn.addEventListener('click', function() {
                moduleContentCard.style.display = 'none';
            });
        }
    }
    
    function showModuleContent(moduleId) {
        const module = moduleData[moduleId];
        if (!module) return;
        
        // Set module title and description
        moduleTitle.textContent = module.title;
        moduleDescription.textContent = module.description;
        
        // Clear existing content
        moduleSections.innerHTML = '';
        moduleResources.innerHTML = '';
        
        // Add sections
        if (module.sections && module.sections.length > 0) {
            module.sections.forEach(section => {
                const sectionEl = document.createElement('div');
                sectionEl.className = 'mb-4';
                sectionEl.innerHTML = `
                    <h4>${section.title}</h4>
                    ${section.content}
                `;
                moduleSections.appendChild(sectionEl);
            });
        }
        
        // Add resources
        if (module.resources && module.resources.length > 0) {
            module.resources.forEach(resource => {
                const resourceEl = document.createElement('a');
                resourceEl.className = 'list-group-item list-group-item-action';
                resourceEl.href = resource.url;
                resourceEl.target = '_blank';
                
                let icon = 'fa-file';
                if (resource.type === 'PDF') icon = 'fa-file-pdf';
                else if (resource.type === 'Excel') icon = 'fa-file-excel';
                else if (resource.type === 'Word') icon = 'fa-file-word';
                else if (resource.type === 'Video') icon = 'fa-video';
                
                resourceEl.innerHTML = `
                    <div class="d-flex align-items-center">
                        <i class="fas ${icon} text-primary me-3"></i>
                        <div>
                            <h5 class="mb-1">${resource.title}</h5>
                            <small>${resource.type}</small>
                        </div>
                    </div>
                `;
                
                moduleResources.appendChild(resourceEl);
            });
        }
        
        // Show the module content card
        moduleContentCard.style.display = 'block';
        
        // Scroll to the content card
        moduleContentCard.scrollIntoView({ behavior: 'smooth' });
    }
    
    // Check if there's a module parameter in the URL
    const urlParams = new URLSearchParams(window.location.search);
    const moduleParam = urlParams.get('module');
    if (moduleParam && moduleData[moduleParam]) {
        // Show the specified module content
        showModuleContent(moduleParam);
    }
});
