const express = require('express');
const router = express.Router();
const axios = require('axios');

// Lead form page
router.get('/', (req, res) => {
  // Get bundle ID from query parameter if it exists
  const bundleId = req.query.bundle || '';
  
  res.render('lead-form', {
    title: 'Request Services - ABL Group Services Catalog',
    activeNav: 'lead-form',
    bundleId,
    zohoUrl: 'https://crm.zoho.com/crm/WebToLeadForm'
  });
});

// Process lead form submission
router.post('/submit', async (req, res) => {
  try {
    // Log the form submission
    console.log('Lead form submitted:', req.body);
    
    // In a real implementation, we would use the Zoho CRM API to create a lead
    // This is a simulated API call to Zoho CRM
    const zohoResponse = await simulateZohoApiCall(req.body);
    
    console.log('Zoho CRM response:', zohoResponse);
    
    // Render success page
    res.render('lead-form-success', {
      title: 'Thank You - ABL Group Services Catalog',
      activeNav: 'lead-form'
    });
  } catch (error) {
    console.error('Error submitting lead to Zoho CRM:', error);
    res.status(500).render('error', {
      title: 'Error - ABL Group Services Catalog',
      message: 'There was an error submitting your request. Please try again later.',
      error: {}
    });
  }
});

// Simulate a Zoho CRM API call
async function simulateZohoApiCall(formData) {
  // In a real implementation, this would use the Zoho CRM API
  // For demo purposes, we'll simulate a successful API response
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return {
    status: 'success',
    message: 'Lead created successfully',
    data: {
      id: 'LEAD_' + Math.floor(Math.random() * 1000000),
      created_time: new Date().toISOString()
    }
  };
}

module.exports = router;
