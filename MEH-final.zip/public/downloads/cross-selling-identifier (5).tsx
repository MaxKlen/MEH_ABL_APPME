import React from 'react';

const CrossSellingIdentifier = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-blue-800 mb-1">ABL Group Cross-Selling Identifier</h1>
        <p className="text-gray-600 italic">Leveraging Our Full-Service Capabilities Across Energy and Oceans</p>
      </div>
      
      <div className="bg-blue-50 p-4 rounded-md mb-6">
        <h2 className="text-lg font-semibold text-blue-700 mb-2">Purpose & Value</h2>
        <p className="text-gray-700 mb-3">This cross-selling tool helps ABL Group professionals identify complementary service opportunities across our business units and sectors. By recognizing how our diverse expertise can address clients' broader needs, we deliver more comprehensive solutions while increasing our service value. This approach supports our clients' journey toward sustainable operations in energy and marine sectors.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mt-4">
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">Benefits to Clients</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Access to broader technical expertise</li>
              <li>More integrated solutions to complex challenges</li>
              <li>Reduced need for multiple service providers</li>
              <li>Consistent quality across service areas</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">Benefits to ABL Group</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Increased service value per client</li>
              <li>Deeper client relationships</li>
              <li>More effective resource utilization</li>
              <li>Enhanced reputation as comprehensive provider</li>
            </ul>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <h3 className="font-medium text-blue-600 mb-1">How to Use This Tool</h3>
            <ul className="list-disc pl-4 text-gray-700">
              <li>Identify your client's current service area</li>
              <li>Review complementary services</li>
              <li>Assess opportunity level & timing</li>
              <li>Consult relevant group experts</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Cross-Selling Matrix: Renewables Sector</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Primary Service</th>
                  <th className="p-2 text-left">Complementary Services</th>
                  <th className="p-2 text-left">Client Trigger Indicators</th>
                  <th className="p-2 text-left">Opportunity Level</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Offshore Wind Technical Advisory<br /><span className="text-xs text-gray-500">OWC</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Marine Warranty Survey (ABL)</li>
                      <li>Marine Operations Engineering (Longitude)</li>
                      <li>Floating Foundation Design (Innosea)</li>
                      <li>Cable Engineering (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Project advancing to FEED/detailed design</li>
                      <li>Discussion of installation challenges</li>
                      <li>Concern about marine operations risk</li>
                      <li>Interest in floating wind solutions</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Floating Solar Engineering<br /><span className="text-xs text-gray-500">Innosea</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Marine Warranty Survey (ABL)</li>
                      <li>Metocean Analysis (OWC)</li>
                      <li>Mooring System Design (Longitude)</li>
                      <li>Energy Yield Assessment (OWC)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Early stage project development</li>
                      <li>Questions about environmental conditions</li>
                      <li>Interest in hybrid energy systems</li>
                      <li>Installation planning discussions</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Marine Warranty Survey for Renewables<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Transportation & Installation Engineering (Longitude)</li>
                      <li>Technical Due Diligence (OWC)</li>
                      <li>Dynamic Cable Analysis (Innosea)</li>
                      <li>Operations & Maintenance Advisory (OWC)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Complex installation challenges identified</li>
                      <li>Discussions about long-term operations</li>
                      <li>Project financing questions</li>
                      <li>Cable system reliability concerns</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Wind Resource Assessment<br /><span className="text-xs text-gray-500">OWC</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Site Suitability Analysis (OWC)</li>
                      <li>Geotechnical & Geophysical Services (East Point Geo)</li>
                      <li>Foundation Concept Design (Innosea)</li>
                      <li>Owner's Engineering (OWC)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Early stage project development</li>
                      <li>Site selection discussions</li>
                      <li>Questions about seabed conditions</li>
                      <li>Interest in project optimization</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Wave & Tidal Energy Engineering<br /><span className="text-xs text-gray-500">Innosea</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Metocean Analysis (OWC)</li>
                      <li>Structural Engineering (Longitude)</li>
                      <li>Environmental Impact Assessment Support (OWC)</li>
                      <li>Marine Operations Advisory (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Technology development stage</li>
                      <li>Discussion of deployment challenges</li>
                      <li>Environmental permitting questions</li>
                      <li>Structural integrity concerns</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Cross-Selling Matrix: Maritime Sector</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Primary Service</th>
                  <th className="p-2 text-left">Complementary Services</th>
                  <th className="p-2 text-left">Client Trigger Indicators</th>
                  <th className="p-2 text-left">Opportunity Level</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Marine Casualty Response<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Marine Engineering (Longitude)</li>
                      <li>Salvage Engineering & Naval Architecture (ABL)</li>
                      <li>Expert Witness Services (ABL)</li>
                      <li>Environmental Impact Assessment (OWC)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Complex casualty with structural damage</li>
                      <li>Legal/insurance proceedings initiated</li>
                      <li>Environmental concerns raised</li>
                      <li>Challenging salvage operation</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Port & Harbor Consultancy<br /><span className="text-xs text-gray-500">ABL/Longitude</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Navigational Risk Assessment (ABL)</li>
                      <li>Marine Civil Engineering (Longitude)</li>
                      <li>Clean Shipping/Shore Power Engineering (ABL)</li>
                      <li>Renewable Energy Integration (OWC)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Port expansion/modernization plans</li>
                      <li>Increasing vessel sizes/traffic</li>
                      <li>Decarbonization initiatives</li>
                      <li>Interest in energy self-sufficiency</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Vessel Condition Surveys<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Clean Shipping Engineering (ABL)</li>
                      <li>Naval Architecture Services (Longitude)</li>
                      <li>Structural Integrity Assessment (ABL)</li>
                      <li>DP System Verification (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Vessel age >15 years</li>
                      <li>Emissions compliance concerns</li>
                      <li>Conversion/repurposing discussions</li>
                      <li>Advanced positioning requirements</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Superyacht Services<br /><span className="text-xs text-gray-500">ABL Yachts</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Technical Due Diligence (ABL)</li>
                      <li>Marine Engineering (Longitude)</li>
                      <li>Clean Propulsion Solutions (ABL)</li>
                      <li>Energy Management Systems (OWC)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Yacht purchase/sale transactions</li>
                      <li>Refit or upgrade discussions</li>
                      <li>Interest in sustainability features</li>
                      <li>Energy efficiency concerns</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">Low</span></td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Marine Warranty Survey<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Transportation & Installation Engineering (Longitude)</li>
                      <li>Marine Operations Consultancy (ABL)</li>
                      <li>Risk Assessment Services (ABL)</li>
                      <li>DP Assurance Services (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Complex cargo/high value assets</li>
                      <li>Challenging marine operation</li>
                      <li>Specialized vessel requirements</li>
                      <li>Operations in harsh environments</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Cross-Selling Matrix: Oil & Gas Sector</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Primary Service</th>
                  <th className="p-2 text-left">Complementary Services</th>
                  <th className="p-2 text-left">Client Trigger Indicators</th>
                  <th className="p-2 text-left">Opportunity Level</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Asset Integrity Management<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Structural Engineering (Longitude)</li>
                      <li>Underwater Inspection Services (ABL)</li>
                      <li>Risk-Based Inspection Planning (ABL)</li>
                      <li>Digital Twin Solutions (AGR)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Aging assets (>15 years)</li>
                      <li>Life extension discussions</li>
                      <li>Recent inspection findings</li>
                      <li>Digital transformation initiatives</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Marine Warranty Survey for O&G<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Marine Operations Engineering (Longitude)</li>
                      <li>DP Assurance Services (ABL)</li>
                      <li>Transportation Engineering (ABL)</li>
                      <li>Installation Engineering (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Complex offshore installation project</li>
                      <li>Multiple high-value critical lifts</li>
                      <li>Operations in challenging environments</li>
                      <li>Tight project schedules</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Well Management Services<br /><span className="text-xs text-gray-500">AGR</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Rig Inspection Services (ABL)</li>
                      <li>Marine Operations Advisory (ABL)</li>
                      <li>Carbon Capture & Storage Solutions (AGR)</li>
                      <li>Digital & Software Solutions (AGR)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Drilling campaign planning</li>
                      <li>Rig selection/contracting phase</li>
                      <li>Interest in emission reduction</li>
                      <li>Operational efficiency focus</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Pipeline Engineering<br /><span className="text-xs text-gray-500">ABL/Longitude</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Marine Warranty Survey (ABL)</li>
                      <li>Geophysical Services (East Point Geo)</li>
                      <li>Metocean Analysis (OWC)</li>
                      <li>Installation Engineering (Longitude)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Early stage pipeline planning</li>
                      <li>Complex seabed conditions</li>
                      <li>Challenging metocean environment</li>
                      <li>Project entering FEED phase</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Rig Moving Services<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Site Assessment Services (ABL)</li>
                      <li>Marine Operations Advisory (ABL)</li>
                      <li>Geotechnical Services (East Point Geo)</li>
                      <li>Metocean Analysis (OWC)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>New drilling location planning</li>
                      <li>Limited site data available</li>
                      <li>Challenging seabed conditions</li>
                      <li>Operations in new geography</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Cross-Selling Matrix: Energy Transition</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Primary Service</th>
                  <th className="p-2 text-left">Complementary Services</th>
                  <th className="p-2 text-left">Client Trigger Indicators</th>
                  <th className="p-2 text-left">Opportunity Level</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Hydrogen & Alternative Fuels<br /><span className="text-xs text-gray-500">OWC/Innosea</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Offshore Wind Advisory (OWC)</li>
                      <li>Floating Structures Engineering (Innosea)</li>
                      <li>Infrastructure Engineering (Longitude)</li>
                      <li>Risk & Safety Analysis (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Green hydrogen projects</li>
                      <li>Offshore energy production interest</li>
                      <li>Decarbonization strategy focus</li>
                      <li>New infrastructure considerations</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Carbon Capture & Storage<br /><span className="text-xs text-gray-500">AGR</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Subsurface & Reservoir Engineering (AGR)</li>
                      <li>Well Integrity Services (AGR)</li>
                      <li>Offshore Infrastructure Assessment (ABL)</li>
                      <li>Transportation & Storage Analysis (Longitude)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Net-zero commitments</li>
                      <li>Depleted reservoir repurposing</li>
                      <li>Infrastructure reuse considerations</li>
                      <li>Regulatory compliance discussions</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Emissions Reduction Consulting<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Clean Shipping Engineering (ABL)</li>
                      <li>Energy Efficiency Solutions (OWC)</li>
                      <li>Offshore Electrification (Longitude)</li>
                      <li>Digital Emissions Monitoring (AGR)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Corporate ESG targets</li>
                      <li>Regulatory compliance challenges</li>
                      <li>Operational cost concerns</li>
                      <li>Interest in emissions verification</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">High</span></td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="p-2 font-medium">Clean Shipping Engineering<br /><span className="text-xs text-gray-500">ABL</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Alternative Fuel Systems (ABL)</li>
                      <li>Energy Efficiency Analysis (ABL)</li>
                      <li>Marine Engineering & Naval Architecture (Longitude)</li>
                      <li>Regulatory Compliance Advisory (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>IMO 2050 compliance planning</li>
                      <li>Fleet modernization discussions</li>
                      <li>Alternative fuel interest</li>
                      <li>Vessel conversion considerations</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Energy Storage Solutions<br /><span className="text-xs text-gray-500">OWC</span></td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Renewables Integration (OWC)</li>
                      <li>Electrical Engineering (OWC)</li>
                      <li>Energy Management Systems (OWC)</li>
                      <li>Safety & Risk Assessment (ABL)</li>
                    </ul>
                  </td>
                  <td className="p-2">
                    <ul className="list-disc pl-4">
                      <li>Renewable energy variability concerns</li>
                      <li>Grid stability discussions</li>
                      <li>Hybrid energy system interest</li>
                      <li>Microgrids for remote operations</li>
                    </ul>
                  </td>
                  <td className="p-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-blue-700 mb-3">Cross-Selling Approach Guide</h2>
        <div className="border border-gray-300 rounded-md p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Best Practices for Cross-Selling</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2"><strong>Client-Centered Approach</strong> – Focus on solving client challenges, not just selling services</li>
                  <li className="mb-2"><strong>Value Articulation</strong> – Clearly explain the benefits of integrated services</li>
                  <li className="mb-2"><strong>Internal Collaboration</strong> – Involve relevant specialists in client discussions early</li>
                  <li className="mb-2"><strong>Timing Sensitivity</strong> – Introduce complementary services at appropriate project phases</li>
                  <li className="mb-2"><strong>Technical Credibility</strong> – Maintain focus on ABL Group's technical excellence</li>
                </ul>
              </div>
            </div>
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Conversation Starters</h4>
              <div className="bg-white p-3 rounded border border-gray-200">
                <ul className="list-disc pl-5 text-gray-700 text-sm">
                  <li className="mb-2">"As we're discussing [current service], have you considered how [complementary service] might enhance your approach to [client challenge]?"</li>
                  <li className="mb-2">"Many of our clients with similar projects have found value in combining [current service] with [complementary service] to address [specific benefit]."</li>
                  <li className="mb-2">"Based on what you've shared about [client challenge], our [business unit] specialists might offer some valuable insights. Would it be helpful to include them in our next discussion?"</li>
                  <li className="mb-2">"As your project progresses to [next phase], you might benefit from our expertise in [complementary service]. Would you like to learn more about our approach?"</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <h4 className="font-medium text-blue-600 mb-2">Internal Coordination Process</h4>
            <div className="bg-white p-3 rounded border border-gray-200">
              <ol className="list-decimal pl-5 text-gray-700 text-sm">
                <li className="mb-2"><strong>Identify Opportunity</strong> – Use this matrix to identify relevant complementary services</li>
                <li className="mb-2"><strong>Internal Consultation</strong> – Contact relevant business unit/specialist to discuss the client's specific needs</li>
                <li className="mb-2"><strong>Coordinated Approach</strong> – Develop joint value proposition before presenting to client</li>
                <li className="mb-2"><strong>Client Introduction</strong> – Formally introduce specialists to the client at appropriate time</li>
                <li className="mb-2"><strong>Feedback Loop</strong> – Document success stories and lessons learned to improve future cross-selling</li>
              </ol>
            </div>
          </div>
          <div className="bg-yellow-50 p-3 rounded mt-4">
            <h4 className="font-medium text-yellow-800 mb-1">Important Reminders</h4>
            <ul className="list-disc pl-5 text-gray-700 text-sm">
              <li className="mb-1">All ABL Group services maintain our core values: Safety, Technical Excellence, Collaboration, Innovation, and Truth</li>
              <li className="mb-1">Cross-selling success depends on genuine understanding of client needs</li>
              <li className="mb-1">Our independence and technical integrity remain paramount</li>
              <li className="mb-1">Coordinate internally before approaching clients with multi-service solutions</li>
              <li className="mb-1">Document successful cross-selling cases for organizational learning</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="text-xs text-gray-500 mt-6 text-center">
        ABL Group Cross-Selling Identifier • Driving Sustainability in Energy and Oceans • Last Updated: May 2025
      </div>
    </div>
  );
};

export default CrossSellingIdentifier;
