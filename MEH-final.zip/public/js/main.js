// Create a simple SVG logo for ABL Group
document.addEventListener('DOMContentLoaded', function() {
  // Check if we need to create a placeholder logo
  const logoImages = document.querySelectorAll('.header-logo');
  
  logoImages.forEach(img => {
    img.onerror = function() {
      // If the logo image fails to load, create an SVG logo
      const svgLogo = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svgLogo.setAttribute("width", "40");
      svgLogo.setAttribute("height", "40");
      svgLogo.setAttribute("viewBox", "0 0 40 40");
      svgLogo.setAttribute("class", "header-logo");
      
      // Create the ABL text
      const textABL = document.createElementNS("http://www.w3.org/2000/svg", "text");
      textABL.setAttribute("x", "5");
      textABL.setAttribute("y", "25");
      textABL.setAttribute("fill", "#0d6efd");
      textABL.setAttribute("font-weight", "bold");
      textABL.setAttribute("font-size", "16");
      textABL.textContent = "ABL";
      
      // Create the Group text
      const textGroup = document.createElementNS("http://www.w3.org/2000/svg", "text");
      textGroup.setAttribute("x", "10");
      textGroup.setAttribute("y", "35");
      textGroup.setAttribute("fill", "#198754");
      textGroup.setAttribute("font-style", "italic");
      textGroup.setAttribute("font-size", "10");
      textGroup.textContent = "GROUP";
      
      svgLogo.appendChild(textABL);
      svgLogo.appendChild(textGroup);
      
      // Replace the img with the SVG
      img.parentNode.replaceChild(svgLogo, img);
    };
  });
  
  // Initialize tooltips
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
  
  // Initialize popovers
  const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
  popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl);
  });
  
  // Lifecycle explorer interaction
  const lifecycleStages = document.querySelectorAll('.lifecycle-stage');
  if (lifecycleStages.length > 0) {
    lifecycleStages.forEach(stage => {
      stage.addEventListener('click', function() {
        // Remove active class from all stages
        lifecycleStages.forEach(s => s.classList.remove('active'));
        
        // Add active class to clicked stage
        this.classList.add('active');
        
        // Get the stage name from data-stage attribute
        const stageName = this.getAttribute('data-stage');
        
        // Update content based on selected stage
        updateLifecycleContent(stageName);
        
        // Update the URL hash to reflect the current stage
        window.location.hash = stageName;
      });
    });
    
    // Check if there's a hash in the URL to set the active stage
    const hashStage = window.location.hash.substring(1);
    if (hashStage && document.querySelector(`.lifecycle-stage[data-stage="${hashStage}"]`)) {
      // Set the stage from URL hash as active
      document.querySelector(`.lifecycle-stage[data-stage="${hashStage}"]`).classList.add('active');
      updateLifecycleContent(hashStage);
    } else {
      // Set first stage as active by default
      lifecycleStages[0].classList.add('active');
      const defaultStageName = lifecycleStages[0].getAttribute('data-stage');
      updateLifecycleContent(defaultStageName);
    }
  }
  
  // Function to update lifecycle content based on selected stage
  function updateLifecycleContent(stageName) {
    console.log('Updating content for stage:', stageName);
    
    // Hide all content sections first
    const allContentSections = document.querySelectorAll('.lifecycle-content');
    if (allContentSections.length > 0) {
      allContentSections.forEach(section => {
        section.style.display = 'none';
      });
    }
    
    // Show the content for the selected stage
    const selectedContent = document.querySelector(`.lifecycle-content[data-stage="${stageName}"]`);
    if (selectedContent) {
      selectedContent.style.display = 'block';
    } else {
      // If no specific content section exists, create dynamic content
      createDynamicLifecycleContent(stageName);
    }
    
    // Update the stage title in the UI
    const stageTitle = document.getElementById('lifecycle-stage-title');
    if (stageTitle) {
      stageTitle.textContent = stageName.charAt(0).toUpperCase() + stageName.slice(1);
    }
    
    // Update services related to this lifecycle stage if on services page
    updateServicesForLifecycleStage(stageName);
  }
  
  // Function to create dynamic content if no static content exists
  function createDynamicLifecycleContent(stageName) {
    const contentContainer = document.getElementById('lifecycle-content-container');
    if (!contentContainer) return;
    
    // Clear existing dynamic content
    const existingDynamic = document.querySelector('.lifecycle-content-dynamic');
    if (existingDynamic) {
      existingDynamic.remove();
    }
    
    // Create new content section
    const newContent = document.createElement('div');
    newContent.className = 'lifecycle-content lifecycle-content-dynamic';
    newContent.setAttribute('data-stage', stageName);
    
    // Set content based on stage
    let stageContent = '';
    let stageServices = [];
    
    switch(stageName) {
      case 'concept':
        stageContent = 'The Concept phase focuses on initial project ideas, market analysis, and preliminary feasibility studies.';
        stageServices = ['Concept Development', 'Market Analysis', 'Preliminary Feasibility'];
        break;
      case 'feasibility':
        stageContent = 'The Feasibility phase evaluates technical, economic, and environmental viability of the project.';
        stageServices = ['Technical Feasibility Studies', 'Economic Analysis', 'Environmental Screening'];
        break;
      case 'development':
        stageContent = 'The Development phase includes detailed engineering, planning, and preparation for construction.';
        stageServices = ['FEED Studies', 'Detailed Engineering', 'Project Planning'];
        break;
      case 'construction':
        stageContent = 'The Construction phase covers building, installation, and commissioning of project assets.';
        stageServices = ['Construction Management', 'Quality Assurance', 'Commissioning Support'];
        break;
      case 'operations':
        stageContent = 'The Operations phase focuses on running, maintaining, and optimizing operational assets.';
        stageServices = ['Asset Integrity Management', 'Performance Optimization', 'Maintenance Strategy'];
        break;
      case 'decommissioning':
        stageContent = 'The Decommissioning phase handles safe and environmentally responsible project closure.';
        stageServices = ['Decommissioning Planning', 'Environmental Compliance', 'Site Restoration'];
        break;
      default:
        stageContent = 'Explore our services across different stages of the energy lifecycle.';
        stageServices = [];
    }
    
    // Build the HTML content
    let html = `
      <h4>${stageName.charAt(0).toUpperCase() + stageName.slice(1)} Stage</h4>
      <p>${stageContent}</p>
    `;
    
    if (stageServices.length > 0) {
      html += '<h5>Key Services:</h5><ul>';
      stageServices.forEach(service => {
        html += `<li>${service}</li>`;
      });
      html += '</ul>';
    }
    
    html += `<a href="/services?lifecycle=${stageName}" class="btn btn-primary mt-3">View ${stageName.charAt(0).toUpperCase() + stageName.slice(1)} Services</a>`;
    
    newContent.innerHTML = html;
    contentContainer.appendChild(newContent);
    newContent.style.display = 'block';
  }
  
  // Function to update services based on lifecycle stage
  function updateServicesForLifecycleStage(stageId) {
    const serviceCards = document.querySelectorAll('.service-card');
    if (serviceCards.length > 0) {
      serviceCards.forEach(card => {
        const cardStages = card.getAttribute('data-stages').split(',');
        if (stageId === 'all' || cardStages.includes(stageId)) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    }
  }
  
  // Service filter functionality
  const serviceFilters = document.querySelectorAll('.service-filter');
  if (serviceFilters.length > 0) {
    serviceFilters.forEach(filter => {
      filter.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all filters
        serviceFilters.forEach(f => f.classList.remove('active'));
        
        // Add active class to clicked filter
        this.classList.add('active');
        
        // Update services list based on selected filter
        const filterValue = this.getAttribute('data-filter');
        filterServices(filterValue);
      });
    });
  }
  
  // Function to filter services
  function filterServices(filterValue) {
    const serviceCards = document.querySelectorAll('.service-card');
    if (serviceCards.length > 0) {
      serviceCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (filterValue === 'all' || cardCategory === filterValue) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    }
  }
  
  // Lead form validation
  const leadForm = document.getElementById('leadForm');
  if (leadForm) {
    leadForm.addEventListener('submit', function(event) {
      if (!leadForm.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      
      leadForm.classList.add('was-validated');
    });
  }
});
