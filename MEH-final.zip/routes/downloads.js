const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

// Ensure downloads directory exists
const downloadsDir = path.join(__dirname, '../public/downloads');
if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
}

// Ensure services downloads directory exists
const servicesDownloadsDir = path.join(downloadsDir, 'services');
if (!fs.existsSync(servicesDownloadsDir)) {
    fs.mkdirSync(servicesDownloadsDir, { recursive: true });
}

// Ensure sales training downloads directory exists
const salesTrainingDir = path.join(downloadsDir, 'sales-training');
if (!fs.existsSync(salesTrainingDir)) {
    fs.mkdirSync(salesTrainingDir, { recursive: true });
}

// Function to generate PDF using HTML content
function generatePDF(htmlContent, outputPath) {
    return new Promise((resolve, reject) => {
        // Create temporary HTML file
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }
        
        const tempHtmlPath = path.join(tempDir, `temp-${Date.now()}.html`);
        
        // Add proper HTML structure with styling
        const fullHtmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>ABL Group Document</title>
            <style>
                body { 
                    font-family: Arial, sans-serif;
                    margin: 40px;
                    line-height: 1.6;
                }
                h1, h2, h3 { color: #0d6efd; }
                .header {
                    text-align: center;
                    margin-bottom: 30px;
                    border-bottom: 2px solid #0d6efd;
                    padding-bottom: 10px;
                }
                .logo {
                    max-width: 200px;
                    margin-bottom: 20px;
                }
                .content {
                    margin-top: 20px;
                }
                .footer {
                    margin-top: 50px;
                    text-align: center;
                    font-size: 12px;
                    color: #666;
                    border-top: 1px solid #ddd;
                    padding-top: 10px;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>ABL Group</h1>
                <p>Professional Services Documentation</p>
            </div>
            <div class="content">
                ${htmlContent}
            </div>
            <div class="footer">
                <p>© ${new Date().getFullYear()} ABL Group. All rights reserved.</p>
                <p>This document is confidential and intended for internal use only.</p>
            </div>
        </body>
        </html>
        `;
        
        fs.writeFileSync(tempHtmlPath, fullHtmlContent);
        
        // Use wkhtmltopdf (commonly available on Linux) to convert HTML to PDF
        exec(`wkhtmltopdf ${tempHtmlPath} ${outputPath}`, (error, stdout, stderr) => {
            // Clean up temp file
            try {
                fs.unlinkSync(tempHtmlPath);
            } catch (e) {
                console.error('Error removing temp file:', e);
            }
            
            if (error) {
                console.error(`Error generating PDF: ${error}`);
                // Fallback to creating a text file with .pdf extension
                fs.writeFileSync(outputPath, htmlContent);
                resolve(outputPath);
                return;
            }
            
            console.log(`PDF generated at: ${outputPath}`);
            resolve(outputPath);
        });
    });
}

// Generate sales training PDFs if they don't exist
async function ensureSalesTrainingPDFs() {
    const clientCommPath = path.join(salesTrainingDir, 'client-communication-handbook.pdf');
    const techSolutionPath = path.join(salesTrainingDir, 'technical-solution-selling-guide.pdf');
    const leadQualPath = path.join(salesTrainingDir, 'lead-qualification-handbook.pdf');
    
    if (!fs.existsSync(clientCommPath)) {
        // Read HTML content from template file
        const clientCommHtmlPath = path.join(__dirname, '../templates/downloads/client_communication_handbook.html');
        const clientCommContent = fs.readFileSync(clientCommHtmlPath, 'utf8');
        
        await generatePDF(clientCommContent, clientCommPath);
    }
    
    if (!fs.existsSync(techSolutionPath)) {
        // Read HTML content from template file
        const techSolutionHtmlPath = path.join(__dirname, "../templates/downloads/technical_solution_selling_guide.html");
        const techSolutionContent = fs.readFileSync(techSolutionHtmlPath, "utf8");
      
        await generatePDF(techSolutionContent, techSolutionPath);
    }
    
    if (!fs.existsSync(leadQualPath)) {
        // Read HTML content from template file
        const leadQualHtmlPath = path.join(__dirname, "../templates/downloads/lead_qualification_handbook.html"); // Corrected path
        const leadQualContent = fs.readFileSync(leadQualHtmlPath, "utf8");
        
        await generatePDF(leadQualContent, leadQualPath);
    }
}

// Generate PDFs on startup
ensureSalesTrainingPDFs();

// Route to handle downloads
router.get('/services/:serviceId/:filename', (req, res) => {
    const { serviceId, filename } = req.params;
    
    // Create service directory if it doesn't exist
    const serviceDir = path.join(servicesDownloadsDir, serviceId);
    if (!fs.existsSync(serviceDir)) {
        fs.mkdirSync(serviceDir, { recursive: true });
    }
    
    // Path to the requested file
    const filePath = path.join(serviceDir, filename);
    
    // Check if file exists
    if (fs.existsSync(filePath)) {
        // Set proper content type for PDF files
        if (filename.endsWith('.pdf')) {
            res.setHeader('Content-Type', 'application/pdf');
        }
        // File exists, send it
        res.download(filePath);
    } else {
        // File doesn't exist, generate a PDF
        const htmlContent = `
        <h1>${filename.replace('.pdf', '')}</h1>
        <h2>Service: ${serviceId}</h2>
        <p>This document provides detailed information about the ${serviceId} service offered by ABL Group.</p>
        <p>In a production environment, this would contain comprehensive service documentation.</p>
        `;
        
        const outputPath = filePath;
        
        generatePDF(htmlContent, outputPath)
            .then(() => {
                // Set proper content type for PDF files
                if (filename.endsWith('.pdf')) {
                    res.setHeader('Content-Type', 'application/pdf');
                }
                res.download(outputPath);
            })
            .catch(err => {
                console.error('Error generating PDF:', err);
                res.status(500).send('Error generating document');
            });
    }
});

// Route for general downloads
router.get('/:category/:filename', (req, res) => {
    const { category, filename } = req.params;
    
    // Create category directory if it doesn't exist
    const categoryDir = path.join(downloadsDir, category);
    if (!fs.existsSync(categoryDir)) {
        fs.mkdirSync(categoryDir, { recursive: true });
    }
    
    // Path to the requested file
    const filePath = path.join(categoryDir, filename);
    
    // Check if file exists
    if (fs.existsSync(filePath)) {
        // Set proper content type for PDF files
        if (filename.endsWith('.pdf')) {
            res.setHeader('Content-Type', 'application/pdf');
        }
        // File exists, send it
        res.download(filePath);
    } else {
        // For sales training documents, ensure they're generated
        if (category === 'sales-training' && filename.endsWith('.pdf')) {
            ensureSalesTrainingPDFs()
                .then(() => {
                    if (fs.existsSync(filePath)) {
                        res.setHeader('Content-Type', 'application/pdf');
                        res.download(filePath);
                    } else {
                        res.status(404).send('File not found');
                    }
                })
                .catch(err => {
                    console.error('Error ensuring sales training PDFs:', err);
                    res.status(500).send('Error generating document');
                });
        } else {
            // For other files, generate a generic PDF
            const htmlContent = `
            <h1>${filename.replace('.pdf', '')}</h1>
            <h2>Category: ${category}</h2>
            <p>This document provides information related to ${category}.</p>
            <p>In a production environment, this would contain comprehensive documentation.</p>
            `;
            
            const outputPath = filePath;
            
            generatePDF(htmlContent, outputPath)
                .then(() => {
                    // Set proper content type for PDF files
                    if (filename.endsWith('.pdf')) {
                        res.setHeader('Content-Type', 'application/pdf');
                    }
                    res.download(outputPath);
                })
                .catch(err => {
                    console.error('Error generating PDF:', err);
                    res.status(500).send('Error generating document');
                });
        }
    }
});

module.exports = router;
