// Simple Floating AI Button
document.addEventListener('DOMContentLoaded', function() {
  // Create a simple AI bubble
  const aiButton = document.createElement('div');
  aiButton.style.position = 'fixed';
  aiButton.style.bottom = '20px';
  aiButton.style.right = '20px';
  aiButton.style.width = '60px';
  aiButton.style.height = '60px';
  aiButton.style.backgroundColor = '#0066cc';
  aiButton.style.color = 'white';
  aiButton.style.borderRadius = '50%';
  aiButton.style.display = 'flex';
  aiButton.style.justifyContent = 'center';
  aiButton.style.alignItems = 'center';
  aiButton.style.cursor = 'pointer';
  aiButton.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
  aiButton.style.zIndex = '9999';
  aiButton.innerHTML = 'AI';
  aiButton.style.fontSize = '24px';
  aiButton.style.fontWeight = 'bold';
  
  // Create a simple chat box
  const chatBox = document.createElement('div');
  chatBox.style.position = 'fixed';
  chatBox.style.bottom = '90px';
  chatBox.style.right = '20px';
  chatBox.style.width = '300px';
  chatBox.style.height = '400px';
  chatBox.style.backgroundColor = 'white';
  chatBox.style.borderRadius = '10px';
  chatBox.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
  chatBox.style.zIndex = '9998';
  chatBox.style.display = 'none';
  chatBox.style.flexDirection = 'column';
  chatBox.style.overflow = 'hidden';
  
  // Create header
  const header = document.createElement('div');
  header.style.padding = '10px';
  header.style.backgroundColor = '#0066cc';
  header.style.color = 'white';
  header.style.fontWeight = 'bold';
  header.style.borderTopLeftRadius = '10px';
  header.style.borderTopRightRadius = '10px';
  header.style.display = 'flex';
  header.style.justifyContent = 'space-between';
  header.innerHTML = 'ABL Group AI Assistant';
  
  // Close button
  const closeBtn = document.createElement('span');
  closeBtn.innerHTML = '×';
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.fontSize = '20px';
  header.appendChild(closeBtn);
  
  // Message area
  const messageArea = document.createElement('div');
  messageArea.style.flex = '1';
  messageArea.style.padding = '10px';
  messageArea.style.overflowY = 'auto';
  messageArea.style.display = 'flex';
  messageArea.style.flexDirection = 'column';
  
  // Initial message
  const initialMessage = document.createElement('div');
  initialMessage.style.backgroundColor = '#f0f0f0';
  initialMessage.style.padding = '10px';
  initialMessage.style.borderRadius = '10px';
  initialMessage.style.marginBottom = '10px';
  initialMessage.style.maxWidth = '80%';
  initialMessage.innerHTML = 'Hello! How can I assist you with ABL Group services today?';
  messageArea.appendChild(initialMessage);
  
  // Input area
  const inputArea = document.createElement('div');
  inputArea.style.padding = '10px';
  inputArea.style.borderTop = '1px solid #eee';
  inputArea.style.display = 'flex';
  
  // Text input
  const textInput = document.createElement('input');
  textInput.type = 'text';
  textInput.placeholder = 'Type your message...';
  textInput.style.flex = '1';
  textInput.style.padding = '8px';
  textInput.style.border = '1px solid #ddd';
  textInput.style.borderRadius = '20px';
  textInput.style.marginRight = '10px';
  
  // Send button
  const sendBtn = document.createElement('button');
  sendBtn.innerHTML = 'Send';
  sendBtn.style.backgroundColor = '#0066cc';
  sendBtn.style.color = 'white';
  sendBtn.style.border = 'none';
  sendBtn.style.borderRadius = '20px';
  sendBtn.style.padding = '8px 15px';
  sendBtn.style.cursor = 'pointer';
  
  // Assemble the chat box
  inputArea.appendChild(textInput);
  inputArea.appendChild(sendBtn);
  chatBox.appendChild(header);
  chatBox.appendChild(messageArea);
  chatBox.appendChild(inputArea);
  
  // Add to document
  document.body.appendChild(aiButton);
  document.body.appendChild(chatBox);
  
  // Toggle chat box
  aiButton.addEventListener('click', function() {
    if (chatBox.style.display === 'none') {
      chatBox.style.display = 'flex';
    } else {
      chatBox.style.display = 'none';
    }
  });
  
  // Close chat box
  closeBtn.addEventListener('click', function() {
    chatBox.style.display = 'none';
  });
  
  // Send message function
  function sendMessage() {
    const text = textInput.value.trim();
    if (!text) return;
    
    // Add user message
    const userMsg = document.createElement('div');
    userMsg.style.backgroundColor = '#e6f2ff';
    userMsg.style.padding = '10px';
    userMsg.style.borderRadius = '10px';
    userMsg.style.marginBottom = '10px';
    userMsg.style.alignSelf = 'flex-end';
    userMsg.style.maxWidth = '80%';
    userMsg.innerHTML = text;
    messageArea.appendChild(userMsg);
    
    // Clear input
    textInput.value = '';
    
    // Auto response
    setTimeout(function() {
      const botMsg = document.createElement('div');
      botMsg.style.backgroundColor = '#f0f0f0';
      botMsg.style.padding = '10px';
      botMsg.style.borderRadius = '10px';
      botMsg.style.marginBottom = '10px';
      botMsg.style.maxWidth = '80%';
      
      if (text.toLowerCase().includes('energy') || text.toLowerCase().includes('transition')) {
        botMsg.innerHTML = 'ABL Group supports the energy transition with digital solutions and consultancy services across the renewable energy sector.';
      } else if (text.toLowerCase().includes('marine')) {
        botMsg.innerHTML = 'ABL Group offers comprehensive marine services including warranty surveys and engineering consultancy.';
      } else if (text.toLowerCase().includes('software') || text.toLowerCase().includes('digital')) {
        botMsg.innerHTML = 'ABL Group provides digital solutions including AssetVoice™, Effio™, and ePAV™ for asset tracking and data management.';
      } else {
        botMsg.innerHTML = 'ABL Group offers services across energy, marine, and engineering sectors. How can I assist you further?';
      }
      
      messageArea.appendChild(botMsg);
      messageArea.scrollTop = messageArea.scrollHeight;
    }, 500);
    
    // Scroll to bottom
    messageArea.scrollTop = messageArea.scrollHeight;
  }
  
  // Send button click
  sendBtn.addEventListener('click', sendMessage);
  
  // Enter key press
  textInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });
});
