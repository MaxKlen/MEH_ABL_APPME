// Services page functionality
document.addEventListener('DOMContentLoaded', function() {
    console.log('Services page JS loaded');
    
    // Quick filter buttons
    const quickFilterBtns = document.querySelectorAll('.quick-filter-btn');
    if (quickFilterBtns.length > 0) {
        console.log('Found quick filter buttons:', quickFilterBtns.length);
        quickFilterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const segment = this.getAttribute('data-segment');
                const stage = this.getAttribute('data-stage');
                
                console.log('Quick filter clicked:', segment || stage);
                
                // Update the form selects to match the clicked button
                if (segment) {
                    document.getElementById('segment-filter').value = segment;
                    // Update active state for segment buttons
                    document.querySelectorAll('.quick-filter-btn[data-segment]').forEach(b => {
                        b.classList.remove('active');
                    });
                    this.classList.add('active');
                }
                if (stage) {
                    document.getElementById('lifecycle-stage-filter').value = stage;
                    // Update active state for stage buttons
                    document.querySelectorAll('.quick-filter-btn[data-stage]').forEach(b => {
                        b.classList.remove('active');
                    });
                    this.classList.add('active');
                }
                
                // Apply filters immediately
                applyFilters();
            });
        });
    }
    
    // Service filter form
    const serviceFilterForm = document.getElementById('service-filter-form');
    if (serviceFilterForm) {
        serviceFilterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            applyFilters();
        });
    }
    
    // Function to apply filters
    function applyFilters() {
        // Get filter values
        const segment = document.getElementById('segment-filter').value;
        const stage = document.getElementById('lifecycle-stage-filter').value;
        const keyword = document.getElementById('keyword-filter').value.trim().toLowerCase();
        
        console.log('Applying filters:', { segment, stage, keyword });
        
        // Filter service cards
        const serviceCards = document.querySelectorAll('.service-card');
        let visibleCount = 0;
        
        serviceCards.forEach(card => {
            const cardSegment = card.getAttribute('data-segment');
            const cardStage = card.getAttribute('data-stage');
            const cardTitle = card.querySelector('.card-title').textContent.toLowerCase();
            const cardDescription = card.querySelector('.card-text').textContent.toLowerCase();
            
            // Check if card matches all active filters
            const matchesSegment = segment === 'all' || cardSegment === segment;
            const matchesStage = stage === 'all' || cardStage === stage;
            const matchesKeyword = keyword === '' || 
                                  cardTitle.includes(keyword) || 
                                  cardDescription.includes(keyword);
            
            // Show/hide card based on filter matches
            if (matchesSegment && matchesStage && matchesKeyword) {
                card.style.display = '';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });
        
        console.log('Visible services after filtering:', visibleCount);
        
        // Show/hide "no results" message
        const noResultsMessage = document.querySelector('.no-results-message');
        if (noResultsMessage) {
            if (visibleCount === 0) {
                noResultsMessage.style.display = 'block';
            } else {
                noResultsMessage.style.display = 'none';
            }
        }
    }
    
    // Client-side keyword search for immediate filtering
    const keywordFilter = document.getElementById('keyword-filter');
    if (keywordFilter) {
        keywordFilter.addEventListener('input', function() {
            // Apply filters on each keystroke
            applyFilters();
        });
    }
    
    // Download functionality for service details
    const downloadButtons = document.querySelectorAll('.download-service-info');
    if (downloadButtons.length > 0) {
        console.log('Found download buttons:', downloadButtons.length);
        downloadButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const serviceId = this.getAttribute('data-service-id');
                const serviceName = this.getAttribute('data-service-name');
                
                console.log('Download requested for service:', serviceName);
                
                // Generate PDF content
                const serviceDetails = document.querySelector('.service-details-container');
                if (serviceDetails) {
                    // Create a PDF and download it
                    const fileName = `${serviceName.replace(/\s+/g, '-').toLowerCase()}-service-details.pdf`;
                    
                    // Redirect to download endpoint
                    window.location.href = `/downloads/services/${serviceId}`;
                }
            });
        });
    }
    
    // Initialize filters on page load
    applyFilters();
});
