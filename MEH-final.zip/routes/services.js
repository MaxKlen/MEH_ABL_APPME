const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Load mock data
const services = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/services.json')));
const businessSegments = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/business-segments.json')));
const lifecycleStages = JSON.parse(fs.readFileSync(path.join(__dirname, '../models/lifecycle-stages.json')));

// Services catalog page
router.get('/', (req, res) => {
  const segment = req.query.segment || 'all';
  const stage = req.query.stage || 'all';
  
  let filteredServices = services;
  
  // Filter by segment if specified
  if (segment !== 'all') {
    filteredServices = filteredServices.filter(service => service.segment === segment);
  }
  
  // Filter by lifecycle stage if specified
  if (stage !== 'all') {
    filteredServices = filteredServices.filter(service => service.lifecycleStages.includes(stage));
  }
  
  res.render('services', {
    title: 'Services Catalog',
    activeNav: 'services',
    services: filteredServices,
    segments: businessSegments,
    lifecycleStages: lifecycleStages,
    selectedSegment: segment,
    selectedStage: stage
  });
});

// Service detail page
router.get('/:id', (req, res) => {
  const serviceId = req.params.id;
  const service = services.find(s => s.id === serviceId);
  
  if (!service) {
    return res.status(404).render('error', {
      title: 'Service Not Found',
      message: 'The requested service does not exist.',
      error: { status: 404 }
    });
  }
  
  // Find related services
  const relatedServicesData = service.relatedServices
    ? service.relatedServices.map(id => services.find(s => s.id === id)).filter(Boolean)
    : [];
  
  // Find segment info
  const segment = businessSegments.find(s => s.id === service.segment);
  
  // Find business line info
  const businessLine = segment ? segment.businessLines.find(bl => bl.id === service.businessLine) : null;
  
  // Find lifecycle stages this service is part of
  const serviceLifecycleStages = lifecycleStages.filter(stage => 
    stage.services.includes(service.id)
  );
  
  // Find bundles that include this service
  const bundles = lifecycleStages.flatMap(stage => 
    stage.bundleRecommendations.filter(bundle => 
      bundle.services.includes(service.id)
    ).map(bundle => ({
      ...bundle,
      stage: stage.name
    }))
  );
  
  res.render('service-details', {
    title: service.name,
    activeNav: 'services',
    service,
    segment,
    businessLine,
    lifecycleStages: serviceLifecycleStages,
    relatedServices: relatedServicesData,
    bundles
  });
});

module.exports = router;
