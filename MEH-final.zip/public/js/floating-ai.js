// ABL Group AI Assistant
document.addEventListener("DOMContentLoaded", function() {
  // Only create the AI if it doesn"t already exist
  if (document.getElementById("abl-ai-bubble")) return;
  
  // Create the AI bubble
  const bubble = document.createElement("div");
  bubble.id = "abl-ai-bubble";
  bubble.style.position = "fixed";
  bubble.style.zIndex = "9999";
  bubble.style.bottom = "20px";
  bubble.style.right = "20px";
  bubble.style.width = "60px";
  bubble.style.height = "60px";
  bubble.style.borderRadius = "50%";
  bubble.style.backgroundColor = "#005C9A"; // ABL Blue
  bubble.style.color = "white";
  bubble.style.display = "flex";
  bubble.style.justifyContent = "center";
  bubble.style.alignItems = "center";
  bubble.style.boxShadow = "0 2px 10px rgba(0,0,0,0.2)";
  bubble.style.cursor = "pointer";
  bubble.style.fontSize = "24px";
  bubble.style.fontWeight = "bold";
  bubble.innerHTML = "AI";
  
  // Create the AI panel
  const panel = document.createElement("div");
  panel.id = "abl-ai-panel";
  panel.style.position = "fixed";
  panel.style.zIndex = "9998";
  panel.style.bottom = "90px";
  panel.style.right = "20px";
  panel.style.width = "350px";
  panel.style.height = "450px";
  panel.style.borderRadius = "10px";
  panel.style.backgroundColor = "white";
  panel.style.boxShadow = "0 5px 15px rgba(0,0,0,0.2)";
  panel.style.display = "none";
  panel.style.flexDirection = "column";
  panel.style.overflow = "hidden";
  
  // Create header
  const header = document.createElement("div");
  header.style.padding = "15px";
  header.style.backgroundColor = "#005C9A"; // ABL Blue
  header.style.color = "white";
  header.style.fontWeight = "bold";
  header.style.display = "flex";
  header.style.justifyContent = "space-between";
  header.style.alignItems = "center";
  
  const title = document.createElement("div");
  title.textContent = "ABL Group AI Assistant";
  title.style.fontSize = "16px";
  
  const closeBtn = document.createElement("button");
  closeBtn.innerHTML = "&times;";
  closeBtn.style.background = "none";
  closeBtn.style.border = "none";
  closeBtn.style.color = "white";
  closeBtn.style.fontSize = "20px";
  closeBtn.style.cursor = "pointer";
  
  header.appendChild(title);
  header.appendChild(closeBtn);
  
  // Create messages container
  const messagesContainer = document.createElement("div");
  messagesContainer.style.flex = "1";
  messagesContainer.style.padding = "15px";
  messagesContainer.style.overflowY = "auto";
  messagesContainer.style.display = "flex";
  messagesContainer.style.flexDirection = "column";
  
  // Add initial message
  const initialMessage = document.createElement("div");
  initialMessage.style.alignSelf = "flex-start";
  initialMessage.style.maxWidth = "80%";
  initialMessage.style.padding = "10px 15px";
  initialMessage.style.marginBottom = "10px";
  initialMessage.style.backgroundColor = "#f0f0f0";
  initialMessage.style.borderRadius = "18px 18px 18px 4px";
  initialMessage.textContent = "Hello! I am the ABL Group AI Assistant. How can I help you explore our services in energy and oceans?";
  messagesContainer.appendChild(initialMessage);
  
  // Create input area
  const inputArea = document.createElement("div");
  inputArea.style.padding = "15px";
  inputArea.style.borderTop = "1px solid #eee";
  inputArea.style.display = "flex";
  
  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "Ask about our services...";
  input.style.flex = "1";
  input.style.padding = "10px";
  input.style.border = "1px solid #ddd";
  input.style.borderRadius = "20px";
  input.style.marginRight = "10px";
  input.style.outline = "none";
  
  const sendBtn = document.createElement("button");
  sendBtn.textContent = "Send";
  sendBtn.style.backgroundColor = "#005C9A"; // ABL Blue
  sendBtn.style.color = "white";
  sendBtn.style.border = "none";
  sendBtn.style.borderRadius = "20px";
  sendBtn.style.padding = "8px 15px";
  sendBtn.style.cursor = "pointer";
  
  inputArea.appendChild(input);
  inputArea.appendChild(sendBtn);
  
  // Assemble panel
  panel.appendChild(header);
  panel.appendChild(messagesContainer);
  panel.appendChild(inputArea);
  
  // Add elements to the document
  document.body.appendChild(bubble);
  document.body.appendChild(panel);
  
  // Toggle panel visibility
  bubble.addEventListener("click", function() {
    if (panel.style.display === "none") {
      panel.style.display = "flex";
    } else {
      panel.style.display = "none";
    }
  });
  
  // Close panel
  closeBtn.addEventListener("click", function() {
    panel.style.display = "none";
  });
  
  // Handle sending messages
  function sendMessage() {
    const messageText = input.value.trim();
    if (!messageText) return;
    
    // Create user message element
    const userMessage = document.createElement("div");
    userMessage.style.alignSelf = "flex-end";
    userMessage.style.maxWidth = "80%";
    userMessage.style.padding = "10px 15px";
    userMessage.style.marginBottom = "10px";
    userMessage.style.backgroundColor = "#0078D4"; // Slightly different blue for user
    userMessage.style.color = "white";
    userMessage.style.borderRadius = "18px 18px 4px 18px";
    userMessage.textContent = messageText;
    messagesContainer.appendChild(userMessage);
    
    // Clear input
    input.value = "";
    
    // Auto-scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Respond based on user"s message
    setTimeout(function() {
      let responseText = "";
      const lowercaseMsg = messageText.toLowerCase();
      
      if (lowercaseMsg.includes("hello") || lowercaseMsg.includes("hi")) {
        responseText = "Hello there! How can I assist you with ABL Group's services today?";
      } else if (lowercaseMsg.includes("offshore wind") || lowercaseMsg.includes("floating wind")) {
        responseText = "ABL Group is a leader in offshore wind, including fixed and floating projects. We offer services from feasibility studies and engineering design to marine warranty survey (MWS) and operational support. OWC, an ABL Group company, specializes in this area.";
      } else if (lowercaseMsg.includes("marine warranty") || lowercaseMsg.includes("mws")) {
        responseText = "ABL provides comprehensive Marine Warranty Survey (MWS) services for complex offshore operations, ensuring safety and mitigating risks for loadouts, transportation, and installations.";
      } else if (lowercaseMsg.includes("energy transition") || lowercaseMsg.includes("decarbonization") || lowercaseMsg.includes("sustainability")) {
        responseText = "ABL Group is committed to the energy transition. We support decarbonization efforts through services for renewables like wind and solar, hydrogen, CCUS, and by helping traditional energy clients reduce their carbon footprint. Our expertise spans technical consultancy, digital solutions, and strategic advice.";
      } else if (lowercaseMsg.includes("software") || lowercaseMsg.includes("digital solutions")) {
        responseText = "ABL Group develops and offers various digital solutions, including AssetVoice™ for asset integrity, Effio™ for operational efficiency, and ePAV™ for remote inspection and verification. These tools enhance project management and operational performance.";
      } else if (lowercaseMsg.includes("abl company") || lowercaseMsg.includes("about abl")) {
        responseText = "ABL provides independent engineering, design, and consultancy services to the renewables, maritime, and oil & gas sectors. We focus on project development, risk management, and operational support.";
      } else if (lowercaseMsg.includes("owc")) {
        responseText = "OWC, an ABL Group company, is a specialized consultancy dedicated to offshore wind energy, offering project development services, owner's engineering, and technical due diligence globally.";
      } else if (lowercaseMsg.includes("longitude")) {
        responseText = "Longitude, part of ABL Group, provides independent engineering and design consultancy for marine projects, including vessel design, advanced analysis, and marine operations engineering.";
      } else if (lowercaseMsg.includes("agr")) {
        responseText = "AGR, an ABL Group company, delivers well and reservoir management, HSEQ, and software solutions to the upstream oil and gas industry, enhancing efficiency and safety.";
      } else if (lowercaseMsg.includes("services") || lowercaseMsg.includes("what do you do")) {
        responseText = "ABL Group offers a wide range of services across the energy and oceans sectors. This includes engineering, design, consultancy, marine warranty, project management, and digital solutions. Could you be more specific about what you're looking for?";
      } else if (lowercaseMsg.includes("contact") || lowercaseMsg.includes("reach you")) {
        responseText = "You can find contact information for our global offices on the ABL Group website. For specific inquiries, you can also use the lead form on this portal.";
      } else {
        responseText = "I can provide information about ABL Group's services in offshore wind, marine operations, energy transition, and our various business segments like ABL, OWC, Longitude, and AGR. Please ask a more specific question, or browse the catalog for details.";
      }
      
      // Create bot message element
      const botMessage = document.createElement("div");
      botMessage.style.alignSelf = "flex-start";
      botMessage.style.maxWidth = "80%";
      botMessage.style.padding = "10px 15px";
      botMessage.style.marginBottom = "10px";
      botMessage.style.backgroundColor = "#f0f0f0";
      botMessage.style.borderRadius = "18px 18px 18px 4px";
      botMessage.textContent = responseText;
      messagesContainer.appendChild(botMessage);
      
      // Auto-scroll to bottom
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }, 1000);
  }
  
  // Send message on button click
  sendBtn.addEventListener("click", sendMessage);
  
  // Send message on Enter key
  input.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
      sendMessage();
    }
  });
});

// Ensure the script runs when the page loads
if (document.readyState === "complete" || document.readyState === "interactive") {
  setTimeout(function() {
    var event = new Event("DOMContentLoaded");
    document.dispatchEvent(event);
  }, 500);
}

