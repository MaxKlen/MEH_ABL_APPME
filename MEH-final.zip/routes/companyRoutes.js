const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const businessSegmentsData = JSON.parse(fs.readFileSync(path.join(__dirname, "../models/business-segments.json")));

const getSegmentData = (segmentId) => {
  return businessSegmentsData.find(s => s.id.toLowerCase() === segmentId.toLowerCase());
};

router.get("/abl", (req, res) => {
  const segment = getSegmentData("abl");
  if (!segment) {
    console.error("ABL segment data not found in business-segments.json");
    return res.status(404).render("error", { title: "Error", message: "ABL segment data not found. Please check server logs.", error: {status: 404}});
  }
  res.render("company-page", {
    title: segment.name || "ABL",
    activeNav: "abl",
    segment: segment,
    pageContent: `This is the page for ABL. More details to come. Founded in ${segment.founded || "N/A"}. Based in ${segment.location || "N/A"}.`
  });
});

router.get("/owc", (req, res) => {
  const segment = getSegmentData("owc");
  if (!segment) {
    console.error("OWC segment data not found in business-segments.json");
    return res.status(404).render("error", { title: "Error", message: "OWC segment data not found. Please check server logs.", error: {status: 404}});
  }
  res.render("company-page", {
    title: segment.name || "OWC",
    activeNav: "owc",
    segment: segment,
    pageContent: `This is the page for OWC. Specializing in ${segment.specialization || "N/A"}.`
  });
});

router.get("/longitude", (req, res) => {
  const segment = getSegmentData("longitude");
  if (!segment) {
    console.error("Longitude segment data not found in business-segments.json");
    return res.status(404).render("error", { title: "Error", message: "Longitude segment data not found. Please check server logs.", error: {status: 404}});
  }
  res.render("company-page", {
    title: segment.name || "Longitude",
    activeNav: "longitude",
    segment: segment,
    pageContent: `This is the page for Longitude. Key services include ${segment.keyServices ? segment.keyServices.join(", ") : "various engineering services"}.`
  });
});

module.exports = router;
