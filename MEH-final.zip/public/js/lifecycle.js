// Lifecycle map interactive functionality
document.addEventListener('DOMContentLoaded', function() {
  console.log('Lifecycle map JS loaded');
  
  // Handle lifecycle stage clicks
  const lifecycleStages = document.querySelectorAll('.lifecycle-stage');
  
  if (lifecycleStages.length > 0) {
    console.log('Found lifecycle stages:', lifecycleStages.length);
    
    lifecycleStages.forEach(stage => {
      stage.addEventListener('click', function() {
        const stageId = this.getAttribute('data-stage');
        console.log('Stage clicked:', stageId);
        
        // Update active stage visually
        lifecycleStages.forEach(s => s.classList.remove('active'));
        this.classList.add('active');
        
        // Update the lifecycle map visualization
        updateLifecycleMap(stageId);
        
        // Update stage content
        updateStageContent(stageId);
      });
    });
    
    // Initialize with the first stage
    const firstStage = lifecycleStages[0].getAttribute('data-stage');
    updateLifecycleMap(firstStage);
    updateStageContent(firstStage);
  }
  
  // Function to update the lifecycle map visualization
  function updateLifecycleMap(stageId) {
    console.log('Updating lifecycle map for stage:', stageId);
    
    // Get the lifecycle map image container
    const mapContainer = document.querySelector('.lifecycle-map-container');
    if (!mapContainer) {
      console.error('Lifecycle map container not found');
      return;
    }
    
    // Add CSS styles for service indicators if not already present
    if (!document.getElementById('lifecycle-map-styles')) {
      const styleElement = document.createElement('style');
      styleElement.id = 'lifecycle-map-styles';
      styleElement.textContent = `
        .service-indicator {
          position: absolute;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.7);
          cursor: pointer;
          z-index: 100;
          transition: transform 0.2s ease;
        }
        .service-indicator:hover {
          transform: scale(1.3);
        }
        .service-tooltip {
          position: absolute;
          background-color: rgba(0, 0, 0, 0.8);
          color: white;
          padding: 5px 10px;
          border-radius: 5px;
          z-index: 101;
          white-space: nowrap;
          transform: translateX(-50%);
          pointer-events: none;
        }
        .stage-highlight {
          position: absolute;
          width: 40px;
          height: 40px;
          border-radius: 50%;
          border: 4px solid #ffc107;
          transform: translate(-50%, -50%);
          z-index: 99;
          animation: pulse 2s infinite;
        }
        @keyframes pulse {
          0% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0.7); }
          70% { box-shadow: 0 0 0 10px rgba(255, 193, 7, 0); }
          100% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0); }
        }
      `;
      document.head.appendChild(styleElement);
    }
    
    // Update the map visualization based on the selected stage
    // First, remove any existing service indicators
    const existingIndicators = mapContainer.querySelectorAll('.service-indicator');
    existingIndicators.forEach(indicator => indicator.remove());
    
    // Define service positions for each stage
    const servicePositions = {
      concept: [
        { top: '30%', left: '20%', segment: 'owc', name: 'Concept Development' },
        { top: '40%', left: '15%', segment: 'abl', name: 'Market Analysis' },
        { top: '25%', left: '25%', segment: 'owc', name: 'Preliminary Resource Assessment' }
      ],
      feasibility: [
        { top: '35%', left: '30%', segment: 'abl', name: 'Technical Feasibility Studies' },
        { top: '45%', left: '25%', segment: 'owc', name: 'Environmental Impact Assessment' },
        { top: '25%', left: '35%', segment: 'agr', name: 'Economic Modeling' },
        { top: '40%', left: '35%', segment: 'longitude', name: 'Site Selection & Analysis' }
      ],
      development: [
        { top: '30%', left: '45%', segment: 'longitude', name: 'Detailed Engineering Design' },
        { top: '40%', left: '50%', segment: 'abl', name: 'Permitting Support' },
        { top: '50%', left: '45%', segment: 'agr', name: 'Project Planning' }
      ],
      construction: [
        { top: '25%', left: '60%', segment: 'abl', name: 'Construction Management' },
        { top: '35%', left: '65%', segment: 'longitude', name: 'Quality Assurance' },
        { top: '45%', left: '60%', segment: 'abl', name: 'Marine Warranty Surveying' },
        { top: '55%', left: '65%', segment: 'owc', name: 'Installation Engineering' }
      ],
      operations: [
        { top: '25%', left: '75%', segment: 'abl', name: 'Asset Integrity Management' },
        { top: '35%', left: '80%', segment: 'owc', name: 'Performance Optimization' },
        { top: '45%', left: '75%', segment: 'agr', name: 'Maintenance Planning' },
        { top: '55%', left: '80%', segment: 'longitude', name: 'Operational Support' }
      ],
      decommissioning: [
        { top: '30%', left: '90%', segment: 'abl', name: 'Decommissioning Planning' },
        { top: '40%', left: '85%', segment: 'owc', name: 'Environmental Compliance' },
        { top: '50%', left: '90%', segment: 'agr', name: 'Asset Disposal Management' },
        { top: '60%', left: '85%', segment: 'longitude', name: 'Site Restoration' }
      ]
    };
    
    // Add service indicators for the selected stage
    const positions = servicePositions[stageId] || [];
    positions.forEach(position => {
      const indicator = document.createElement('div');
      indicator.className = 'service-indicator';
      indicator.style.top = position.top;
      indicator.style.left = position.left;
      indicator.style.backgroundColor = 
        position.segment === 'abl' ? '#0d6efd' : 
        position.segment === 'owc' ? '#198754' : 
        position.segment === 'agr' ? '#dc3545' : '#0dcaf0';
      indicator.title = position.name;
      
      // Add tooltip functionality
      indicator.addEventListener('mouseover', function() {
        const tooltip = document.createElement('div');
        tooltip.className = 'service-tooltip';
        tooltip.style.top = `calc(${position.top} - 40px)`;
        tooltip.style.left = position.left;
        tooltip.textContent = position.name;
        mapContainer.appendChild(tooltip);
        
        indicator.addEventListener('mouseout', function() {
          tooltip.remove();
        });
      });
      
      mapContainer.appendChild(indicator);
    });
    
    // Highlight the active stage on the map
    const stageHighlights = mapContainer.querySelectorAll('.stage-highlight');
    stageHighlights.forEach(highlight => highlight.remove());
    
    const stagePositions = {
      concept: { top: '50%', left: '16.7%' },
      feasibility: { top: '50%', left: '33.3%' },
      development: { top: '50%', left: '50%' },
      construction: { top: '50%', left: '66.7%' },
      operations: { top: '50%', left: '83.3%' },
      decommissioning: { top: '50%', left: '100%' }
    };
    
    const stagePosition = stagePositions[stageId];
    if (stagePosition) {
      const highlight = document.createElement('div');
      highlight.className = 'stage-highlight';
      highlight.style.top = stagePosition.top;
      highlight.style.left = stagePosition.left;
      mapContainer.appendChild(highlight);
    }
  }
  
  // Function to update stage content
  function updateStageContent(stageId) {
    console.log('Updating content for stage:', stageId);
    
    // Update stage name and description
    const stageNameElement = document.getElementById('stage-name');
    const stageDescriptionElement = document.getElementById('stage-description');
    const stageServicesContainer = document.getElementById('stage-services');
    
    if (!stageNameElement || !stageDescriptionElement || !stageServicesContainer) {
      console.error('Stage content elements not found');
      return;
    }
    
    let stageName = '';
    let stageDescription = '';
    let services = [];
    
    switch(stageId) {
      case 'concept':
        stageName = 'Concept';
        stageDescription = 'Initial project concept and idea generation';
        services = [
          {
            name: 'Marine Consultancy',
            provider: 'ABL Group',
            description: 'Specialized marine consultancy services for offshore projects.'
          },
          {
            name: 'Wind Resource Assessment',
            provider: 'OWC',
            description: 'Comprehensive assessment of wind resources for renewable energy projects.'
          },
          {
            name: 'Naval Architecture',
            provider: 'Longitude',
            description: 'Expert naval architecture services for marine vessel design.'
          }
        ];
        break;
      case 'feasibility':
        stageName = 'Feasibility';
        stageDescription = 'Evaluating technical, economic, and environmental viability';
        services = [
          {
            name: 'Technical Due Diligence',
            provider: 'ABL Group',
            description: 'Comprehensive technical assessment and due diligence services.'
          },
          {
            name: 'Environmental Impact Studies',
            provider: 'OWC',
            description: 'Detailed environmental impact assessments for energy projects.'
          },
          {
            name: 'Financial Modeling',
            provider: 'AGR',
            description: 'Sophisticated financial modeling and economic analysis.'
          }
        ];
        break;
      case 'development':
        stageName = 'Development';
        stageDescription = 'Detailed engineering, planning, and preparation';
        services = [
          {
            name: 'Engineering Design',
            provider: 'Longitude',
            description: 'Comprehensive engineering design services for energy projects.'
          },
          {
            name: 'Permitting Support',
            provider: 'ABL Group',
            description: 'Expert guidance through complex permitting processes.'
          },
          {
            name: 'Project Management',
            provider: 'AGR',
            description: 'End-to-end project management and coordination services.'
          }
        ];
        break;
      case 'construction':
        stageName = 'Construction';
        stageDescription = 'Building, installation, and commissioning';
        services = [
          {
            name: 'Construction Supervision',
            provider: 'ABL Group',
            description: 'Expert supervision of construction activities and contractors.'
          },
          {
            name: 'Quality Assurance',
            provider: 'Longitude',
            description: 'Comprehensive quality assurance and control services.'
          },
          {
            name: 'Installation Support',
            provider: 'OWC',
            description: 'Specialized support for installation of renewable energy assets.'
          }
        ];
        break;
      case 'operations':
        stageName = 'Operations';
        stageDescription = 'Running, maintaining, and optimizing operational assets';
        services = [
          {
            name: 'Asset Integrity Management',
            provider: 'ABL Group',
            description: 'Comprehensive management of asset integrity throughout operational life.'
          },
          {
            name: 'Performance Optimization',
            provider: 'OWC',
            description: 'Services to optimize operational performance of energy assets.'
          },
          {
            name: 'Maintenance Planning',
            provider: 'AGR',
            description: 'Strategic maintenance planning to maximize uptime and efficiency.'
          }
        ];
        break;
      case 'decommissioning':
        stageName = 'Decommissioning';
        stageDescription = 'Safe and environmentally responsible project closure';
        services = [
          {
            name: 'Decommissioning Planning',
            provider: 'ABL Group',
            description: 'Strategic planning for efficient and compliant decommissioning.'
          },
          {
            name: 'Environmental Compliance',
            provider: 'OWC',
            description: 'Ensuring decommissioning activities meet environmental regulations.'
          },
          {
            name: 'Site Restoration',
            provider: 'Longitude',
            description: 'Comprehensive site restoration and rehabilitation services.'
          }
        ];
        break;
      default:
        stageName = 'Select a Stage';
        stageDescription = 'Please select a lifecycle stage to view details';
        services = [];
    }
    
    // Update the DOM with stage information
    stageNameElement.textContent = stageName;
    stageDescriptionElement.textContent = stageDescription;
    
    // Clear and rebuild services list
    stageServicesContainer.innerHTML = '';
    
    services.forEach(service => {
      const serviceCard = document.createElement('div');
      serviceCard.className = 'col-md-4 mb-4';
      
      const providerClass = 
        service.provider === 'ABL Group' ? 'bg-primary' : 
        service.provider === 'OWC' ? 'bg-success' : 
        service.provider === 'AGR' ? 'bg-danger' : 'bg-info';
      
      serviceCard.innerHTML = `
        <div class="card h-100">
          <div class="card-header ${providerClass} text-white">
            ${service.name}
          </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted">${service.provider}</h6>
            <p class="card-text">${service.description}</p>
          </div>
          <div class="card-footer">
            <a href="/services?provider=${service.provider.toLowerCase()}" class="btn btn-sm btn-outline-secondary">Learn More</a>
          </div>
        </div>
      `;
      
      stageServicesContainer.appendChild(serviceCard);
    });
  }
});
